<?php
/**
 * Stock Transfer Demo Test Scenarios
 * Interactive testing interface for system demonstration
 */

require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/config/database.php';

// Ensure only admins can access this testing tool
$currentUser = require_login_page();
if ($currentUser['role'] !== 'admin') {
    http_response_code(403);
    die('Access denied. Admin role required for testing tools.');
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Stock Transfer Demo Scenarios - RAM-YUM Store</title>
    <link rel="stylesheet" href="assets/css/main.css">
    <style>
        body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; }
        .container { max-width: 1200px; margin: 0 auto; padding: 20px; }
        .scenario-card {
            background: var(--bg-card);
            border: 1px solid var(--border-color);
            border-radius: 12px;
            padding: 24px;
            margin-bottom: 20px;
            box-shadow: var(--shadow-sm);
        }
        .scenario-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 16px;
        }
        .scenario-title {
            font-size: 1.25rem;
            font-weight: 700;
            color: var(--text-primary);
            margin-bottom: 4px;
        }
        .scenario-subtitle {
            color: var(--text-secondary);
            font-size: 0.875rem;
        }
        .status-badge {
            padding: 6px 12px;
            border-radius: 20px;
            font-size: 0.75rem;
            font-weight: 600;
            text-transform: uppercase;
        }
        .status-pending { background: #FEF3C7; color: #92400E; }
        .status-approved { background: #D1FAE5; color: #065F46; }
        .status-rejected { background: #FEE2E2; color: #991B1B; }
        .status-completed { background: #DBEAFE; color: #1E40AF; }
        .test-actions {
            display: flex;
            gap: 12px;
            flex-wrap: wrap;
            margin-top: 16px;
        }
        .btn {
            padding: 10px 16px;
            border: none;
            border-radius: 8px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.2s;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }
        .btn-primary { background: var(--primary-red); color: white; }
        .btn-secondary { background: var(--bg-gray); color: var(--text-primary); }
        .btn-success { background: #10B981; color: white; }
        .btn-warning { background: #F59E0B; color: white; }
        .btn-danger { background: #EF4444; color: white; }
        .btn:hover { transform: translateY(-1px); box-shadow: 0 4px 12px rgba(0,0,0,0.15); }
        .details-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 16px;
            margin: 16px 0;
        }
        .detail-item {
            background: var(--bg-gray);
            padding: 12px;
            border-radius: 8px;
        }
        .detail-label {
            font-size: 0.75rem;
            font-weight: 600;
            color: var(--text-secondary);
            text-transform: uppercase;
            margin-bottom: 4px;
        }
        .detail-value {
            color: var(--text-primary);
            font-weight: 500;
        }
        .workflow-steps {
            display: flex;
            align-items: center;
            gap: 12px;
            margin: 20px 0;
            padding: 16px;
            background: var(--bg-gray);
            border-radius: 8px;
            overflow-x: auto;
        }
        .workflow-step {
            display: flex;
            flex-direction: column;
            align-items: center;
            min-width: 100px;
            text-align: center;
        }
        .step-icon {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
            margin-bottom: 8px;
        }
        .step-active { background: var(--primary-red); color: white; }
        .step-completed { background: #10B981; color: white; }
        .step-pending { background: var(--bg-white); border: 2px solid var(--border-color); }
        .step-rejected { background: #EF4444; color: white; }
        .arrow { font-size: 1.5rem; color: var(--text-muted); }
        .items-list {
            background: var(--bg-gray);
            border-radius: 8px;
            padding: 16px;
            margin: 16px 0;
        }
        .item-row {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 8px 0;
            border-bottom: 1px solid var(--border-color);
        }
        .item-row:last-child { border-bottom: none; }
        .alert {
            padding: 16px;
            border-radius: 8px;
            margin: 16px 0;
            border-left: 4px solid;
        }
        .alert-info { background: #EBF8FF; border-color: #3182CE; color: #2C5282; }
        .alert-success { background: #F0FDF4; border-color: #10B981; color: #065F46; }
        .alert-warning { background: #FFFBEB; border-color: #F59E0B; color: #92400E; }
        .alert-danger { background: #FEF2F2; border-color: #EF4444; color: #991B1B; }
    </style>
</head>
<body>
    <div class="container">
        <div style="text-align: center; margin-bottom: 40px;">
            <h1 style="color: var(--text-primary); margin-bottom: 8px;">Stock Transfer Demo Scenarios</h1>
            <p style="color: var(--text-secondary);">Interactive testing environment for system demonstration</p>
        </div>

        <div class="alert alert-info">
            <strong>Demo Environment:</strong> This tool provides comprehensive test scenarios for demonstrating the Stock Transfer module functionality. Use these scenarios to showcase workflow capabilities during presentations.
        </div>

        <!-- Scenario 1: Urgent Restock -->
        <div class="scenario-card">
            <div class="scenario-header">
                <div>
                    <div class="scenario-title">🚨 Scenario 1: Urgent Branch Restock</div>
                    <div class="scenario-subtitle">High-priority transfer pending approval</div>
                </div>
                <div class="status-badge status-pending">Pending Approval</div>
            </div>

            <div class="workflow-steps">
                <div class="workflow-step">
                    <div class="step-icon step-completed">✓</div>
                    <small>Created</small>
                </div>
                <div class="arrow">→</div>
                <div class="workflow-step">
                    <div class="step-icon step-completed">✓</div>
                    <small>Submitted</small>
                </div>
                <div class="arrow">→</div>
                <div class="workflow-step">
                    <div class="step-icon step-active">⏳</div>
                    <small>Approval</small>
                </div>
                <div class="arrow">→</div>
                <div class="workflow-step">
                    <div class="step-icon step-pending">📦</div>
                    <small>Transfer</small>
                </div>
            </div>

            <div class="details-grid">
                <div class="detail-item">
                    <div class="detail-label">Transfer ID</div>
                    <div class="detail-value">ST-2026-0101</div>
                </div>
                <div class="detail-item">
                    <div class="detail-label">Route</div>
                    <div class="detail-value">Main Warehouse → Branch 1</div>
                </div>
                <div class="detail-item">
                    <div class="detail-label">Priority</div>
                    <div class="detail-value">🔴 High</div>
                </div>
                <div class="detail-item">
                    <div class="detail-label">Total Items</div>
                    <div class="detail-value">115 pieces</div>
                </div>
            </div>

            <div class="items-list">
                <div class="detail-label">Transfer Items</div>
                <div class="item-row">
                    <span>Samyang Buldak Original (50 pcs)</span>
                    <span>Source: 150 → Dest: 8</span>
                </div>
                <div class="item-row">
                    <span>Shin Ramyun (40 pcs)</span>
                    <span>Source: 200 → Dest: 12</span>
                </div>
                <div class="item-row">
                    <span>Chapagetti (25 pcs)</span>
                    <span>Source: 100 → Dest: 5</span>
                </div>
            </div>

            <div class="alert alert-warning">
                <strong>Test Scenario:</strong> Branch 1 is critically low on bestselling items. This demonstrates urgent approval workflow and inventory level monitoring.
            </div>

            <div class="test-actions">
                <a href="dashboard.php" class="btn btn-primary">View in Dashboard</a>
                <button class="btn btn-success" onclick="approveTransfer('ST-2026-0101')">✅ Approve Transfer</button>
                <button class="btn btn-danger" onclick="rejectTransfer('ST-2026-0101')">❌ Reject Transfer</button>
                <button class="btn btn-secondary" onclick="viewDetails('ST-2026-0101')">📋 View Details</button>
            </div>
        </div>

        <!-- Scenario 2: New Product Launch -->
        <div class="scenario-card">
            <div class="scenario-header">
                <div>
                    <div class="scenario-title">🚀 Scenario 2: New Product Launch Distribution</div>
                    <div class="scenario-subtitle">Market test distribution to QC branch</div>
                </div>
                <div class="status-badge status-pending">Pending Approval</div>
            </div>

            <div class="workflow-steps">
                <div class="workflow-step">
                    <div class="step-icon step-completed">✓</div>
                    <small>Created</small>
                </div>
                <div class="arrow">→</div>
                <div class="workflow-step">
                    <div class="step-icon step-completed">✓</div>
                    <small>Submitted</small>
                </div>
                <div class="arrow">→</div>
                <div class="workflow-step">
                    <div class="step-icon step-active">⏳</div>
                    <small>Approval</small>
                </div>
                <div class="arrow">→</div>
                <div class="workflow-step">
                    <div class="step-icon step-pending">📦</div>
                    <small>Transfer</small>
                </div>
            </div>

            <div class="details-grid">
                <div class="detail-item">
                    <div class="detail-label">Transfer ID</div>
                    <div class="detail-value">ST-2026-0102</div>
                </div>
                <div class="detail-item">
                    <div class="detail-label">Route</div>
                    <div class="detail-value">Main Warehouse → Branch 2</div>
                </div>
                <div class="detail-item">
                    <div class="detail-label">Priority</div>
                    <div class="detail-value">🟡 Medium</div>
                </div>
                <div class="detail-item">
                    <div class="detail-label">Total Items</div>
                    <div class="detail-value">50 pieces</div>
                </div>
            </div>

            <div class="alert alert-info">
                <strong>Test Scenario:</strong> Demonstrates new product distribution workflow and strategic inventory placement for market testing.
            </div>

            <div class="test-actions">
                <button class="btn btn-success" onclick="approveTransfer('ST-2026-0102')">✅ Approve Launch</button>
                <button class="btn btn-warning" onclick="requestModification('ST-2026-0102')">📝 Request Changes</button>
                <button class="btn btn-secondary" onclick="viewDetails('ST-2026-0102')">📋 View Details</button>
            </div>
        </div>

        <!-- Scenario 3: Completed Transfer -->
        <div class="scenario-card">
            <div class="scenario-header">
                <div>
                    <div class="scenario-title">✅ Scenario 3: Successful Inventory Optimization</div>
                    <div class="scenario-subtitle">Completed seasonal redistribution with audit trail</div>
                </div>
                <div class="status-badge status-approved">Completed</div>
            </div>

            <div class="workflow-steps">
                <div class="workflow-step">
                    <div class="step-icon step-completed">✓</div>
                    <small>Created</small>
                </div>
                <div class="arrow">→</div>
                <div class="workflow-step">
                    <div class="step-icon step-completed">✓</div>
                    <small>Submitted</small>
                </div>
                <div class="arrow">→</div>
                <div class="workflow-step">
                    <div class="step-icon step-completed">✓</div>
                    <small>Approved</small>
                </div>
                <div class="arrow">→</div>
                <div class="workflow-step">
                    <div class="step-icon step-completed">✅</div>
                    <small>Completed</small>
                </div>
            </div>

            <div class="details-grid">
                <div class="detail-item">
                    <div class="detail-label">Transfer ID</div>
                    <div class="detail-value">ST-2026-0103</div>
                </div>
                <div class="detail-item">
                    <div class="detail-label">Route</div>
                    <div class="detail-value">Main Warehouse → BGC Storage</div>
                </div>
                <div class="detail-item">
                    <div class="detail-label">Items Transferred</div>
                    <div class="detail-value">175 pieces</div>
                </div>
                <div class="detail-item">
                    <div class="detail-label">Value</div>
                    <div class="detail-value">₱3,500.00</div>
                </div>
            </div>

            <div class="alert alert-success">
                <strong>Test Scenario:</strong> Shows complete workflow with inventory movements and audit trail. Perfect for demonstrating successful transfers.
            </div>

            <div class="test-actions">
                <button class="btn btn-secondary" onclick="viewAuditTrail('ST-2026-0103')">📊 View Audit Trail</button>
                <button class="btn btn-secondary" onclick="viewInventoryImpact('ST-2026-0103')">📈 Inventory Impact</button>
                <button class="btn btn-secondary" onclick="generateReport('ST-2026-0103')">📄 Generate Report</button>
            </div>
        </div>

        <!-- Scenario 4: Rejected Transfer -->
        <div class="scenario-card">
            <div class="scenario-header">
                <div>
                    <div class="scenario-title">❌ Scenario 4: Business Logic Rejection</div>
                    <div class="scenario-subtitle">Transfer rejected with detailed reasoning</div>
                </div>
                <div class="status-badge status-rejected">Rejected</div>
            </div>

            <div class="workflow-steps">
                <div class="workflow-step">
                    <div class="step-icon step-completed">✓</div>
                    <small>Created</small>
                </div>
                <div class="arrow">→</div>
                <div class="workflow-step">
                    <div class="step-icon step-completed">✓</div>
                    <small>Submitted</small>
                </div>
                <div class="arrow">→</div>
                <div class="workflow-step">
                    <div class="step-icon step-rejected">❌</div>
                    <small>Rejected</small>
                </div>
                <div class="arrow">→</div>
                <div class="workflow-step">
                    <div class="step-icon step-pending">📝</div>
                    <small>Alternative</small>
                </div>
            </div>

            <div class="alert alert-danger">
                <strong>Rejection Reason:</strong> Insufficient inventory at source. Branch 1 has only 45 units but requires minimum 20 units for daily operations.
            </div>

            <div class="alert alert-info">
                <strong>Suggested Alternative:</strong> Transfer from Main Warehouse (150 units available) or reduce order quantity to 25 units.
            </div>

            <div class="test-actions">
                <button class="btn btn-primary" onclick="createAlternative('ST-2026-0104')">🔄 Create Alternative</button>
                <button class="btn btn-secondary" onclick="viewRejectionDetails('ST-2026-0104')">📋 View Rejection Details</button>
            </div>
        </div>

        <!-- Scenario 5: Emergency Transfer -->
        <div class="scenario-card">
            <div class="scenario-header">
                <div>
                    <div class="scenario-title">🚨 Scenario 5: Emergency Fast-Track</div>
                    <div class="scenario-subtitle">Critical priority with expedited approval</div>
                </div>
                <div class="status-badge status-approved">Emergency Approved</div>
            </div>

            <div class="workflow-steps">
                <div class="workflow-step">
                    <div class="step-icon step-completed">✓</div>
                    <small>Created</small>
                </div>
                <div class="arrow">→</div>
                <div class="workflow-step">
                    <div class="step-icon step-completed">⚡</div>
                    <small>Fast-Track</small>
                </div>
                <div class="arrow">→</div>
                <div class="workflow-step">
                    <div class="step-icon step-completed">✅</div>
                    <small>Approved</small>
                </div>
                <div class="arrow">→</div>
                <div class="workflow-step">
                    <div class="step-icon step-active">🚛</div>
                    <small>In Transit</small>
                </div>
            </div>

            <div class="alert alert-warning">
                <strong>Emergency Status:</strong> Main supplier delivery delayed. Branch experiencing stockout during peak hours.
            </div>

            <div class="test-actions">
                <button class="btn btn-warning" onclick="trackDelivery('ST-2026-0105')">🚛 Track Delivery</button>
                <button class="btn btn-secondary" onclick="notifyCompletion('ST-2026-0105')">📱 Mark Completed</button>
            </div>
        </div>

        <!-- Testing Tools Section -->
        <div class="scenario-card" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white;">
            <div class="scenario-title" style="color: white;">🧪 Testing Tools & Controls</div>
            <div class="scenario-subtitle" style="color: rgba(255,255,255,0.8);">Administrative tools for demo environment management</div>
            
            <div class="test-actions" style="margin-top: 24px;">
                <button class="btn" style="background: white; color: #667eea;" onclick="resetDemoData()">🔄 Reset All Demo Data</button>
                <button class="btn" style="background: rgba(255,255,255,0.2); color: white;" onclick="generateNewScenarios()">✨ Generate New Scenarios</button>
                <button class="btn" style="background: rgba(255,255,255,0.2); color: white;" onclick="exportTestResults()">📊 Export Test Results</button>
                <button class="btn" style="background: rgba(255,255,255,0.2); color: white;" onclick="viewSystemHealth()">💚 System Health Check</button>
            </div>
        </div>

        <!-- Quick Links -->
        <div style="text-align: center; margin-top: 40px; padding-top: 20px; border-top: 1px solid var(--border-color);">
            <h3 style="color: var(--text-primary); margin-bottom: 16px;">Quick Access Links</h3>
            <div style="display: flex; justify-content: center; gap: 16px; flex-wrap: wrap;">
                <a href="dashboard.php" class="btn btn-primary">📊 Main Dashboard</a>
                <a href="setup-stock-transfer-db.php" class="btn btn-secondary">🛠️ Setup Database</a>
                <a href="test-workflow.php" class="btn btn-secondary">⚙️ Test Workflow</a>
                <a href="validate-modules.html" class="btn btn-secondary">✅ Validate Modules</a>
            </div>
        </div>
    </div>

    <script>
        // Demo scenario interaction functions
        function approveTransfer(transferId) {
            if (confirm(`Approve transfer ${transferId}? This will update inventory levels.`)) {
                fetch('api/stock-transfers.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        action: 'approve',
                        transferId: transferId,
                        approvalRemarks: 'Approved via demo interface'
                    })
                })
                .then(response => response.json())
                .then(result => {
                    if (result.success) {
                        alert('Transfer approved successfully!');
                        location.reload();
                    } else {
                        alert('Error: ' + result.error);
                    }
                });
            }
        }

        function rejectTransfer(transferId) {
            const reason = prompt('Enter rejection reason:');
            if (reason) {
                fetch('api/stock-transfers.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        action: 'reject',
                        transferId: transferId,
                        rejectionReason: reason
                    })
                })
                .then(response => response.json())
                .then(result => {
                    if (result.success) {
                        alert('Transfer rejected!');
                        location.reload();
                    } else {
                        alert('Error: ' + result.error);
                    }
                });
            }
        }

        function viewDetails(transferId) {
            window.open(`dashboard.php#stock-transfer?transfer=${transferId}`, '_blank');
        }

        function viewAuditTrail(transferId) {
            alert(`Viewing audit trail for ${transferId}\n\nThis would show detailed history of all actions performed on this transfer.`);
        }

        function viewInventoryImpact(transferId) {
            alert(`Inventory impact analysis for ${transferId}\n\nThis would show before/after inventory levels and financial impact.`);
        }

        function trackDelivery(transferId) {
            alert(`Tracking delivery for ${transferId}\n\nThis would show real-time delivery status and ETA.`);
        }

        function resetDemoData() {
            if (confirm('Reset all demo data? This will restore the original test scenarios.')) {
                fetch('setup-stock-transfer-db.php?action=reset_demo')
                .then(() => {
                    alert('Demo data reset successfully!');
                    location.reload();
                });
            }
        }

        function generateNewScenarios() {
            alert('This would generate additional test scenarios with random data for extended testing.');
        }

        function exportTestResults() {
            alert('This would export comprehensive test results and audit trails for documentation.');
        }

        function viewSystemHealth() {
            window.open('api/stock-transfers.php?action=health_check', '_blank');
        }

        // Auto-refresh every 30 seconds to show real-time updates
        setTimeout(() => location.reload(), 30000);
    </script>
</body>
</html>