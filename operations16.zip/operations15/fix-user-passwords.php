<?php
/**
 * FIX USER PASSWORDS - Convert all passwords to bcrypt
 * For demonstration/capstone: Use known demo passwords
 */

require_once 'config/database.php';

$db = getDB();

echo "═══════════════════════════════════════════════════════════════════════\n";
echo "FIX USER PASSWORDS - SECURITY UPDATE\n";
echo "═══════════════════════════════════════════════════════════════════════\n\n";

// Define demo passwords for capstone demonstration
$users = [
    'admin' => [
        'password' => 'admin123',
        'role' => 'admin'
    ],
    'manager' => [
        'password' => 'manager123',
        'role' => 'manager'
    ],
    'staff' => [
        'password' => 'staff123',
        'role' => 'staff'
    ]
];

try {
    $db->beginTransaction();
    
    foreach ($users as $username => $data) {
        // Generate bcrypt hash
        $passwordHash = password_hash($data['password'], PASSWORD_BCRYPT);
        
        // Update user
        $stmt = $db->prepare("
            UPDATE users 
            SET password_hash = ?,
                updated_at = NOW()
            WHERE username = ?
        ");
        
        $stmt->execute([$passwordHash, $username]);
        
        echo "✓ Updated password for user: {$username} ({$data['role']})\n";
        echo "  Password: {$data['password']}\n";
        echo "  Hash: " . substr($passwordHash, 0, 30) . "...\n\n";
    }
    
    $db->commit();
    
    echo "═══════════════════════════════════════════════════════════════════════\n";
    echo "SUCCESS - All passwords updated to bcrypt\n";
    echo "═══════════════════════════════════════════════════════════════════════\n\n";
    
    echo "DEMO LOGIN CREDENTIALS:\n";
    echo "───────────────────────────────────────────────────────────────────────\n";
    echo "Admin:    username: admin    | password: admin123\n";
    echo "Manager:  username: manager  | password: manager123\n";
    echo "Staff:    username: staff    | password: staff123\n";
    echo "───────────────────────────────────────────────────────────────────────\n\n";
    
    echo "⚠ IMPORTANT FOR PRODUCTION:\n";
    echo "  1. Change these passwords immediately after deployment\n";
    echo "  2. Enable password complexity requirements\n";
    echo "  3. Implement password expiration policy\n";
    echo "  4. Enable two-factor authentication if needed\n\n";
    
    // Verify passwords work
    echo "VERIFICATION:\n";
    echo "───────────────────────────────────────────────────────────────────────\n";
    $stmt = $db->query("SELECT username, password_hash FROM users");
    while ($row = $stmt->fetch()) {
        $testPassword = $users[$row['username']]['password'];
        $verified = password_verify($testPassword, $row['password_hash']);
        echo ($verified ? "✓" : "✗") . " {$row['username']}: " . ($verified ? "Password verified" : "Verification FAILED") . "\n";
    }
    
} catch (Exception $e) {
    $db->rollBack();
    echo "✗ ERROR: " . $e->getMessage() . "\n";
    exit(1);
}

echo "\n";
echo "═══════════════════════════════════════════════════════════════════════\n";
echo "PASSWORD FIX COMPLETE\n";
echo "═══════════════════════════════════════════════════════════════════════\n";
