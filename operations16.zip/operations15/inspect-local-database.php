<?php
/**
 * Inspect Local Database for Stock Transfer
 */

require_once 'includes/auth.php';

$db = getDB();

echo "=================================================\n";
echo "  LOCAL DATABASE INSPECTION\n";
echo "=================================================\n\n";

echo "Database: " . DB_NAME . "\n";
echo "Host: " . DB_HOST . "\n";
echo "User: " . DB_USER . "\n\n";

// Check stock_transfers table
echo "STOCK_TRANSFERS TABLE\n";
echo "-------------------------------------------------\n";
$stmt = $db->query("DESCRIBE stock_transfers");
$columns = $stmt->fetchAll();
foreach ($columns as $col) {
    $key = $col['Key'] === 'PRI' ? ' [PRIMARY KEY]' : '';
    echo "  " . $col['Field'] . " (" . $col['Type'] . ")" . $key . "\n";
}

// Count transfers
$stmt = $db->query("SELECT COUNT(*) as count FROM stock_transfers");
$count = $stmt->fetch()['count'];
echo "\nTotal transfers: $count\n";

// Show sample
if ($count > 0) {
    $stmt = $db->query("SELECT id, data FROM stock_transfers LIMIT 1");
    $row = $stmt->fetch();
    $data = json_decode($row['data'], true);
    
    echo "\nSample transfer:\n";
    echo "  Database ID: " . $row['id'] . "\n";
    echo "  Transfer Number: " . ($data['transferNumber'] ?? 'N/A') . "\n";
    echo "  Status: " . ($data['status'] ?? 'N/A') . "\n";
}

echo "\n";

// Check locations
echo "LOCATIONS TABLE\n";
echo "-------------------------------------------------\n";
$stmt = $db->query("SELECT COUNT(*) as count FROM locations");
$count = $stmt->fetch()['count'];
echo "Total locations: $count\n";

if ($count > 0) {
    $stmt = $db->query("SELECT id, data FROM locations LIMIT 3");
    while ($row = $stmt->fetch()) {
        $data = json_decode($row['data'], true);
        echo "  • " . $row['id'] . " - " . ($data['name'] ?? 'N/A') . "\n";
    }
}

echo "\n";

// Check products
echo "PRODUCTS TABLE\n";
echo "-------------------------------------------------\n";
$stmt = $db->query("SELECT COUNT(*) as count FROM products");
$count = $stmt->fetch()['count'];
echo "Total products: $count\n";

echo "\n";

// Check inventory
echo "INVENTORY_LOCATIONS TABLE\n";
echo "-------------------------------------------------\n";
$stmt = $db->query("SELECT COUNT(*) as count FROM inventory_locations");
$count = $stmt->fetch()['count'];
echo "Total inventory records: $count\n";

echo "\n";

// Check POD table
echo "PROOF_OF_DELIVERY TABLE\n";
echo "-------------------------------------------------\n";
$stmt = $db->query("DESCRIBE proof_of_delivery");
$columns = $stmt->fetchAll();
foreach ($columns as $col) {
    $key = $col['Key'] === 'PRI' ? ' [PRIMARY KEY]' : '';
    echo "  " . $col['Field'] . " (" . $col['Type'] . ")" . $key . "\n";
}

$stmt = $db->query("SELECT COUNT(*) as count FROM proof_of_delivery");
$count = $stmt->fetch()['count'];
echo "\nTotal POD records: $count\n";

echo "\n=================================================\n";
echo "           INSPECTION COMPLETE\n";
echo "=================================================\n\n";

echo "Summary:\n";
echo "  ✓ Local database: " . DB_NAME . "\n";
echo "  ✓ Using localhost connection\n";
echo "  ✓ All required tables exist\n";
echo "  ✓ Ready for local stock transfer operations\n\n";
