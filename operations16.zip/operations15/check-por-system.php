<?php
/**
 * Check POR System Status
 */

require_once 'config/database.php';

header('Content-Type: text/html; charset=utf-8');

echo "<!DOCTYPE html>
<html>
<head>
    <title>POR System Check</title>
    <style>
        body { font-family: Arial, sans-serif; padding: 20px; background: #f5f5f5; }
        .success { color: #10B981; font-weight: bold; }
        .error { color: #EF4444; font-weight: bold; }
        .info { color: #3B82F6; }
        .section { background: white; padding: 20px; margin: 20px 0; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
        table { width: 100%; border-collapse: collapse; margin: 10px 0; }
        th, td { padding: 10px; text-align: left; border-bottom: 1px solid #ddd; }
        th { background: #f9f9f9; font-weight: bold; }
    </style>
</head>
<body>";

echo "<h1>🔍 POR System Status Check</h1>\n";

try {
    $db = getDB();
    
    // Check if proof_of_receiving table exists
    echo "<div class='section'>";
    echo "<h2>1. Database Table</h2>\n";
    $stmt = $db->query("SHOW TABLES LIKE 'proof_of_receiving'");
    if ($stmt->rowCount() > 0) {
        echo "<p class='success'>✓ proof_of_receiving table exists</p>\n";
        
        // Get table structure
        $columns = $db->query("DESCRIBE proof_of_receiving")->fetchAll(PDO::FETCH_ASSOC);
        echo "<h3>Table Structure:</h3>\n";
        echo "<table><tr><th>Column</th><th>Type</th><th>Null</th><th>Key</th></tr>";
        foreach ($columns as $col) {
            echo "<tr><td>{$col['Field']}</td><td>{$col['Type']}</td><td>{$col['Null']}</td><td>{$col['Key']}</td></tr>";
        }
        echo "</table>\n";
    } else {
        echo "<p class='error'>✗ proof_of_receiving table does not exist</p>\n";
    }
    echo "</div>";
    
    // Check if proof_of_receiving_items table exists
    echo "<div class='section'>";
    echo "<h2>2. POR Items Table</h2>\n";
    $stmt = $db->query("SHOW TABLES LIKE 'proof_of_receiving_items'");
    if ($stmt->rowCount() > 0) {
        echo "<p class='success'>✓ proof_of_receiving_items table exists</p>\n";
    } else {
        echo "<p class='error'>✗ proof_of_receiving_items table does not exist</p>\n";
    }
    echo "</div>";
    
    // Check POR records
    echo "<div class='section'>";
    echo "<h2>3. POR Records</h2>\n";
    $count = $db->query("SELECT COUNT(*) FROM proof_of_receiving")->fetchColumn();
    echo "<p class='info'>Total POR records: <strong>{$count}</strong></p>\n";
    
    if ($count > 0) {
        $recent = $db->query("SELECT * FROM proof_of_receiving ORDER BY created_at DESC LIMIT 5")->fetchAll(PDO::FETCH_ASSOC);
        echo "<h3>Recent POR Records:</h3>\n";
        echo "<table><tr><th>POR #</th><th>PO #</th><th>Supplier</th><th>Status</th><th>Created</th></tr>";
        foreach ($recent as $por) {
            echo "<tr>
                <td>{$por['por_number']}</td>
                <td>{$por['po_number']}</td>
                <td>{$por['supplier_name']}</td>
                <td>{$por['inspection_status']}</td>
                <td>{$por['created_at']}</td>
            </tr>";
        }
        echo "</table>\n";
    }
    echo "</div>";
    
    // Check POR API
    echo "<div class='section'>";
    echo "<h2>4. POR API</h2>\n";
    if (file_exists('api/por.php')) {
        echo "<p class='success'>✓ api/por.php exists</p>\n";
    } else {
        echo "<p class='error'>✗ api/por.php missing</p>\n";
    }
    echo "</div>";
    
    // Check POR Module
    echo "<div class='section'>";
    echo "<h2>5. POR Module Files</h2>\n";
    if (file_exists('modules/por/index.js')) {
        echo "<p class='success'>✓ modules/por/index.js exists</p>\n";
    } else {
        echo "<p class='error'>✗ modules/por/index.js missing</p>\n";
    }
    echo "</div>";
    
    // Check available receivings for POR creation
    echo "<div class='section'>";
    echo "<h2>6. Available Receivings (for POR creation)</h2>\n";
    $availableReceivings = $db->query("
        SELECT r.id, r.data, r.received_date
        FROM receivings r
        LEFT JOIN proof_of_receiving por ON por.receiving_id = r.id
        WHERE por.id IS NULL
        ORDER BY r.received_date DESC
        LIMIT 10
    ")->fetchAll(PDO::FETCH_ASSOC);
    
    echo "<p class='info'>Receivings without POR: <strong>" . count($availableReceivings) . "</strong></p>\n";
    
    if (count($availableReceivings) > 0) {
        echo "<table><tr><th>Receiving ID</th><th>Receiving #</th><th>PO #</th><th>Date</th></tr>";
        foreach ($availableReceivings as $rec) {
            $data = json_decode($rec['data'], true);
            echo "<tr>
                <td>{$rec['id']}</td>
                <td>" . ($data['receivingNumber'] ?? 'N/A') . "</td>
                <td>" . ($data['poNumber'] ?? 'N/A') . "</td>
                <td>{$rec['received_date']}</td>
            </tr>";
        }
        echo "</table>\n";
    }
    echo "</div>";
    
    // Overall Status
    echo "<div class='section'>";
    echo "<h2>✅ System Status</h2>\n";
    $tableExists = $db->query("SHOW TABLES LIKE 'proof_of_receiving'")->rowCount() > 0;
    $apiExists = file_exists('api/por.php');
    $moduleExists = file_exists('modules/por/index.js');
    
    if ($tableExists && $apiExists && $moduleExists) {
        echo "<p class='success'>🎉 POR System is fully operational!</p>\n";
        echo "<p>Navigate to: <a href='dashboard.php'>Dashboard</a> → Click 'Proof of Receiving' in sidebar</p>\n";
    } else {
        echo "<p class='error'>⚠️ Some components are missing. System may not work correctly.</p>\n";
    }
    echo "</div>";
    
} catch (Exception $e) {
    echo "<div class='section'>";
    echo "<p class='error'>❌ ERROR: " . htmlspecialchars($e->getMessage()) . "</p>\n";
    echo "</div>";
}

echo "</body></html>";
?>
