<?php
/**
 * AUDIT REPORTS MODULE
 * Test all report endpoints and verify data accuracy
 */

require_once 'config/database.php';
require_once 'includes/functions.php';

$db = getDB();

echo "═══════════════════════════════════════════════════════════════════════\n";
echo "REPORTS MODULE AUDIT\n";
echo "═══════════════════════════════════════════════════════════════════════\n\n";

// Helper function to get collection data
function getCollectionData($db, $collection) {
    try {
        $stmt = $db->prepare("SELECT data FROM $collection");
        $stmt->execute();
        $results = $stmt->fetchAll(PDO::FETCH_COLUMN);
        return array_map(function($r) {
            return json_decode($r, true);
        }, array_filter($results, fn($r) => !empty($r)));
    } catch (Exception $e) {
        return [];
    }
}

// TEST 1: Workflow Summary Report
echo "TEST 1: WORKFLOW SUMMARY REPORT\n";
echo "───────────────────────────────────────────────────────────────────────\n";

$pos = getCollectionData($db, 'purchase_orders');
$receivings = getCollectionData($db, 'receivings');
$movements = getCollectionData($db, 'inventory_movements');

$completedPOs = array_filter($pos, fn($po) => ($po['status'] ?? '') === 'Fully Received');
$partialPOs = array_filter($pos, fn($po) => ($po['status'] ?? '') === 'Partially Received');
$pendingPOs = array_filter($pos, fn($po) => in_array($po['status'] ?? '', ['Approved', 'Pending']));

echo "Total POs: " . count($pos) . "\n";
echo "Completed POs: " . count($completedPOs) . "\n";
echo "Partial POs: " . count($partialPOs) . "\n";
echo "Pending POs: " . count($pendingPOs) . "\n";
echo "Total Receivings: " . count($receivings) . "\n";
echo "Total Movements: " . count($movements) . "\n";

$totalPOValue = array_sum(array_map(fn($po) => floatval($po['total'] ?? 0), $pos));
echo "Total PO Value: ₱" . number_format($totalPOValue, 2) . "\n";

echo "\n";

// TEST 2: Inventory Metrics
echo "TEST 2: INVENTORY METRICS\n";
echo "───────────────────────────────────────────────────────────────────────\n";

$products = getCollectionData($db, 'products');

$totalProducts = count($products);
$totalStock = array_sum(array_map(fn($p) => floatval($p['stock'] ?? 0), $products));

// Calculate low stock and out of stock
$lowStock = 0;
$outOfStock = 0;
$totalValue = 0;

foreach ($products as $product) {
    $stock = floatval($product['stock'] ?? 0);
    $minStock = floatval($product['minimumStock'] ?? 10);
    $price = floatval($product['costingPrice'] ?? 0);
    
    if ($stock === 0) {
        $outOfStock++;
    } elseif ($stock < $minStock) {
        $lowStock++;
    }
    
    $totalValue += $stock * $price;
}

$stockIn = array_filter($movements, fn($m) => ($m['type'] ?? '') === 'Stock In');
$stockOut = array_filter($movements, fn($m) => ($m['type'] ?? '') === 'Stock Out');
$adjustments = array_filter($movements, fn($m) => ($m['type'] ?? '') === 'Adjustment');

echo "Total Products: {$totalProducts}\n";
echo "Total Stock: {$totalStock} units\n";
echo "Total Inventory Value: ₱" . number_format($totalValue, 2) . "\n";
echo "Low Stock Products: {$lowStock}\n";
echo "Out of Stock Products: {$outOfStock}\n";
echo "Stock In Movements: " . count($stockIn) . "\n";
echo "Stock Out Movements: " . count($stockOut) . "\n";
echo "Adjustment Movements: " . count($adjustments) . "\n";

echo "\n";

// TEST 3: Movement Type Breakdown
echo "TEST 3: INVENTORY MOVEMENT BREAKDOWN\n";
echo "───────────────────────────────────────────────────────────────────────\n";

$movementsByType = [];
$movementsByReference = [];

foreach ($movements as $mov) {
    $type = $mov['type'] ?? 'Unknown';
    $refType = $mov['referenceType'] ?? 'Unknown';
    
    if (!isset($movementsByType[$type])) {
        $movementsByType[$type] = 0;
    }
    $movementsByType[$type]++;
    
    if (!isset($movementsByReference[$refType])) {
        $movementsByReference[$refType] = 0;
    }
    $movementsByReference[$refType]++;
}

echo "BY MOVEMENT TYPE:\n";
foreach ($movementsByType as $type => $count) {
    echo "  {$type}: {$count}\n";
}

echo "\nBY REFERENCE TYPE:\n";
foreach ($movementsByReference as $refType => $count) {
    echo "  {$refType}: {$count}\n";
}

echo "\n";

// TEST 4: Stock Transfer Statistics
echo "TEST 4: STOCK TRANSFER STATISTICS\n";
echo "───────────────────────────────────────────────────────────────────────\n";

$transfers = getCollectionData($db, 'stock_transfers');

$transfersByStatus = [];
foreach ($transfers as $transfer) {
    $status = $transfer['status'] ?? 'Unknown';
    if (!isset($transfersByStatus[$status])) {
        $transfersByStatus[$status] = 0;
    }
    $transfersByStatus[$status]++;
}

echo "Total Transfers: " . count($transfers) . "\n";
echo "BY STATUS:\n";
foreach ($transfersByStatus as $status => $count) {
    echo "  {$status}: {$count}\n";
}

// Check transfer proofs
$proofCount = $db->query("SELECT COUNT(*) FROM transfer_proof")->fetchColumn();
$proofItemCount = $db->query("SELECT COUNT(*) FROM transfer_proof_items")->fetchColumn();

echo "\nTransfer Proofs: {$proofCount}\n";
echo "Transfer Proof Items: {$proofItemCount}\n";
echo "Transfers with Proof: {$proofCount}/" . count($transfers) . "\n";

echo "\n";

// TEST 5: POR Statistics
echo "TEST 5: PROOF OF RECEIVING STATISTICS\n";
echo "───────────────────────────────────────────────────────────────────────\n";

$pors = $db->query("SELECT * FROM proof_of_receiving")->fetchAll();
$porItems = $db->query("SELECT * FROM proof_of_receiving_items")->fetchAll();

$porsByStatus = [];
$porsByInspection = [];

foreach ($pors as $por) {
    $status = $por['status'];
    $inspection = $por['inspection_status'];
    
    if (!isset($porsByStatus[$status])) {
        $porsByStatus[$status] = 0;
    }
    $porsByStatus[$status]++;
    
    if (!isset($porsByInspection[$inspection])) {
        $porsByInspection[$inspection] = 0;
    }
    $porsByInspection[$inspection]++;
}

echo "Total PORs: " . count($pors) . "\n";
echo "Total POR Items: " . count($porItems) . "\n";

echo "\nBY STATUS:\n";
foreach ($porsByStatus as $status => $count) {
    echo "  {$status}: {$count}\n";
}

echo "\nBY INSPECTION:\n";
foreach ($porsByInspection as $inspection => $count) {
    echo "  {$inspection}: {$count}\n";
}

// Calculate acceptance rate
$totalAccepted = 0;
$totalReceived = 0;

foreach ($porItems as $item) {
    $totalAccepted += floatval($item['accepted_quantity']);
    $totalReceived += floatval($item['received_quantity']);
}

$acceptanceRate = $totalReceived > 0 ? round($totalAccepted / $totalReceived * 100, 2) : 0;
echo "\nAcceptance Rate: {$acceptanceRate}% ({$totalAccepted} accepted / {$totalReceived} received)\n";

echo "\n";

// TEST 6: Location Statistics
echo "TEST 6: LOCATION STATISTICS\n";
echo "───────────────────────────────────────────────────────────────────────\n";

$locations = getCollectionData($db, 'locations');

echo "Total Locations: " . count($locations) . "\n";
foreach ($locations as $location) {
    echo "  {$location['code']}: {$location['name']} ({$location['type']})\n";
}

// Count transfers by location
$transfersByLocation = [];
foreach ($transfers as $transfer) {
    $from = $transfer['fromLocation'] ?? 'Unknown';
    $to = $transfer['toLocation'] ?? 'Unknown';
    $route = "{$from} → {$to}";
    
    if (!isset($transfersByLocation[$route])) {
        $transfersByLocation[$route] = 0;
    }
    $transfersByLocation[$route]++;
}

echo "\nTransfers by Route:\n";
foreach ($transfersByLocation as $route => $count) {
    echo "  {$route}: {$count} transfers\n";
}

echo "\n";

// TEST 7: User Activity
echo "TEST 7: USER ACTIVITY STATISTICS\n";
echo "───────────────────────────────────────────────────────────────────────\n";

$users = $db->query("SELECT id, username, role FROM users")->fetchAll();
$securityLogs = $db->query("SELECT * FROM security_logs ORDER BY created_at DESC LIMIT 100")->fetchAll();

echo "Total Users: " . count($users) . "\n";
foreach ($users as $user) {
    echo "  {$user['username']}: {$user['role']}\n";
}

$logsByAction = [];
foreach ($securityLogs as $log) {
    $action = $log['action'];
    if (!isset($logsByAction[$action])) {
        $logsByAction[$action] = 0;
    }
    $logsByAction[$action]++;
}

echo "\nRecent Security Events (last 100):\n";
foreach ($logsByAction as $action => $count) {
    echo "  {$action}: {$count}\n";
}

echo "\n";

// SUMMARY
echo "═══════════════════════════════════════════════════════════════════════\n";
echo "REPORT SUMMARY\n";
echo "═══════════════════════════════════════════════════════════════════════\n";

echo "Data Availability:\n";
echo "  Products: ✓ ({$totalProducts} products)\n";
echo "  Purchase Orders: ✓ (" . count($pos) . " POs)\n";
echo "  Receivings: ✓ (" . count($receivings) . " receivings)\n";
echo "  PORs: ✓ (" . count($pors) . " PORs)\n";
echo "  Inventory Movements: ✓ (" . count($movements) . " movements)\n";
echo "  Stock Transfers: ✓ (" . count($transfers) . " transfers)\n";
echo "  Transfer Proofs: " . ($proofCount > 0 ? "✓" : "⚠") . " ({$proofCount} proofs)\n";
echo "  Locations: ✓ (" . count($locations) . " locations)\n";
echo "  Users: ✓ (" . count($users) . " users)\n";

echo "\nReport Capabilities:\n";
echo "  ✓ Workflow Summary (PO, Receiving, Movements)\n";
echo "  ✓ Inventory Metrics (Stock levels, Value, Low stock)\n";
echo "  ✓ Movement Analysis (Types, Reference tracking)\n";
echo "  ✓ Transfer Statistics (Status, Proofs, Routes)\n";
echo "  ✓ POR Analysis (Inspection, Acceptance rates)\n";
echo "  ✓ Location Tracking (Transfer routes)\n";
echo "  ✓ User Activity (Security logs)\n";

echo "\nData Quality:\n";
$quality = [];

// Check PO completeness
$posWithTotal = array_filter($pos, fn($po) => isset($po['total']) && $po['total'] > 0);
$quality[] = [
    'metric' => 'POs with Total Value',
    'value' => count($posWithTotal) . '/' . count($pos),
    'percentage' => count($pos) > 0 ? round(count($posWithTotal) / count($pos) * 100, 1) : 0
];

// Check movements with reference
$movementsWithRef = array_filter($movements, fn($m) => isset($m['referenceType']) && isset($m['referenceId']));
$quality[] = [
    'metric' => 'Movements with Reference',
    'value' => count($movementsWithRef) . '/' . count($movements),
    'percentage' => count($movements) > 0 ? round(count($movementsWithRef) / count($movements) * 100, 1) : 0
];

// Check transfers with locations
$transfersWithLocations = array_filter($transfers, fn($t) => isset($t['fromLocation']) && isset($t['toLocation']));
$quality[] = [
    'metric' => 'Transfers with Locations',
    'value' => count($transfersWithLocations) . '/' . count($transfers),
    'percentage' => count($transfers) > 0 ? round(count($transfersWithLocations) / count($transfers) * 100, 1) : 0
];

// Check PORs with inventory updated
$completedPORs = array_filter($pors, fn($por) => $por['status'] === 'Completed');
$updatedInventory = array_filter($completedPORs, fn($por) => $por['inventory_updated'] == 1);
$quality[] = [
    'metric' => 'Completed PORs with Inventory',
    'value' => count($updatedInventory) . '/' . count($completedPORs),
    'percentage' => count($completedPORs) > 0 ? round(count($updatedInventory) / count($completedPORs) * 100, 1) : 0
];

foreach ($quality as $q) {
    $status = $q['percentage'] >= 90 ? '✓' : ($q['percentage'] >= 70 ? '⚠' : '✗');
    echo "  {$status} {$q['metric']}: {$q['value']} ({$q['percentage']}%)\n";
}

echo "\n";
echo "═══════════════════════════════════════════════════════════════════════\n";
echo "AUDIT COMPLETE\n";
echo "═══════════════════════════════════════════════════════════════════════\n";
