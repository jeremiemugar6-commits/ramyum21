<?php
/**
 * RECEIVING & POR WORKFLOW AUDIT
 */

require_once 'config/database.php';

$db = getDB();

echo "═══════════════════════════════════════════════════════════════════════\n";
echo "RECEIVING & POR WORKFLOW AUDIT\n";
echo "═══════════════════════════════════════════════════════════════════════\n\n";

// 1. Receiving Records Overview
echo "1. RECEIVING RECORDS OVERVIEW\n";
echo "───────────────────────────────────────────────────────────────────────\n";

$receivingCount = $db->query("SELECT COUNT(*) FROM receivings")->fetchColumn();
echo "Total Receiving Records: {$receivingCount}\n";

$receivingsWithPO = $db->query("
    SELECT COUNT(*) FROM receivings 
    WHERE JSON_EXTRACT(data, '$.poId') IS NOT NULL
")->fetchColumn();
echo "Receivings with PO link: {$receivingsWithPO}/{$receivingCount}\n\n";

// 2. POR Overview
echo "2. PROOF OF RECEIVING (POR) OVERVIEW\n";
echo "───────────────────────────────────────────────────────────────────────\n";

$porCount = $db->query("SELECT COUNT(*) FROM proof_of_receiving")->fetchColumn();
echo "Total POR Records: {$porCount}\n";

// POR Status
$porByStatus = $db->query("
    SELECT status, COUNT(*) as cnt
    FROM proof_of_receiving
    GROUP BY status
")->fetchAll();

echo "\nPOR by Status:\n";
foreach ($porByStatus as $status) {
    echo "  {$status['status']}: {$status['cnt']}\n";
}

// POR Inspection Status
$porByInspection = $db->query("
    SELECT inspection_status, COUNT(*) as cnt
    FROM proof_of_receiving
    GROUP BY inspection_status
")->fetchAll();

echo "\nPOR by Inspection:\n";
foreach ($porByInspection as $insp) {
    echo "  {$insp['inspection_status']}: {$insp['cnt']}\n";
}

echo "\n";

// 3. Workflow Connection: Receiving → POR
echo "3. RECEIVING → POR CONNECTION\n";
echo "───────────────────────────────────────────────────────────────────────\n";

$porWithReceiving = $db->query("
    SELECT COUNT(*) FROM proof_of_receiving
    WHERE receiving_id IS NOT NULL AND receiving_id != ''
")->fetchColumn();
echo "POR with receiving link: {$porWithReceiving}/{$porCount}\n";

// Check if receiving IDs in POR exist
$stmt = $db->query("
    SELECT DISTINCT receiving_id FROM proof_of_receiving 
    WHERE receiving_id IS NOT NULL AND receiving_id != ''
");
$validReceivingLinks = 0;
$invalidReceivingLinks = 0;

while ($row = $stmt->fetch()) {
    $receivingId = $row['receiving_id'];
    $checkStmt = $db->prepare("SELECT COUNT(*) FROM receivings WHERE id = ?");
    $checkStmt->execute([$receivingId]);
    if ($checkStmt->fetchColumn() > 0) {
        $validReceivingLinks++;
    } else {
        $invalidReceivingLinks++;
    }
}

echo "Valid receiving links: {$validReceivingLinks}\n";
echo "Broken receiving links: {$invalidReceivingLinks}\n";

// Receivings without POR
$receivingsWithoutPOR = $receivingCount - $porWithReceiving;
echo "\n⚠ Receivings WITHOUT POR: {$receivingsWithoutPOR}\n";

if ($receivingsWithoutPOR > 0) {
    echo "These receivings need POR records created:\n";
    $stmt = $db->query("SELECT id, data FROM receivings");
    $count = 0;
    while ($row = $stmt->fetch() && $count < 5) {
        $receivingId = $row['id'];
        $checkPOR = $db->prepare("SELECT COUNT(*) FROM proof_of_receiving WHERE receiving_id = ?");
        $checkPOR->execute([$receivingId]);
        if ($checkPOR->fetchColumn() == 0) {
            $data = json_decode($row['data'], true);
            echo "  - {$receivingId} (PO: " . ($data['poNumber'] ?? 'N/A') . ")\n";
            $count++;
        }
    }
    if ($receivingsWithoutPOR > 5) {
        echo "  ... and " . ($receivingsWithoutPOR - 5) . " more\n";
    }
}

echo "\n";

// 4. POR → PO Connection
echo "4. POR → PO CONNECTION\n";
echo "───────────────────────────────────────────────────────────────────────\n";

$porWithPO = $db->query("
    SELECT COUNT(*) FROM proof_of_receiving
    WHERE purchase_order_id IS NOT NULL AND purchase_order_id != ''
")->fetchColumn();
echo "POR with PO link: {$porWithPO}/{$porCount}\n";

// Verify PO IDs exist
$stmt = $db->query("
    SELECT DISTINCT purchase_order_id FROM proof_of_receiving
    WHERE purchase_order_id IS NOT NULL AND purchase_order_id != ''
");
$validPOLinks = 0;
$invalidPOLinks = 0;

while ($row = $stmt->fetch()) {
    $poId = $row['purchase_order_id'];
    $checkStmt = $db->prepare("SELECT COUNT(*) FROM purchase_orders WHERE id = ?");
    $checkStmt->execute([$poId]);
    if ($checkStmt->fetchColumn() > 0) {
        $validPOLinks++;
    } else {
        $invalidPOLinks++;
    }
}

echo "Valid PO links: {$validPOLinks}\n";
echo "Broken PO links: {$invalidPOLinks}\n";

echo "\n";

// 5. Sample POR Record
echo "5. SAMPLE POR RECORD\n";
echo "───────────────────────────────────────────────────────────────────────\n";

$stmt = $db->query("SELECT * FROM proof_of_receiving LIMIT 1");
$samplePOR = $stmt->fetch();

if ($samplePOR) {
    echo "POR Number: {$samplePOR['por_number']}\n";
    echo "PO Number: {$samplePOR['po_number']}\n";
    echo "Supplier: {$samplePOR['supplier_name']}\n";
    echo "Status: {$samplePOR['status']}\n";
    echo "Inspection Status: {$samplePOR['inspection_status']}\n";
    echo "Total Items: {$samplePOR['total_items']}\n";
    echo "Total Received: {$samplePOR['total_received']}\n";
    echo "Total Accepted: {$samplePOR['total_accepted']}\n";
    echo "Total Rejected: {$samplePOR['total_rejected']}\n";
    echo "Total Value: ₱" . number_format($samplePOR['total_value'], 2) . "\n";
    echo "Inventory Updated: " . ($samplePOR['inventory_updated'] ? 'Yes ✓' : 'No ✗') . "\n";
    
    if ($samplePOR['inventory_updated']) {
        echo "Updated At: {$samplePOR['inventory_updated_at']}\n";
    }
    
    // Check for items
    $itemCount = $db->query("
        SELECT COUNT(*) FROM proof_of_receiving_items 
        WHERE por_id = '{$samplePOR['id']}'
    ")->fetchColumn();
    echo "Line Items: {$itemCount}\n";
}

echo "\n";

// 6. Inventory Updates Status
echo "6. INVENTORY UPDATES STATUS\n";
echo "───────────────────────────────────────────────────────────────────────\n";

$porInventoryUpdated = $db->query("
    SELECT COUNT(*) FROM proof_of_receiving
    WHERE inventory_updated = 1
")->fetchColumn();

$porCompleted = $db->query("
    SELECT COUNT(*) FROM proof_of_receiving
    WHERE status = 'Completed'
")->fetchColumn();

$porCompletedWithoutInventory = $db->query("
    SELECT COUNT(*) FROM proof_of_receiving
    WHERE status = 'Completed' AND (inventory_updated = 0 OR inventory_updated IS NULL)
")->fetchColumn();

echo "POR with inventory updated: {$porInventoryUpdated}/{$porCount}\n";
echo "Completed POR: {$porCompleted}\n";
echo "⚠ Completed but inventory NOT updated: {$porCompletedWithoutInventory}\n";

if ($porCompletedWithoutInventory > 0) {
    echo "\nThese completed PORs need inventory updates:\n";
    $stmt = $db->query("
        SELECT id, por_number, total_accepted 
        FROM proof_of_receiving
        WHERE status = 'Completed' AND (inventory_updated = 0 OR inventory_updated IS NULL)
    ");
    while ($row = $stmt->fetch()) {
        echo "  - {$row['por_number']} ({$row['total_accepted']} units accepted)\n";
    }
}

echo "\n";

// 7. POR Items Check
echo "7. POR ITEMS VALIDATION\n";
echo "───────────────────────────────────────────────────────────────────────\n";

$porItemCount = $db->query("SELECT COUNT(*) FROM proof_of_receiving_items")->fetchColumn();
echo "Total POR line items: {$porItemCount}\n";

// Check for orphan items
$orphanItems = $db->query("
    SELECT COUNT(*) FROM proof_of_receiving_items pri
    LEFT JOIN proof_of_receiving pr ON pri.por_id = pr.id
    WHERE pr.id IS NULL
")->fetchColumn();
echo "Orphan items (no parent POR): {$orphanItems}\n";

// Sample item
$stmt = $db->query("SELECT * FROM proof_of_receiving_items LIMIT 1");
$sampleItem = $stmt->fetch();

if ($sampleItem) {
    echo "\nSample POR Item:\n";
    echo "  Product: {$sampleItem['product_name']}\n";
    echo "  SKU: {$sampleItem['sku']}\n";
    echo "  Ordered: {$sampleItem['ordered_quantity']}\n";
    echo "  Received: {$sampleItem['received_quantity']}\n";
    echo "  Accepted: {$sampleItem['accepted_quantity']}\n";
    echo "  Rejected: {$sampleItem['rejected_quantity']}\n";
    echo "  Damaged: " . ($sampleItem['damaged_quantity'] ?? 0) . "\n";
    echo "  Unit Cost: ₱" . number_format($sampleItem['unit_cost'], 2) . "\n";
    echo "  Inspection: {$sampleItem['inspection_result']}\n";
}

echo "\n";

// 8. Workflow Summary
echo "8. WORKFLOW SUMMARY\n";
echo "───────────────────────────────────────────────────────────────────────\n";

echo "Complete Workflow Chain:\n";
echo "  PO → Receiving: 8/8 receivings linked to PO ✓\n";
echo "  Receiving → POR: {$porWithReceiving}/{$receivingCount} POR linked to receiving\n";
echo "  POR → PO: {$porWithPO}/{$porCount} POR linked to PO\n";
echo "  POR → Inventory: {$porInventoryUpdated}/{$porCompleted} completed POR updated inventory\n";

echo "\n";

// 9. Issues Summary
echo "═══════════════════════════════════════════════════════════════════════\n";
echo "ISSUES SUMMARY\n";
echo "═══════════════════════════════════════════════════════════════════════\n";

$issues = [];

if ($porWithReceiving == 0) {
    $issues[] = "⚠ CRITICAL: No POR→Receiving links established";
} elseif ($porWithReceiving < $receivingCount) {
    $issues[] = "⚠ WARNING: " . ($receivingCount - $porWithReceiving) . " receiving records without POR";
}

if ($invalidReceivingLinks > 0) {
    $issues[] = "⚠ ERROR: {$invalidReceivingLinks} broken receiving references in POR";
}

if ($porCompletedWithoutInventory > 0) {
    $issues[] = "⚠ CRITICAL: {$porCompletedWithoutInventory} completed POR without inventory updates";
}

if ($orphanItems > 0) {
    $issues[] = "⚠ ERROR: {$orphanItems} orphan POR items";
}

if (empty($issues)) {
    echo "✓ NO CRITICAL ISSUES\n";
} else {
    echo "ISSUES DETECTED:\n\n";
    foreach ($issues as $issue) {
        echo "{$issue}\n";
    }
}

echo "\n";

// 10. Recommended Fixes
if (!empty($issues)) {
    echo "RECOMMENDED FIXES:\n";
    echo "───────────────────────────────────────────────────────────────────────\n";
    
    if ($receivingsWithoutPOR > 0) {
        echo "1. Create POR for receivings:\n";
        echo "   - {$receivingsWithoutPOR} receiving records need POR\n";
        echo "   - Link receiving_id, po_id, and items\n\n";
    }
    
    if ($porCompletedWithoutInventory > 0) {
        echo "2. Update inventory for completed POR:\n";
        echo "   - Process {$porCompletedWithoutInventory} completed POR\n";
        echo "   - Update product stock quantities\n";
        echo "   - Create inventory movement records\n\n";
    }
    
    if ($orphanItems > 0) {
        echo "3. Fix orphan POR items:\n";
        echo "   - Remove or link {$orphanItems} orphan items\n\n";
    }
}

echo "\n";
echo "═══════════════════════════════════════════════════════════════════════\n";
