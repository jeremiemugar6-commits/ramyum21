<?php
/**
 * PRODUCT CATALOG AUDIT
 */

require_once 'config/database.php';

$db = getDB();

echo "═══════════════════════════════════════════════════════════════════════\n";
echo "PRODUCT CATALOG AUDIT\n";
echo "═══════════════════════════════════════════════════════════════════════\n\n";

// 1. Product Count
$productCount = $db->query("SELECT COUNT(*) FROM products")->fetchColumn();
echo "Total Products: {$productCount}\n\n";

// 2. Sample Products
echo "Sample Products:\n";
echo "───────────────────────────────────────────────────────────────────────\n";

$stmt = $db->query("SELECT id, data FROM products LIMIT 5");
while ($row = $stmt->fetch()) {
    $data = json_decode($row['data'], true);
    echo "\nID: {$row['id']}\n";
    echo "  SKU: " . ($data['sku'] ?? 'N/A') . "\n";
    echo "  Name: " . ($data['name'] ?? 'N/A') . "\n";
    echo "  Stock: " . ($data['stock'] ?? 0) . " " . ($data['unit'] ?? 'units') . "\n";
    echo "  Cost Price: ₱" . number_format($data['costPrice'] ?? 0, 2) . "\n";
    echo "  SRP: ₱" . number_format($data['srp'] ?? 0, 2) . "\n";
    echo "  Image: " . (isset($data['image']) ? 'Yes' : 'No') . "\n";
    echo "  Status: " . ($data['status'] ?? 'Active') . "\n";
}

echo "\n";

// 3. Check Required Fields
echo "Field Completeness Check:\n";
echo "───────────────────────────────────────────────────────────────────────\n";

$withSKU = $db->query("SELECT COUNT(*) FROM products WHERE JSON_EXTRACT(data, '$.sku') IS NOT NULL")->fetchColumn();
$withName = $db->query("SELECT COUNT(*) FROM products WHERE JSON_EXTRACT(data, '$.name') IS NOT NULL")->fetchColumn();
$withStock = $db->query("SELECT COUNT(*) FROM products WHERE JSON_EXTRACT(data, '$.stock') IS NOT NULL")->fetchColumn();
$withUnit = $db->query("SELECT COUNT(*) FROM products WHERE JSON_EXTRACT(data, '$.unit') IS NOT NULL")->fetchColumn();
$withCostPrice = $db->query("SELECT COUNT(*) FROM products WHERE JSON_EXTRACT(data, '$.costPrice') IS NOT NULL")->fetchColumn();
$withSRP = $db->query("SELECT COUNT(*) FROM products WHERE JSON_EXTRACT(data, '$.srp') IS NOT NULL")->fetchColumn();
$withImage = $db->query("SELECT COUNT(*) FROM products WHERE JSON_EXTRACT(data, '$.image') IS NOT NULL")->fetchColumn();
$withMinStock = $db->query("SELECT COUNT(*) FROM products WHERE JSON_EXTRACT(data, '$.minStock') IS NOT NULL")->fetchColumn();
$withMaxStock = $db->query("SELECT COUNT(*) FROM products WHERE JSON_EXTRACT(data, '$.maxStock') IS NOT NULL")->fetchColumn();

echo "✓ With SKU: {$withSKU}/{$productCount}\n";
echo "✓ With Name: {$withName}/{$productCount}\n";
echo "✓ With Stock: {$withStock}/{$productCount}\n";
echo "✓ With Unit: {$withUnit}/{$productCount}\n";
echo "✓ With Cost Price: {$withCostPrice}/{$productCount}\n";
echo "✓ With SRP: {$withSRP}/{$productCount}\n";
echo "✓ With Image: {$withImage}/{$productCount}\n";
echo "✓ With Min Stock: {$withMinStock}/{$productCount}\n";
echo "✓ With Max Stock: {$withMaxStock}/{$productCount}\n";

echo "\n";

// 4. Check Units of Measure
echo "Units of Measure:\n";
echo "───────────────────────────────────────────────────────────────────────\n";

$units = $db->query("
    SELECT JSON_EXTRACT(data, '$.unit') as unit, COUNT(*) as cnt
    FROM products
    WHERE JSON_EXTRACT(data, '$.unit') IS NOT NULL
    GROUP BY unit
    ORDER BY cnt DESC
")->fetchAll();

foreach ($units as $unit) {
    $unitName = trim($unit['unit'], '"');
    echo "  {$unitName}: {$unit['cnt']} products\n";
}

echo "\n";

// 5. Stock Status
echo "Stock Status:\n";
echo "───────────────────────────────────────────────────────────────────────\n";

$outOfStock = $db->query("SELECT COUNT(*) FROM products WHERE JSON_EXTRACT(data, '$.stock') = 0")->fetchColumn();
$lowStock = $db->query("
    SELECT COUNT(*) FROM products 
    WHERE JSON_EXTRACT(data, '$.stock') > 0 
    AND JSON_EXTRACT(data, '$.stock') < JSON_EXTRACT(data, '$.minStock')
")->fetchColumn();
$normalStock = $db->query("
    SELECT COUNT(*) FROM products 
    WHERE JSON_EXTRACT(data, '$.stock') >= JSON_EXTRACT(data, '$.minStock')
    AND JSON_EXTRACT(data, '$.stock') <= JSON_EXTRACT(data, '$.maxStock')
")->fetchColumn();
$overStock = $db->query("
    SELECT COUNT(*) FROM products 
    WHERE JSON_EXTRACT(data, '$.stock') > JSON_EXTRACT(data, '$.maxStock')
")->fetchColumn();

echo "  Out of Stock: {$outOfStock}\n";
echo "  Low Stock: {$lowStock}\n";
echo "  Normal Stock: {$normalStock}\n";
echo "  Overstock: {$overStock}\n";

echo "\n";

// 6. Duplicate SKU Check
echo "Duplicate SKU Check:\n";
echo "───────────────────────────────────────────────────────────────────────\n";

$duplicates = $db->query("
    SELECT JSON_EXTRACT(data, '$.sku') as sku, COUNT(*) as cnt
    FROM products
    WHERE JSON_EXTRACT(data, '$.sku') IS NOT NULL
    GROUP BY sku
    HAVING cnt > 1
")->fetchAll();

if (count($duplicates) > 0) {
    echo "⚠ WARNING: " . count($duplicates) . " duplicate SKUs found:\n";
    foreach ($duplicates as $dup) {
        $skuValue = trim($dup['sku'], '"');
        echo "  - SKU {$skuValue}: {$dup['cnt']} occurrences\n";
    }
} else {
    echo "✓ No duplicate SKUs\n";
}

echo "\n";

// 7. Price Validation
echo "Price Validation:\n";
echo "───────────────────────────────────────────────────────────────────────\n";

$zeroCost = $db->query("SELECT COUNT(*) FROM products WHERE JSON_EXTRACT(data, '$.costPrice') = 0")->fetchColumn();
$zeroSRP = $db->query("SELECT COUNT(*) FROM products WHERE JSON_EXTRACT(data, '$.srp') = 0")->fetchColumn();
$srpLessThanCost = $db->query("
    SELECT COUNT(*) FROM products 
    WHERE JSON_EXTRACT(data, '$.srp') < JSON_EXTRACT(data, '$.costPrice')
    AND JSON_EXTRACT(data, '$.srp') > 0
")->fetchColumn();

echo ($zeroCost > 0 ? "⚠" : "✓") . " Products with zero cost price: {$zeroCost}\n";
echo ($zeroSRP > 0 ? "⚠" : "✓") . " Products with zero SRP: {$zeroSRP}\n";
echo ($srpLessThanCost > 0 ? "⚠" : "✓") . " Products with SRP < Cost: {$srpLessThanCost}\n";

echo "\n";

// 8. Image Files Check
echo "Image Files:\n";
echo "───────────────────────────────────────────────────────────────────────\n";

$imageDir = 'assets/images/products';
if (is_dir($imageDir)) {
    $imageFiles = glob($imageDir . '/*');
    echo "✓ Image directory exists: {$imageDir}\n";
    echo "  Files in directory: " . count($imageFiles) . "\n";
} else {
    echo "⚠ Image directory not found: {$imageDir}\n";
}

// Check for broken image references
$brokenImages = 0;
$stmt = $db->query("SELECT id, data FROM products WHERE JSON_EXTRACT(data, '$.image') IS NOT NULL");
while ($row = $stmt->fetch()) {
    $data = json_decode($row['data'], true);
    if (isset($data['image'])) {
        $imagePath = $data['image'];
        if (!file_exists($imagePath)) {
            $brokenImages++;
        }
    }
}

echo ($brokenImages > 0 ? "⚠" : "✓") . " Broken image references: {$brokenImages}\n";

echo "\n";

// Summary
echo "═══════════════════════════════════════════════════════════════════════\n";
echo "PRODUCT CATALOG SUMMARY\n";
echo "═══════════════════════════════════════════════════════════════════════\n";

$issues = [];

if (count($duplicates) > 0) {
    $issues[] = count($duplicates) . " duplicate SKUs";
}
if ($zeroCost > 0) {
    $issues[] = "{$zeroCost} products with zero cost price";
}
if ($srpLessThanCost > 0) {
    $issues[] = "{$srpLessThanCost} products with SRP < Cost";
}
if ($brokenImages > 0) {
    $issues[] = "{$brokenImages} broken image references";
}
if ($withSKU < $productCount) {
    $issues[] = ($productCount - $withSKU) . " products without SKU";
}

if (empty($issues)) {
    echo "✓ NO CRITICAL ISSUES\n";
    echo "  Product catalog is in good condition\n";
} else {
    echo "⚠ ISSUES DETECTED:\n";
    foreach ($issues as $issue) {
        echo "  • {$issue}\n";
    }
}

echo "\n";
echo "═══════════════════════════════════════════════════════════════════════\n";
