-- =====================================================================
-- Safe additive migration: batch/expiration on damage evidence +
-- inventory lots support without destroying existing data
-- Includes manufacturing_date (start of shelf life) alongside expiration_date (end)
-- =====================================================================

-- 1. Extend damage_evidence with batch / manufacturing / expiration linkage
ALTER TABLE `damage_evidence`
  ADD COLUMN IF NOT EXISTS `batch_number` varchar(100) DEFAULT NULL AFTER `product_name`,
  ADD COLUMN IF NOT EXISTS `manufacturing_date` date DEFAULT NULL AFTER `batch_number`,
  ADD COLUMN IF NOT EXISTS `expiration_date` date DEFAULT NULL AFTER `manufacturing_date`;

-- 2. Inventory lots table (optional multi-batch tracking per product+location)
-- Existing inventory_locations continues to hold aggregated quantity.
-- Lots table holds per-batch/expiration breakdown so different expirations
-- for the same SKU are never overwritten.
CREATE TABLE IF NOT EXISTS `inventory_lots` (
  `id` varchar(40) NOT NULL,
  `product_id` varchar(40) NOT NULL,
  `location_id` varchar(40) NOT NULL,
  `batch_number` varchar(100) DEFAULT NULL,
  `manufacturing_date` date DEFAULT NULL,
  `expiration_date` date DEFAULT NULL,
  `quantity` decimal(12,2) NOT NULL DEFAULT 0.00,
  `reserved_quantity` decimal(12,2) NOT NULL DEFAULT 0.00,
  `unit` varchar(50) DEFAULT 'pcs',
  `receiving_id` varchar(40) DEFAULT NULL,
  `por_id` varchar(40) DEFAULT NULL,
  `source_reference` varchar(100) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_product_location` (`product_id`, `location_id`),
  KEY `idx_batch` (`batch_number`),
  KEY `idx_expiration` (`expiration_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Safe additive: if inventory_lots already exists without manufacturing_date
ALTER TABLE `inventory_lots`
  ADD COLUMN IF NOT EXISTS `manufacturing_date` date DEFAULT NULL AFTER `batch_number`;

-- Note: application code continues to update inventory_locations totals.
-- When receiving with batch/expiration, also insert/update inventory_lots.
