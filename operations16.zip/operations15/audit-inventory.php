<?php
/**
 * INVENTORY MANAGEMENT AUDIT
 */

require_once 'config/database.php';

$db = getDB();

echo "═══════════════════════════════════════════════════════════════════════\n";
echo "INVENTORY MANAGEMENT AUDIT\n";
echo "═══════════════════════════════════════════════════════════════════════\n\n";

// 1. Inventory Movements Overview
echo "1. INVENTORY MOVEMENTS OVERVIEW\n";
echo "───────────────────────────────────────────────────────────────────────\n";

$movementCount = $db->query("SELECT COUNT(*) FROM inventory_movements")->fetchColumn();
echo "Total Inventory Movements: {$movementCount}\n";

// Movement types
$movementTypes = $db->query("
    SELECT JSON_EXTRACT(data, '$.type') as type, COUNT(*) as cnt
    FROM inventory_movements
    WHERE JSON_EXTRACT(data, '$.type') IS NOT NULL
    GROUP BY type
    ORDER BY cnt DESC
")->fetchAll();

echo "\nMovement Types:\n";
foreach ($movementTypes as $type) {
    $typeName = trim($type['type'], '"');
    echo "  {$typeName}: {$type['cnt']}\n";
}

echo "\n";

// 2. Recent Movements
echo "2. RECENT INVENTORY MOVEMENTS\n";
echo "───────────────────────────────────────────────────────────────────────\n";

$recentMovements = $db->query("
    SELECT id, data, created_at 
    FROM inventory_movements 
    ORDER BY created_at DESC 
    LIMIT 5
")->fetchAll();

foreach ($recentMovements as $movement) {
    $data = json_decode($movement['data'], true);
    echo "\nMovement: {$movement['id']}\n";
    echo "  Date: " . ($data['date'] ?? $movement['created_at']) . "\n";
    echo "  Type: " . ($data['type'] ?? 'N/A') . "\n";
    echo "  Product: " . ($data['productName'] ?? 'N/A') . "\n";
    echo "  Quantity: " . ($data['quantity'] ?? 0) . " " . ($data['unit'] ?? '') . "\n";
    echo "  Previous: " . ($data['previousBalance'] ?? 0) . "\n";
    echo "  New: " . ($data['newBalance'] ?? 0) . "\n";
    echo "  Reference: " . ($data['referenceType'] ?? 'N/A') . " - " . ($data['referenceId'] ?? 'N/A') . "\n";
}

echo "\n";

// 3. Product Stock vs Movements Reconciliation
echo "3. STOCK RECONCILIATION CHECK\n";
echo "───────────────────────────────────────────────────────────────────────\n";

// Get sample products with recent movements
$products = $db->query("
    SELECT id, data FROM products 
    ORDER BY updated_at DESC 
    LIMIT 5
")->fetchAll();

$reconciliationIssues = 0;

foreach ($products as $product) {
    $productData = json_decode($product['data'], true);
    $productId = $product['id'];
    $productName = $productData['name'] ?? 'Unknown';
    $currentStock = floatval($productData['stock'] ?? 0);
    
    // Get latest movement for this product
    $movementStmt = $db->prepare("
        SELECT data FROM inventory_movements 
        WHERE JSON_EXTRACT(data, '$.productId') = ?
        ORDER BY created_at DESC 
        LIMIT 1
    ");
    $movementStmt->execute([$productId]);
    $latestMovement = $movementStmt->fetch();
    
    if ($latestMovement) {
        $movementData = json_decode($latestMovement['data'], true);
        $movementBalance = floatval($movementData['newBalance'] ?? 0);
        
        echo "\n{$productName} (SKU: " . ($productData['sku'] ?? 'N/A') . ")\n";
        echo "  Current Stock: {$currentStock}\n";
        echo "  Last Movement Balance: {$movementBalance}\n";
        
        if (abs($currentStock - $movementBalance) > 0.01) {
            echo "  ⚠ MISMATCH: Stock doesn't match movement balance\n";
            $reconciliationIssues++;
        } else {
            echo "  ✓ Reconciled\n";
        }
    }
}

if ($reconciliationIssues > 0) {
    echo "\n⚠ Reconciliation Issues: {$reconciliationIssues}\n";
}

echo "\n";

// 4. Stock Status Summary
echo "4. STOCK STATUS SUMMARY\n";
echo "───────────────────────────────────────────────────────────────────────\n";

$totalProducts = $db->query("SELECT COUNT(*) FROM products")->fetchColumn();

$outOfStock = $db->query("
    SELECT COUNT(*) FROM products 
    WHERE JSON_EXTRACT(data, '$.stock') = 0
")->fetchColumn();

$lowStock = $db->query("
    SELECT COUNT(*) FROM products 
    WHERE JSON_EXTRACT(data, '$.stock') > 0 
    AND JSON_EXTRACT(data, '$.stock') < JSON_EXTRACT(data, '$.minimumStock')
")->fetchColumn();

$normalStock = $db->query("
    SELECT COUNT(*) FROM products 
    WHERE JSON_EXTRACT(data, '$.stock') >= JSON_EXTRACT(data, '$.minimumStock')
    AND JSON_EXTRACT(data, '$.stock') <= JSON_EXTRACT(data, '$.maximumStock')
")->fetchColumn();

$overStock = $db->query("
    SELECT COUNT(*) FROM products 
    WHERE JSON_EXTRACT(data, '$.stock') > JSON_EXTRACT(data, '$.maximumStock')
")->fetchColumn();

echo "Total Products: {$totalProducts}\n";
echo "  Out of Stock: {$outOfStock} (" . round($outOfStock/$totalProducts*100, 1) . "%)\n";
echo "  Low Stock: {$lowStock} (" . round($lowStock/$totalProducts*100, 1) . "%)\n";
echo "  Normal Stock: {$normalStock} (" . round($normalStock/$totalProducts*100, 1) . "%)\n";
echo "  Overstock: {$overStock} (" . round($overStock/$totalProducts*100, 1) . "%)\n";

echo "\n";

// 5. Movement Reference Integrity
echo "5. MOVEMENT REFERENCE INTEGRITY\n";
echo "───────────────────────────────────────────────────────────────────────\n";

// Check different reference types
$referenceTypes = ['POR', 'Stock Transfer', 'Adjustment', 'Return'];

foreach ($referenceTypes as $refType) {
    $count = $db->query("
        SELECT COUNT(*) FROM inventory_movements 
        WHERE JSON_EXTRACT(data, '$.referenceType') = '{$refType}'
    ")->fetchColumn();
    echo "{$refType}: {$count} movements\n";
}

// Check for movements with POR references
$porMovements = $db->query("
    SELECT COUNT(*) FROM inventory_movements 
    WHERE JSON_EXTRACT(data, '$.referenceType') = 'POR'
")->fetchColumn();

$completedPORs = $db->query("
    SELECT COUNT(*) FROM proof_of_receiving 
    WHERE status = 'Completed' AND inventory_updated = 1
")->fetchColumn();

echo "\nPOR Movements vs Completed PORs:\n";
echo "  Inventory movements from POR: {$porMovements}\n";
echo "  Completed PORs with inventory updated: {$completedPORs}\n";

if ($porMovements < $completedPORs) {
    echo "  ⚠ Some PORs may not have created movements\n";
}

echo "\n";

// 6. Product Movement History
echo "6. PRODUCT MOVEMENT HISTORY CHECK\n";
echo "───────────────────────────────────────────────────────────────────────\n";

$productsWithMovements = $db->query("
    SELECT COUNT(DISTINCT JSON_EXTRACT(data, '$.productId')) FROM inventory_movements
    WHERE JSON_EXTRACT(data, '$.productId') IS NOT NULL
")->fetchColumn();

echo "Products with movement history: {$productsWithMovements}/{$totalProducts}\n";
echo "Products without movements: " . ($totalProducts - $productsWithMovements) . "\n";

echo "\n";

// 7. Locations
echo "7. INVENTORY LOCATIONS\n";
echo "───────────────────────────────────────────────────────────────────────\n";

$locationCount = $db->query("SELECT COUNT(*) FROM locations")->fetchColumn();
echo "Total Locations: {$locationCount}\n";

if ($locationCount > 0) {
    $locations = $db->query("SELECT data FROM locations LIMIT 5")->fetchAll();
    echo "\nSample Locations:\n";
    foreach ($locations as $loc) {
        $locData = json_decode($loc['data'], true);
        echo "  - " . ($locData['name'] ?? 'N/A') . " (" . ($locData['type'] ?? 'N/A') . ")\n";
    }
}

echo "\n";

// 8. Issues Summary
echo "═══════════════════════════════════════════════════════════════════════\n";
echo "ISSUES SUMMARY\n";
echo "═══════════════════════════════════════════════════════════════════════\n";

$issues = [];

if ($movementCount == 0) {
    $issues[] = "⚠ CRITICAL: No inventory movements tracked";
} elseif ($movementCount < $completedPORs) {
    $issues[] = "⚠ WARNING: Fewer movements than completed PORs";
}

if ($reconciliationIssues > 0) {
    $issues[] = "⚠ WARNING: {$reconciliationIssues} stock reconciliation mismatches";
}

if ($outOfStock > 5) {
    $issues[] = "⚠ INFO: {$outOfStock} products out of stock";
}

if ($productsWithMovements < $totalProducts / 2) {
    $issues[] = "⚠ INFO: Less than 50% of products have movement history";
}

if (empty($issues)) {
    echo "✓ NO CRITICAL ISSUES\n";
    echo "  Inventory management is functioning correctly\n";
} else {
    echo "ISSUES DETECTED:\n\n";
    foreach ($issues as $issue) {
        echo "{$issue}\n";
    }
}

echo "\n";

// 9. Inventory Health Summary
echo "INVENTORY HEALTH SUMMARY\n";
echo "───────────────────────────────────────────────────────────────────────\n";

$totalValue = 0;
$stmt = $db->query("SELECT data FROM products");
while ($row = $stmt->fetch()) {
    $prodData = json_decode($row['data'], true);
    $stock = floatval($prodData['stock'] ?? 0);
    $cost = floatval($prodData['costingPrice'] ?? 0);
    $totalValue += $stock * $cost;
}

echo "Total Inventory Value: ₱" . number_format($totalValue, 2) . "\n";
echo "Stock Health:\n";
echo "  ✓ Normal/Healthy: {$normalStock} products\n";
echo "  ⚠ Needs Reorder: {$lowStock} products\n";
echo "  ✗ Out of Stock: {$outOfStock} products\n";
echo "  ℹ Overstock: {$overStock} products\n";

echo "\n";
echo "═══════════════════════════════════════════════════════════════════════\n";
