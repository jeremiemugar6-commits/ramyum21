<?php
/**
 * CREATE MISSING INVENTORY MOVEMENTS FOR COMPLETED PORs
 * The fix-por-workflow.php marked PORs as inventory_updated but didn't create movement records
 * This script creates the missing movements
 */

require_once 'config/database.php';
require_once 'includes/functions.php';

$db = getDB();

echo "═══════════════════════════════════════════════════════════════════════\n";
echo "CREATE POR INVENTORY MOVEMENTS\n";
echo "═══════════════════════════════════════════════════════════════════════\n\n";

try {
    $db->beginTransaction();
    
    // Get all completed PORs with inventory_updated = 1
    $completedPORs = $db->query("
        SELECT * FROM proof_of_receiving
        WHERE status = 'Completed' 
        AND inventory_updated = 1
        ORDER BY por_number
    ")->fetchAll();
    
    echo "Found " . count($completedPORs) . " completed PORs with inventory_updated = 1\n\n";
    
    $movementsCreated = 0;
    $movementsSkipped = 0;
    
    foreach ($completedPORs as $por) {
        echo "Processing POR: {$por['por_number']}\n";
        echo "  Supplier: {$por['supplier_name']}\n";
        echo "  Completed: {$por['completed_at']}\n";
        
        // Check if movements already exist for this POR
        $existingStmt = $db->prepare("
            SELECT COUNT(*) FROM inventory_movements
            WHERE JSON_EXTRACT(data, '$.referenceId') = ?
        ");
        $existingStmt->execute([$por['por_number']]);
        $existingCount = $existingStmt->fetchColumn();
        
        if ($existingCount > 0) {
            echo "  ⚠ Already has {$existingCount} movements - skipping\n\n";
            $movementsSkipped += $existingCount;
            continue;
        }
        
        // Get POR items
        $itemsStmt = $db->prepare("
            SELECT * FROM proof_of_receiving_items 
            WHERE por_id = ?
        ");
        $itemsStmt->execute([$por['id']]);
        $items = $itemsStmt->fetchAll();
        
        echo "  Items: " . count($items) . "\n";
        
        $itemsProcessed = 0;
        
        foreach ($items as $item) {
            $productId = $item['product_id'];
            $acceptedQty = floatval($item['accepted_quantity']);
            
            if ($acceptedQty <= 0) {
                echo "    - {$item['product_name']}: Skipped (0 accepted)\n";
                continue;
            }
            
            // Get current product to calculate previous balance
            // Since inventory was already updated, we need to subtract accepted qty to get previous balance
            $prodStmt = $db->prepare("SELECT data FROM products WHERE id = ?");
            $prodStmt->execute([$productId]);
            $productRow = $prodStmt->fetch();
            
            if (!$productRow) {
                echo "    ✗ {$item['product_name']}: Product not found (ID: {$productId})\n";
                continue;
            }
            
            $productData = json_decode($productRow['data'], true);
            $currentStock = floatval($productData['stock'] ?? 0);
            
            // Calculate what the previous balance was (current - accepted)
            $previousBalance = $currentStock - $acceptedQty;
            $newBalance = $currentStock;
            
            // Create inventory movement record
            $movementId = generate_id('inv_mov');
            $movementData = [
                'id' => $movementId,
                'productId' => $productId,
                'productName' => $item['product_name'],
                'sku' => $item['sku'],
                'date' => $por['completed_at'] ?? date('Y-m-d\TH:i:s.v\Z'),
                'type' => 'Stock In',
                'referenceType' => 'POR',
                'referenceId' => $por['por_number'],
                'referencePO' => $por['po_number'],
                'quantity' => $acceptedQty,
                'previousBalance' => $previousBalance,
                'newBalance' => $newBalance,
                'change' => $acceptedQty,
                'reason' => 'Proof of Receiving - Accepted Quantity',
                'notes' => "POR {$por['por_number']} - {$por['supplier_name']}",
                'user' => 'System (Inventory Sync)',
                'unitCost' => floatval($item['unit_cost'] ?? 0)
            ];
            
            // Use the POR's inventory_updated_at timestamp as created_at
            $createdAt = $por['inventory_updated_at'] ?? date('Y-m-d H:i:s');
            
            $movStmt = $db->prepare("
                INSERT INTO inventory_movements (id, data, created_at, updated_at) 
                VALUES (?, ?, ?, ?)
            ");
            $movStmt->execute([
                $movementId, 
                json_encode($movementData),
                $createdAt,
                $createdAt
            ]);
            
            echo "    ✓ {$item['product_name']}: +{$acceptedQty} units (Balance: {$previousBalance} → {$newBalance})\n";
            $movementsCreated++;
            $itemsProcessed++;
        }
        
        echo "  ✓ Created {$itemsProcessed} movements for {$por['por_number']}\n\n";
    }
    
    $db->commit();
    
    echo "═══════════════════════════════════════════════════════════════════════\n";
    echo "SUMMARY\n";
    echo "═══════════════════════════════════════════════════════════════════════\n";
    echo "Movements created: {$movementsCreated}\n";
    echo "Movements skipped: {$movementsSkipped}\n";
    
    echo "\n";
    
    // VERIFICATION
    echo "VERIFICATION:\n";
    echo "───────────────────────────────────────────────────────────────────────\n";
    
    $porMovements = $db->query("
        SELECT COUNT(*) FROM inventory_movements
        WHERE JSON_EXTRACT(data, '$.referenceType') = 'POR'
    ")->fetchColumn();
    
    $totalMovements = $db->query("SELECT COUNT(*) FROM inventory_movements")->fetchColumn();
    
    echo "Total inventory movements: {$totalMovements}\n";
    echo "Movements with referenceType='POR': {$porMovements}\n";
    
    if ($porMovements > 0) {
        echo "\n✓ POR inventory movements successfully created!\n";
        
        // Show breakdown
        $porDetails = $db->query("
            SELECT 
                JSON_EXTRACT(data, '$.referenceId') as por_number,
                COUNT(*) as movement_count
            FROM inventory_movements
            WHERE JSON_EXTRACT(data, '$.referenceType') = 'POR'
            GROUP BY JSON_EXTRACT(data, '$.referenceId')
        ")->fetchAll();
        
        echo "\nBreakdown by POR:\n";
        foreach ($porDetails as $detail) {
            echo "  {$detail['por_number']}: {$detail['movement_count']} movements\n";
        }
    }
    
    echo "\n";
    echo "═══════════════════════════════════════════════════════════════════════\n";
    echo "COMPLETE\n";
    echo "═══════════════════════════════════════════════════════════════════════\n";
    
} catch (Exception $e) {
    $db->rollBack();
    echo "\n✗ ERROR: " . $e->getMessage() . "\n";
    echo $e->getTraceAsString() . "\n";
    exit(1);
}
