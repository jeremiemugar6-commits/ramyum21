<?php
/**
 * Update Admin Email Script
 * This script updates the admin user's email address to jeremiemugar7@gmail.com
 */

require_once __DIR__ . '/config/database.php';

try {
    $pdo = get_database_connection();
    
    echo "<h2>Admin Email Update</h2>";
    
    // Check current admin email
    $stmt = $pdo->prepare("SELECT id, name, email, username, role FROM users WHERE username = 'admin' AND role = 'admin'");
    $stmt->execute();
    $admin = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$admin) {
        echo "<p style='color: red;'>❌ Admin user not found!</p>";
        exit;
    }
    
    echo "<p><strong>Current Admin User:</strong></p>";
    echo "<p>Name: " . htmlspecialchars($admin['name']) . "</p>";
    echo "<p>Email: " . htmlspecialchars($admin['email']) . "</p>";
    echo "<p>Username: " . htmlspecialchars($admin['username']) . "</p>";
    
    // Update admin email
    $newEmail = 'jeremiemugar7@gmail.com';
    $stmt = $pdo->prepare("UPDATE users SET email = ?, updated_at = CURRENT_TIMESTAMP WHERE username = 'admin' AND role = 'admin'");
    $success = $stmt->execute([$newEmail]);
    
    if ($success && $stmt->rowCount() > 0) {
        echo "<p style='color: green;'>✅ <strong>SUCCESS!</strong> Admin email updated to: " . htmlspecialchars($newEmail) . "</p>";
        
        // Verify the update
        $stmt = $pdo->prepare("SELECT id, name, email, username, role FROM users WHERE username = 'admin' AND role = 'admin'");
        $stmt->execute();
        $updated_admin = $stmt->fetch(PDO::FETCH_ASSOC);
        
        echo "<p><strong>Updated Admin User:</strong></p>";
        echo "<p>Name: " . htmlspecialchars($updated_admin['name']) . "</p>";
        echo "<p>Email: " . htmlspecialchars($updated_admin['email']) . "</p>";
        echo "<p>Username: " . htmlspecialchars($updated_admin['username']) . "</p>";
        
    } else {
        echo "<p style='color: red;'>❌ Failed to update admin email or no changes made.</p>";
    }
    
} catch (PDOException $e) {
    echo "<p style='color: red;'>❌ Database error: " . htmlspecialchars($e->getMessage()) . "</p>";
} catch (Exception $e) {
    echo "<p style='color: red;'>❌ Error: " . htmlspecialchars($e->getMessage()) . "</p>";
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Admin Email Update - RAMYUM</title>
    <style>
        body { font-family: Arial, sans-serif; max-width: 800px; margin: 0 auto; padding: 20px; }
        h2 { color: #FF7A00; }
    </style>
</head>
<body>
    <h1>RAMYUM Admin Email Update</h1>
    
    <hr>
    <p><strong>Note:</strong> After updating the admin email, make sure to:</p>
    <ol>
        <li>Update the Gmail App Password in the .env file if using a different Gmail account</li>
        <li>Test email functionality with the new email address</li>
        <li>Delete this update script for security</li>
    </ol>
</body>
</html>