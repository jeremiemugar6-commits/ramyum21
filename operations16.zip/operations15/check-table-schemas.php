<?php
require_once 'config/database.php';

$db = getDB();

$tables = ['users', 'products', 'purchase_orders', 'receivings', 'proof_of_receiving', 'stock_transfers', 'suppliers'];

foreach ($tables as $table) {
    echo "\n═══ {$table} ═══\n";
    $stmt = $db->query("DESCRIBE {$table}");
    while ($row = $stmt->fetch()) {
        echo sprintf("%-30s %-20s %s\n", $row['Field'], $row['Type'], $row['Null']);
    }
}
