<?php
/**
 * Fix POR Status - Update Pending to Passed
 * This script updates POR records that have accepted items but are marked as "Pending"
 */

require_once __DIR__ . '/includes/functions.php';

$db = getDB();

try {
    // Start transaction
    $db->beginTransaction();
    
    // Find all POR records where:
    // - Status is "Pending" or "Pending Inspection"
    // - Items were actually accepted (total_accepted > 0)
    // - Inventory was updated (meaning they were processed)
    // - Received by Admin User
    
    $stmt = $db->prepare("
        SELECT 
            id,
            por_number,
            inspection_status,
            total_accepted,
            total_rejected,
            total_received,
            received_by_name,
            inventory_updated
        FROM proof_of_receiving
        WHERE (inspection_status = 'Pending' OR inspection_status = 'Pending Inspection')
          AND received_by_name = 'Admin User'
          AND total_accepted > 0
          AND inventory_updated = 1
    ");
    
    $stmt->execute();
    $porRecords = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "<h2>Fixing POR Status - Pending → Passed</h2>";
    echo "<p>Found <strong>" . count($porRecords) . "</strong> POR records to update</p>";
    
    if (count($porRecords) == 0) {
        echo "<p style='color:orange;'>No records need updating.</p>";
        $db->rollBack();
        exit;
    }
    
    echo "<table border='1' cellpadding='10' style='border-collapse:collapse; margin:20px 0;'>";
    echo "<tr style='background:#f0f0f0;'>
            <th>POR #</th>
            <th>Current Status</th>
            <th>New Status</th>
            <th>Accepted</th>
            <th>Rejected</th>
            <th>Received</th>
          </tr>";
    
    $updateStmt = $db->prepare("
        UPDATE proof_of_receiving 
        SET inspection_status = ?
        WHERE id = ?
    ");
    
    $updatedCount = 0;
    
    foreach ($porRecords as $por) {
        // Determine the correct status based on inspection results
        $newStatus = 'Passed';
        
        // If there were rejections, it should be Failed
        if ($por['total_rejected'] > 0) {
            $newStatus = 'Failed';
        }
        // If accepted + rejected doesn't equal received, it's Partial (damaged items)
        elseif (($por['total_accepted'] + $por['total_rejected']) < $por['total_received']) {
            $newStatus = 'Partial';
        }
        // If all items were accepted, it's Passed
        elseif ($por['total_accepted'] == $por['total_received']) {
            $newStatus = 'Passed';
        }
        
        // Update the status
        $updateStmt->execute([$newStatus, $por['id']]);
        $updatedCount++;
        
        $statusColor = match($newStatus) {
            'Passed' => '#10B981',
            'Failed' => '#EF4444',
            'Partial' => '#F59E0B',
            default => '#6B7280'
        };
        
        echo "<tr>";
        echo "<td>{$por['por_number']}</td>";
        echo "<td style='color:#F59E0B;'>{$por['inspection_status']}</td>";
        echo "<td style='color:{$statusColor}; font-weight:bold;'>{$newStatus}</td>";
        echo "<td style='color:#10B981;'>{$por['total_accepted']}</td>";
        echo "<td style='color:#EF4444;'>{$por['total_rejected']}</td>";
        echo "<td>{$por['total_received']}</td>";
        echo "</tr>";
    }
    
    echo "</table>";
    
    // Commit the changes
    $db->commit();
    
    echo "<div style='background:#D1FAE5; border:1px solid #10B981; padding:20px; border-radius:8px; margin:20px 0;'>";
    echo "<h3 style='color:#065F46; margin:0 0 10px 0;'>✓ Success!</h3>";
    echo "<p style='color:#065F46; margin:0;'><strong>{$updatedCount}</strong> POR records updated successfully.</p>";
    echo "</div>";
    
    echo "<p><a href='dashboard.php#por' style='padding:10px 20px; background:#FF7A00; color:white; text-decoration:none; border-radius:5px; display:inline-block;'>Go to POR Module</a></p>";
    echo "<p><a href='fix-por-status.php' onclick='return confirm(\"Run this script again?\")' style='padding:10px 20px; background:#6B7280; color:white; text-decoration:none; border-radius:5px; display:inline-block;'>Check Again</a></p>";
    
} catch (Exception $e) {
    $db->rollBack();
    echo "<div style='background:#FEE2E2; border:1px solid #EF4444; padding:20px; border-radius:8px;'>";
    echo "<h3 style='color:#991B1B;'>✗ Error</h3>";
    echo "<p style='color:#991B1B;'>{$e->getMessage()}</p>";
    echo "</div>";
}
?>

<style>
    body {
        font-family: Arial, sans-serif;
        max-width: 1200px;
        margin: 50px auto;
        padding: 20px;
        background: #f5f5f5;
    }
    h2 {
        color: #333;
        border-bottom: 2px solid #FF7A00;
        padding-bottom: 10px;
    }
</style>
