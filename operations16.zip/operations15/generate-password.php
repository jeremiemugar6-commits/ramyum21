<?php
/**
 * Generate proper PHP bcrypt hashes for the seed users
 */

$passwords = [
    'Admin@123' => password_hash('Admin@123', PASSWORD_BCRYPT),
    'Staff@123' => password_hash('Staff@123', PASSWORD_BCRYPT),
];

echo "<h1>Generated Password Hashes</h1>";
echo "<p>Update these in your database/schema.sql file:</p>";
echo "<pre>";
foreach ($passwords as $plain => $hash) {
    echo "{$plain}: {$hash}\n";
}
echo "</pre>";

// Test verification
echo "<h2>Verification Tests</h2>";
echo "<p>Testing if generated hashes can be verified:</p>";
foreach ($passwords as $plain => $hash) {
    $verified = password_verify($plain, $hash) ? '✓ PASS' : '✗ FAIL';
    echo "<p>{$plain}: {$verified}</p>";
}

// Test the original $2b$ hashes from schema
echo "<h2>Original Schema Hash Tests</h2>";
$original_hashes = [
    'Admin@123' => '$2b$10$jORdZ.f9BV.WT2nFKNek5ekLliBntqCv0DaSh1RXLPoD2bffa3Hb.',
    'Staff@123' => '$2b$10$U//kJkgHuyUwK24TLR9SWuhfowJHAJaq9SouO3yZWV8GekND2XbsS',
];
echo "<p>Testing if PHP can verify the $2b$ hashes from the schema:</p>";
foreach ($original_hashes as $plain => $hash) {
    $verified = password_verify($plain, $hash) ? '✓ PASS' : '✗ FAIL';
    echo "<p>{$plain}: {$verified}</p>";
}
