<?php
/**
 * Proof of Delivery API Endpoints
 * Handles POD scanning, receiving, photo evidence, and confirmation
 * 
 * DEPRECATED: This API is maintained for backward compatibility only.
 * New implementations should use api/proof-of-receiving.php for receiving workflows
 * and api/stock-transfers.php for transfer workflows with POD functionality.
 */

require_once __DIR__ . '/../includes/auth.php';

header('Content-Type: application/json');

$currentUser = require_login_api();
$db = getDB();
$method = $_SERVER['REQUEST_METHOD'];
$action = $_GET['action'] ?? '';

try {
    switch ($method) {
        case 'GET':
            handleGet($db, $action, $currentUser);
            break;
        case 'POST':
            handlePost($db, $action, $currentUser);
            break;
        default:
            http_response_code(405);
            echo json_encode(['success' => false, 'error' => 'Method not allowed']);
    }
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}

function handleGet($db, $action, $currentUser) {
    switch ($action) {
        case 'scan':
            scanQRCode($db, $_GET['token'] ?? '', $currentUser);
            break;
        case 'pod':
            getPODById($db, $_GET['id'] ?? '');
            break;
        case 'by-transfer':
            getPODByTransfer($db, $_GET['transferId'] ?? '');
            break;
        case 'list':
            listPODs($db, $currentUser);
            break;
        case 'photos':
            getPODPhotos($db, $_GET['podId'] ?? '');
            break;
        case 'get_por_stats':
            getPORStats($db, $currentUser);
            break;
        default:
            http_response_code(400);
            echo json_encode(['success' => false, 'error' => 'Invalid action']);
    }
}

function handlePost($db, $action, $currentUser) {
    switch ($action) {
        case 'confirm-receiving':
            confirmReceiving($db, $currentUser);
            break;
        case 'upload-photo':
            uploadPODPhoto($db, $currentUser);
            break;
        case 'record-damage':
            recordDamageEvidence($db, $currentUser);
            break;
        default:
            http_response_code(400);
            echo json_encode(['success' => false, 'error' => 'Invalid action']);
    }
}

/**
 * Scan QR code and retrieve stock transfer
 */
function scanQRCode($db, $token, $currentUser) {
    if (empty($token)) {
        echo json_encode(['success' => false, 'error' => 'QR token required']);
        return;
    }

    try {
        // Find POD by QR token
        $stmt = $db->prepare("SELECT * FROM proof_of_delivery WHERE qr_token = ?");
        $stmt->execute([$token]);
        $pod = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$pod) {
            echo json_encode(['success' => false, 'error' => 'Invalid QR code']);
            return;
        }

        // Check if already received
        if ($pod['status'] === 'Received') {
            echo json_encode([
                'success' => false,
                'error' => 'This transfer has already been received',
                'alreadyReceived' => true,
                'receivedBy' => $pod['received_by_name'],
                'receivedAt' => $pod['received_at']
            ]);
            return;
        }

        // Get transfer details
        $transferStmt = $db->prepare("SELECT data FROM stock_transfers WHERE id = ?");
        $transferStmt->execute([$pod['transfer_id']]);
        $transferResult = $transferStmt->fetch();

        if (!$transferResult) {
            throw new Exception('Stock transfer not found');
        }

        $transfer = json_decode($transferResult['data'], true);

        // Verify transfer is in correct status
        if ($transfer['status'] !== 'In Transit') {
            echo json_encode([
                'success' => false,
                'error' => 'Transfer is not available for receiving',
                'status' => $transfer['status']
            ]);
            return;
        }

        // Update POD scan timestamp
        if (!$pod['scanned_at']) {
            $updateStmt = $db->prepare("
                UPDATE proof_of_delivery 
                SET scanned_at = NOW(), scanned_by_id = ?, scanned_by_name = ? 
                WHERE id = ?
            ");
            $updateStmt->execute([$currentUser['id'], $currentUser['name'], $pod['id']]);
        }

        echo json_encode([
            'success' => true,
            'data' => [
                'podId' => $pod['id'],
                'transferId' => $pod['transfer_id'],
                'transferNumber' => $transfer['transferNumber'],
                'sourceLocation' => $transfer['sourceLocationName'],
                'destinationLocation' => $transfer['destinationLocationName'],
                'transferDate' => $transfer['transferDate'],
                'items' => $transfer['items'],
                'totalItems' => $transfer['totalItems'],
                'remarks' => $transfer['remarks'] ?? '',
                'status' => $transfer['status']
            ]
        ]);

    } catch (Exception $e) {
        throw new Exception('Failed to scan QR code: ' . $e->getMessage());
    }
}

/**
 * Confirm receiving and finalize POD
 */
function confirmReceiving($db, $currentUser) {
    $input = get_json_input();
    
    $podId = $input['podId'] ?? '';
    $items = $input['items'] ?? [];
    $notes = $input['notes'] ?? '';
    $photos = $input['photos'] ?? [];

    if (empty($podId)) {
        echo json_encode(['success' => false, 'error' => 'POD ID required']);
        return;
    }

    if (empty($items) || !is_array($items)) {
        echo json_encode(['success' => false, 'error' => 'Items required']);
        return;
    }

    try {
        $db->beginTransaction();

        // Get POD record
        $stmt = $db->prepare("SELECT * FROM proof_of_delivery WHERE id = ?");
        $stmt->execute([$podId]);
        $pod = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$pod) {
            throw new Exception('POD not found');
        }

        if ($pod['status'] === 'Received') {
            throw new Exception('This transfer has already been received');
        }

        // Get transfer
        $transferStmt = $db->prepare("SELECT data FROM stock_transfers WHERE id = ?");
        $transferStmt->execute([$pod['transfer_id']]);
        $transferResult = $transferStmt->fetch();

        if (!$transferResult) {
            throw new Exception('Stock transfer not found');
        }

        $transfer = json_decode($transferResult['data'], true);

        // Validate all items have required fields
        foreach ($items as $item) {
            if (!isset($item['productId']) || !isset($item['receivedQuantity']) || !isset($item['condition'])) {
                throw new Exception('Invalid item data');
            }

            // Check if damaged items have photos
            if ($item['condition'] === 'Damaged' && empty($item['damagePhotoId'])) {
                throw new Exception("Damage photo required for {$item['productName']}");
            }
        }

        // Save POD items
        foreach ($items as $item) {
            $itemId = generate_id('podi');
            $itemStmt = $db->prepare("
                INSERT INTO pod_items (
                    id, pod_id, transfer_id, product_id, product_name, sku,
                    expected_quantity, received_quantity, unit, condition_status, notes
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ");
            $itemStmt->execute([
                $itemId,
                $podId,
                $pod['transfer_id'],
                $item['productId'],
                $item['productName'],
                $item['sku'] ?? null,
                $item['expectedQuantity'],
                $item['receivedQuantity'],
                $item['unit'] ?? 'pcs',
                $item['condition'],
                $item['notes'] ?? null
            ]);

            // Link photos to items if provided
            if (!empty($item['photoIds'])) {
                foreach ($item['photoIds'] as $photoId) {
                    $db->prepare("UPDATE pod_photos SET pod_item_id = ? WHERE id = ?")
                       ->execute([$itemId, $photoId]);
                }
            }
        }

        // Update inventory for received items
        updateInventoryForPOD($db, $items, $transfer, $currentUser);

        // Update POD status
        $updatePODStmt = $db->prepare("
            UPDATE proof_of_delivery 
            SET status = 'Received', 
                received_by_id = ?, 
                received_by_name = ?,
                received_at = NOW(),
                confirmation_notes = ?
            WHERE id = ?
        ");
        $updatePODStmt->execute([
            $currentUser['id'],
            $currentUser['name'],
            $notes,
            $podId
        ]);

        // Update stock transfer status
        $transfer['status'] = 'Received';
        $transfer['receivedBy'] = $currentUser['id'];
        $transfer['receivedByName'] = $currentUser['name'];
        $transfer['receivedAt'] = gmdate('Y-m-d\TH:i:s.v\Z');
        $transfer['receivingNotes'] = $notes;

        $updateTransferStmt = $db->prepare("UPDATE stock_transfers SET data = ? WHERE id = ?");
        $updateTransferStmt->execute([json_encode($transfer), $pod['transfer_id']]);

        // Log audit event
        logTransferAudit($db, $pod['transfer_id'], 'TRANSFER_RECEIVED', $currentUser, [
            'transferNumber' => $transfer['transferNumber'],
            'podId' => $podId,
            'receivedItems' => count($items),
            'notes' => $notes
        ]);

        $db->commit();

        echo json_encode([
            'success' => true,
            'message' => 'Receiving confirmed successfully',
            'data' => [
                'podId' => $podId,
                'transferNumber' => $transfer['transferNumber'],
                'status' => 'Received'
            ]
        ]);

    } catch (Exception $e) {
        $db->rollBack();
        throw new Exception('Failed to confirm receiving: ' . $e->getMessage());
    }
}

/**
 * Upload POD photo
 */
function uploadPODPhoto($db, $currentUser) {
    $podId = $_POST['podId'] ?? '';
    $photoType = $_POST['photoType'] ?? 'delivery';
    $caption = $_POST['caption'] ?? '';

    if (empty($podId)) {
        echo json_encode(['success' => false, 'error' => 'POD ID required']);
        return;
    }

    // Verify POD exists
    $stmt = $db->prepare("SELECT * FROM proof_of_delivery WHERE id = ?");
    $stmt->execute([$podId]);
    $pod = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$pod) {
        echo json_encode(['success' => false, 'error' => 'POD not found']);
        return;
    }

    // Handle file upload via existing upload system
    $_POST['type'] = 'damage'; // Use damage upload directory for POD photos
    require __DIR__ . '/upload-image.php';
    
    // Note: upload-image.php handles the response, but we need to save to pod_photos table
    // This is a simplified version - in production, we'd refactor upload-image.php
}

/**
 * Record damage evidence
 */
function recordDamageEvidence($db, $currentUser) {
    $input = get_json_input();
    
    $podId = $input['podId'] ?? '';
    $productId = $input['productId'] ?? '';
    $productName = $input['productName'] ?? '';
    $expectedQty = $input['expectedQuantity'] ?? 0;
    $receivedQty = $input['receivedQuantity'] ?? 0;
    $damagedQty = $input['damagedQuantity'] ?? 0;
    $damageType = $input['damageType'] ?? '';
    $description = $input['description'] ?? '';
    $imagePath = $input['imagePath'] ?? '';

    if (empty($podId) || empty($productId)) {
        echo json_encode(['success' => false, 'error' => 'POD ID and Product ID required']);
        return;
    }

    try {
        // Get POD and transfer info
        $stmt = $db->prepare("SELECT * FROM proof_of_delivery WHERE id = ?");
        $stmt->execute([$podId]);
        $pod = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$pod) {
            throw new Exception('POD not found');
        }

        $evidenceId = generate_id('dmg');
        
        $insertStmt = $db->prepare("
            INSERT INTO damage_evidence (
                id, reference_type, reference_id, reference_number,
                pod_id, product_id, product_name, expected_quantity,
                received_quantity, damaged_quantity, damage_type,
                damage_description, evidence_image_path,
                recorded_by_id, recorded_by_name, recorded_at
            ) VALUES (?, 'STOCK_TRANSFER', ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())
        ");
        
        $insertStmt->execute([
            $evidenceId,
            $pod['transfer_id'],
            $pod['transfer_number'],
            $podId,
            $productId,
            $productName,
            $expectedQty,
            $receivedQty,
            $damagedQty,
            $damageType,
            $description,
            $imagePath,
            $currentUser['id'],
            $currentUser['name']
        ]);

        echo json_encode([
            'success' => true,
            'data' => ['evidenceId' => $evidenceId],
            'message' => 'Damage evidence recorded successfully'
        ]);

    } catch (Exception $e) {
        throw new Exception('Failed to record damage evidence: ' . $e->getMessage());
    }
}

/**
 * Get POD by ID
 */
function getPODById($db, $podId) {
    if (empty($podId)) {
        echo json_encode(['success' => false, 'error' => 'POD ID required']);
        return;
    }

    try {
        $stmt = $db->prepare("SELECT * FROM proof_of_delivery WHERE id = ?");
        $stmt->execute([$podId]);
        $pod = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$pod) {
            echo json_encode(['success' => false, 'error' => 'POD not found']);
            return;
        }

        // Get items
        $itemsStmt = $db->prepare("SELECT * FROM pod_items WHERE pod_id = ?");
        $itemsStmt->execute([$podId]);
        $items = $itemsStmt->fetchAll(PDO::FETCH_ASSOC);

        // Get photos
        $photosStmt = $db->prepare("SELECT * FROM pod_photos WHERE pod_id = ?");
        $photosStmt->execute([$podId]);
        $photos = $photosStmt->fetchAll(PDO::FETCH_ASSOC);

        echo json_encode([
            'success' => true,
            'data' => [
                'pod' => $pod,
                'items' => $items,
                'photos' => $photos
            ]
        ]);

    } catch (Exception $e) {
        throw new Exception('Failed to fetch POD: ' . $e->getMessage());
    }
}

/**
 * Get POD by transfer ID
 */
function getPODByTransfer($db, $transferId) {
    if (empty($transferId)) {
        echo json_encode(['success' => false, 'error' => 'Transfer ID required']);
        return;
    }

    try {
        $stmt = $db->prepare("SELECT * FROM proof_of_delivery WHERE transfer_id = ?");
        $stmt->execute([$transferId]);
        $pod = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$pod) {
            echo json_encode(['success' => false, 'error' => 'POD not found for this transfer']);
            return;
        }

        // Get items
        $itemsStmt = $db->prepare("SELECT * FROM pod_items WHERE pod_id = ?");
        $itemsStmt->execute([$pod['id']]);
        $items = $itemsStmt->fetchAll(PDO::FETCH_ASSOC);

        // Get photos
        $photosStmt = $db->prepare("SELECT * FROM pod_photos WHERE pod_id = ?");
        $photosStmt->execute([$pod['id']]);
        $photos = $photosStmt->fetchAll(PDO::FETCH_ASSOC);

        echo json_encode([
            'success' => true,
            'data' => [
                'pod' => $pod,
                'items' => $items,
                'photos' => $photos
            ]
        ]);

    } catch (Exception $e) {
        throw new Exception('Failed to fetch POD: ' . $e->getMessage());
    }
}

/**
 * List PODs
 */
function listPODs($db, $currentUser) {
    try {
        $stmt = $db->query("SELECT * FROM proof_of_delivery ORDER BY created_at DESC");
        $pods = $stmt->fetchAll(PDO::FETCH_ASSOC);

        echo json_encode(['success' => true, 'data' => $pods]);
    } catch (Exception $e) {
        throw new Exception('Failed to fetch PODs: ' . $e->getMessage());
    }
}

/**
 * Get POD photos
 */
function getPODPhotos($db, $podId) {
    if (empty($podId)) {
        echo json_encode(['success' => false, 'error' => 'POD ID required']);
        return;
    }

    try {
        $stmt = $db->prepare("SELECT * FROM pod_photos WHERE pod_id = ? ORDER BY uploaded_at ASC");
        $stmt->execute([$podId]);
        $photos = $stmt->fetchAll(PDO::FETCH_ASSOC);

        echo json_encode(['success' => true, 'data' => $photos]);
    } catch (Exception $e) {
        throw new Exception('Failed to fetch photos: ' . $e->getMessage());
    }
}

/**
 * Update inventory for POD receiving
 */
function updateInventoryForPOD($db, $items, $transfer, $currentUser) {
    foreach ($items as $item) {
        $productId = $item['productId'];
        $quantity = $item['receivedQuantity'];
        $sourceLocationId = $transfer['sourceLocationId'];
        $destinationLocationId = $transfer['destinationLocationId'];

        // Update destination location (add stock)
        $destStmt = $db->prepare("
            SELECT id, data FROM inventory_locations 
            WHERE JSON_UNQUOTE(JSON_EXTRACT(data, '$.productId')) = ? 
            AND JSON_UNQUOTE(JSON_EXTRACT(data, '$.locationId')) = ?
        ");
        $destStmt->execute([$productId, $destinationLocationId]);
        $destResult = $destStmt->fetch();
        
        if ($destResult) {
            $destData = json_decode($destResult['data'], true);
            $destData['quantity'] += $quantity;
            $destData['availableQuantity'] += $quantity;
            $destData['lastUpdated'] = gmdate('Y-m-d\TH:i:s.v\Z');
            
            $updateDestStmt = $db->prepare("UPDATE inventory_locations SET data = ? WHERE id = ?");
            $updateDestStmt->execute([json_encode($destData), $destResult['id']]);
        } else {
            // Create new inventory record
            $newId = generate_id('inv');
            $newData = [
                'id' => $newId,
                'productId' => $productId,
                'locationId' => $destinationLocationId,
                'quantity' => $quantity,
                'reservedQuantity' => 0,
                'availableQuantity' => $quantity,
                'lastUpdated' => gmdate('Y-m-d\TH:i:s.v\Z')
            ];
            
            $insertDestStmt = $db->prepare("INSERT INTO inventory_locations (id, data) VALUES (?, ?)");
            $insertDestStmt->execute([$newId, json_encode($newData)]);
        }

        // Create inventory movement record
        $movementId = generate_id('mov');
        $movementData = [
            'id' => $movementId,
            'productId' => $productId,
            'productName' => $item['productName'],
            'locationId' => $destinationLocationId,
            'locationName' => $transfer['destinationLocationName'],
            'movementType' => 'Stock In',
            'quantity' => $quantity,
            'referenceType' => 'POD_RECEIVING',
            'referenceId' => $transfer['transferNumber'],
            'performedBy' => $currentUser['id'],
            'performedByName' => $currentUser['name'],
            'reason' => 'POD Confirmed',
            'notes' => "Stock transfer received from {$transfer['sourceLocationName']}",
            'createdAt' => gmdate('Y-m-d\TH:i:s.v\Z')
        ];

        $stmt = $db->prepare("INSERT INTO inventory_movements (id, data) VALUES (?, ?)");
        $stmt->execute([$movementId, json_encode($movementData)]);
    }
}

/**
 * Log audit event
 */
function logTransferAudit($db, $transferId, $actionType, $currentUser, $details) {
    $stmt = $db->prepare("
        INSERT INTO stock_transfer_audit (transfer_id, action_type, user_id, user_name, details, ip_address) 
        VALUES (?, ?, ?, ?, ?, ?)
    ");
    $stmt->execute([
        $transferId,
        $actionType,
        $currentUser['id'],
        $currentUser['name'],
        json_encode($details),
        $_SERVER['REMOTE_ADDR'] ?? null
    ]);
}
?>

/**
 * Get POR Statistics (for badge counts)
 * Returns real-time counts from proof_of_receiving table
 */
function getPORStats($db, $currentUser) {
    try {
        // Get counts by inspection_status
        $stmt = $db->query("
            SELECT 
                COUNT(*) as total,
                SUM(CASE WHEN inspection_status IN ('Pending', 'Pending Inspection') THEN 1 ELSE 0 END) as pending,
                SUM(CASE WHEN inspection_status IN ('Passed', 'Approved') THEN 1 ELSE 0 END) as passed,
                SUM(CASE WHEN inspection_status IN ('Failed', 'Rejected') THEN 1 ELSE 0 END) as failed,
                SUM(CASE WHEN inspection_status IN ('Partial', 'Partially Approved') THEN 1 ELSE 0 END) as damaged
            FROM proof_of_receiving
        ");
        
        $stats = $stmt->fetch(PDO::FETCH_ASSOC);
        
        echo json_encode([
            'success' => true,
            'data' => [
                'all' => (int)$stats['total'],
                'pending' => (int)$stats['pending'],
                'passed' => (int)$stats['passed'],
                'failed' => (int)$stats['failed'],
                'damaged' => (int)$stats['damaged']
            ]
        ]);
    } catch (Exception $e) {
        echo json_encode([
            'success' => false,
            'error' => $e->getMessage()
        ]);
    }
}
