<?php
/**
 * Integration Test API for RAM-YUM Workflow
 * Tests the complete Purchase Order → Receiving → Inventory integration
 */

require_once __DIR__ . '/../includes/auth.php';

header('Content-Type: application/json');

// Only allow in demo mode
if (!DEMO_INTEGRATION_MODE) {
    json_error('Integration testing only available in demo mode', 403);
}

require_login_api();

$db = getDB();
$action = $_GET['action'] ?? '';

try {
    switch ($action) {
        case 'create_test_po':
            // Create a test purchase order
            $poData = [
                'poNumber' => 'PO-' . date('Y') . '-' . sprintf('%04d', rand(1000, 9999)),
                'supplier' => 'Seoul Food Distribution',
                'supplierId' => 's1',
                'orderDate' => date('Y-m-d\TH:i:s.000\Z'),
                'status' => 'Approved',
                'items' => [
                    [
                        'productId' => 'p1',
                        'productName' => 'Samyang Buldak Original',
                        'quantity' => 20,
                        'unitCost' => 65.00,
                        'subtotal' => 1300.00,
                        'receivedQuantity' => 0,
                        'remainingQuantity' => 20
                    ]
                ],
                'subtotal' => 1300.00,
                'total' => 1300.00,
                'totalItems' => 20,
                'receivedItems' => 0,
                'remainingItems' => 20,
                'createdBy' => 'Integration Test'
            ];
            
            $testId = 'integration_test_' . uniqid();
            $stmt = $db->prepare("INSERT INTO purchase_orders (id, data) VALUES (?, ?)");
            $stmt->execute([$testId, json_encode($poData)]);
            
            json_response([
                'success' => true,
                'message' => 'Test PO created successfully',
                'data' => [
                    'id' => $testId,
                    'poNumber' => $poData['poNumber'],
                    'status' => $poData['status']
                ]
            ]);
            break;
            
        case 'test_receiving':
            $poId = $_POST['poId'] ?? '';
            if (!$poId) {
                json_error('PO ID required', 400);
            }
            
            // Get PO data
            $stmt = $db->prepare("SELECT data FROM purchase_orders WHERE id = ?");
            $stmt->execute([$poId]);
            $poRow = $stmt->fetch();
            
            if (!$poRow) {
                json_error('Purchase Order not found', 404);
            }
            
            $poData = json_decode($poRow['data'], true);
            
            // Create receiving record
            $receivingData = [
                'receivingNumber' => 'GR-' . date('Y') . '-' . sprintf('%04d', rand(1000, 9999)),
                'poId' => $poId,
                'poNumber' => $poData['poNumber'],
                'supplierId' => $poData['supplierId'],
                'supplier' => $poData['supplier'],
                'receivedDate' => date('Y-m-d\TH:i:s.000\Z'),
                'receivedBy' => 'Integration Test',
                'totalReceived' => 15, // Partial receiving
                'items' => [
                    [
                        'productId' => $poData['items'][0]['productId'],
                        'productName' => $poData['items'][0]['productName'],
                        'quantityReceived' => 15,
                        'unitCost' => $poData['items'][0]['unitCost']
                    ]
                ],
                'status' => 'Completed'
            ];
            
            $receivingId = 'integration_receiving_' . uniqid();
            $stmt = $db->prepare("INSERT INTO receivings (id, data) VALUES (?, ?)");
            $stmt->execute([$receivingId, json_encode($receivingData)]);
            
            // Update PO status
            $poData['status'] = 'Partially Received';
            $poData['items'][0]['receivedQuantity'] = 15;
            $poData['items'][0]['remainingQuantity'] = 5;
            $poData['receivedItems'] = 15;
            $poData['remainingItems'] = 5;
            
            $stmt = $db->prepare("UPDATE purchase_orders SET data = ? WHERE id = ?");
            $stmt->execute([json_encode($poData), $poId]);
            
            // Update inventory
            $productStmt = $db->prepare("SELECT data FROM products WHERE id = ?");
            $productStmt->execute([$poData['items'][0]['productId']]);
            $productRow = $productStmt->fetch();
            
            if ($productRow) {
                $productData = json_decode($productRow['data'], true);
                $oldStock = $productData['stock'];
                $productData['stock'] = $oldStock + 15;
                $productData['lastUpdated'] = date('Y-m-d\TH:i:s.000\Z');
                
                $stmt = $db->prepare("UPDATE products SET data = ? WHERE id = ?");
                $stmt->execute([json_encode($productData), $poData['items'][0]['productId']]);
                
                // Create stock movement
                $movementData = [
                    'productId' => $productData['id'],
                    'productName' => $productData['name'],
                    'sku' => $productData['sku'] ?? 'N/A',
                    'date' => date('Y-m-d\TH:i:s.000\Z'),
                    'type' => 'Stock In',
                    'quantity' => 15,
                    'previousBalance' => $oldStock,
                    'newBalance' => $productData['stock'],
                    'change' => 15,
                    'reason' => 'Purchase Order Receiving',
                    'referenceType' => 'RECEIVING',
                    'referenceId' => $receivingData['receivingNumber'],
                    'referencePO' => $poData['poNumber'],
                    'user' => 'Integration Test'
                ];
                
                $movementId = 'integration_movement_' . uniqid();
                $stmt = $db->prepare("INSERT INTO inventory_movements (id, data) VALUES (?, ?)");
                $stmt->execute([$movementId, json_encode($movementData)]);
            }
            
            json_response([
                'success' => true,
                'message' => 'Receiving processed successfully',
                'data' => [
                    'receivingNumber' => $receivingData['receivingNumber'],
                    'itemsReceived' => 15,
                    'poStatus' => 'Partially Received',
                    'inventoryUpdated' => true
                ]
            ]);
            break;
            
        case 'cleanup_test_data':
            // Clean up integration test data
            $db->exec("DELETE FROM purchase_orders WHERE id LIKE 'integration_test_%'");
            $db->exec("DELETE FROM receivings WHERE id LIKE 'integration_receiving_%'");
            $db->exec("DELETE FROM inventory_movements WHERE id LIKE 'integration_movement_%'");
            
            json_response([
                'success' => true,
                'message' => 'Integration test data cleaned up'
            ]);
            break;
            
        case 'validate_workflow':
            // Validate that all workflow components are working
            $results = [];
            
            // Test 1: Check if demo data exists
            $supplierCount = $db->query("SELECT COUNT(*) as count FROM suppliers")->fetch()['count'];
            $productCount = $db->query("SELECT COUNT(*) as count FROM products")->fetch()['count'];
            $results[] = [
                'test' => 'Base Data',
                'success' => $supplierCount >= 4 && $productCount >= 10,
                'details' => "Suppliers: $supplierCount, Products: $productCount"
            ];
            
            // Test 2: Check API endpoints
            try {
                $testResponse = file_get_contents('http://' . $_SERVER['HTTP_HOST'] . dirname($_SERVER['REQUEST_URI']) . '/demo-config.php');
                $testData = json_decode($testResponse, true);
                $results[] = [
                    'test' => 'API Endpoints',
                    'success' => $testData && $testData['success'],
                    'details' => 'Demo config API accessible'
                ];
            } catch (Exception $e) {
                $results[] = [
                    'test' => 'API Endpoints',
                    'success' => false,
                    'details' => 'Error: ' . $e->getMessage()
                ];
            }
            
            // Test 3: Database operations
            try {
                $db->beginTransaction();
                
                // Test insert
                $testId = 'validation_test_' . uniqid();
                $testData = ['test' => true, 'timestamp' => date('Y-m-d\TH:i:s.000\Z')];
                $stmt = $db->prepare("INSERT INTO purchase_orders (id, data) VALUES (?, ?)");
                $stmt->execute([$testId, json_encode($testData)]);
                
                // Test select
                $stmt = $db->prepare("SELECT data FROM purchase_orders WHERE id = ?");
                $stmt->execute([$testId]);
                $retrieved = $stmt->fetch();
                
                // Test delete
                $stmt = $db->prepare("DELETE FROM purchase_orders WHERE id = ?");
                $stmt->execute([$testId]);
                
                $db->commit();
                
                $results[] = [
                    'test' => 'Database Operations',
                    'success' => $retrieved !== false,
                    'details' => 'CRUD operations functional'
                ];
            } catch (Exception $e) {
                $db->rollBack();
                $results[] = [
                    'test' => 'Database Operations',
                    'success' => false,
                    'details' => 'Error: ' . $e->getMessage()
                ];
            }
            
            $overallSuccess = array_reduce($results, fn($carry, $item) => $carry && $item['success'], true);
            
            json_response([
                'success' => $overallSuccess,
                'message' => $overallSuccess ? 'All validations passed' : 'Some validations failed',
                'data' => [
                    'overall' => $overallSuccess,
                    'results' => $results
                ]
            ]);
            break;
            
        default:
            json_error('Invalid action', 400);
    }
    
} catch (Exception $e) {
    json_error('Integration test failed: ' . $e->getMessage(), 500);
}