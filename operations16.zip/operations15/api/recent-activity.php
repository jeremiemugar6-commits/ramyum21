<?php
/**
 * Recent Activity API
 * Aggregates operational and security events into a unified timeline.
 *
 * GET params:
 *   limit     (int, default 100, max 500)
 *   type      (optional filter: inventory | transfer | security | all)
 *   search    (optional free-text search)
 *   since     (optional ISO date, e.g. 2026-10-01)
 *   until     (optional ISO date)
 */

require_once __DIR__ . '/../includes/auth.php';

require_login_api();

$db = getDB();

$limit  = min(max((int)($_GET['limit'] ?? 100), 1), 500);
$type   = strtolower(trim($_GET['type'] ?? 'all'));
$search = trim($_GET['search'] ?? '');
$since  = trim($_GET['since'] ?? '');
$until  = trim($_GET['until'] ?? '');

$activities = [];

// ---------------------------------------------------------------------------
// 1. Inventory Movements
// ---------------------------------------------------------------------------
if ($type === 'all' || $type === 'inventory') {
    $sql = 'SELECT id, data, created_at FROM inventory_movements';
    $params = [];
    $where = [];

    if ($since !== '') {
        $where[] = 'created_at >= ?';
        $params[] = $since . ' 00:00:00';
    }
    if ($until !== '') {
        $where[] = 'created_at <= ?';
        $params[] = $until . ' 23:59:59';
    }
    if ($where) {
        $sql .= ' WHERE ' . implode(' AND ', $where);
    }
    $sql .= ' ORDER BY created_at DESC LIMIT ' . (int)$limit;

    $stmt = $db->prepare($sql);
    $stmt->execute($params);
    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

    foreach ($rows as $row) {
        $data = json_decode($row['data'], true) ?: [];
        $title = ($data['type'] ?? 'Movement') . ': ' . ($data['productName'] ?? $data['productId'] ?? 'Unknown product');
        $qty   = isset($data['quantity']) ? (int)$data['quantity'] : (isset($data['change']) ? (int)$data['change'] : null);
        $descParts = [];
        if ($qty !== null) {
            $descParts[] = abs($qty) . ' unit(s)';
        }
        if (!empty($data['reason'])) {
            $descParts[] = $data['reason'];
        }
        if (!empty($data['referenceId'])) {
            $descParts[] = 'Ref: ' . $data['referenceId'];
        }
        if (!empty($data['notes'])) {
            $descParts[] = $data['notes'];
        }

        $activities[] = [
            'id'          => $row['id'],
            'source'      => 'inventory',
            'type'        => $data['type'] ?? 'Stock Movement',
            'category'    => 'inventory',
            'title'       => $title,
            'description' => implode(' · ', $descParts),
            'user'        => $data['user'] ?? null,
            'details'     => $data,
            'created_at'  => $row['created_at'],
            'icon'        => 'inventory',
            'color'       => in_array(strtolower($data['type'] ?? ''), ['stock in', 'in', 'receive', 'adjustment in'], true) ? '#10B981' : '#EF4444',
        ];
    }
}

// ---------------------------------------------------------------------------
// 2. Stock Transfer Audit
// ---------------------------------------------------------------------------
if ($type === 'all' || $type === 'transfer') {
    $sql = 'SELECT id, transfer_id, action_type, user_id, user_name, details, ip_address, created_at FROM stock_transfer_audit';
    $params = [];
    $where = [];

    if ($since !== '') {
        $where[] = 'created_at >= ?';
        $params[] = $since . ' 00:00:00';
    }
    if ($until !== '') {
        $where[] = 'created_at <= ?';
        $params[] = $until . ' 23:59:59';
    }
    if ($where) {
        $sql .= ' WHERE ' . implode(' AND ', $where);
    }
    $sql .= ' ORDER BY created_at DESC LIMIT ' . (int)$limit;

    try {
        $stmt = $db->prepare($sql);
        $stmt->execute($params);
        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

        foreach ($rows as $row) {
            $details = $row['details'] ? json_decode($row['details'], true) : [];
            $action  = $row['action_type'] ?? 'TRANSFER';
            $title   = str_replace('_', ' ', $action);
            if (!empty($details['transferNumber'])) {
                $title .= ': ' . $details['transferNumber'];
            }

            $descParts = [];
            if (!empty($details['sourceLocation']) && !empty($details['destinationLocation'])) {
                $descParts[] = $details['sourceLocation'] . ' → ' . $details['destinationLocation'];
            }
            if (isset($details['itemCount'])) {
                $descParts[] = $details['itemCount'] . ' item(s)';
            }
            if (!empty($details['status'])) {
                $descParts[] = 'Status: ' . $details['status'];
            }

            $activities[] = [
                'id'          => 'sta_' . $row['id'],
                'source'      => 'transfer',
                'type'        => $action,
                'category'    => 'transfer',
                'title'       => $title,
                'description' => implode(' · ', $descParts),
                'user'        => $row['user_name'] ?? null,
                'details'     => array_merge($details ?: [], [
                    'transfer_id' => $row['transfer_id'],
                    'ip_address'  => $row['ip_address'],
                ]),
                'created_at'  => $row['created_at'],
                'icon'        => 'transfer',
                'color'       => '#3B82F6',
            ];
        }
    } catch (Throwable $e) {
        // Table may not exist in some environments; skip silently.
    }
}

// ---------------------------------------------------------------------------
// 3. Security Logs (exclude noisy PAGE_ACCESS unless filtered)
// ---------------------------------------------------------------------------
if ($type === 'all' || $type === 'security') {
    $sql = 'SELECT id, event_type, user_id, username, details, ip_address, created_at FROM security_logs';
    $params = [];
    $where = [];

    // By default hide pure page-access noise when showing "all"
    if ($type === 'all') {
        $where[] = "event_type != 'PAGE_ACCESS'";
    }

    if ($since !== '') {
        $where[] = 'created_at >= ?';
        $params[] = $since . ' 00:00:00';
    }
    if ($until !== '') {
        $where[] = 'created_at <= ?';
        $params[] = $until . ' 23:59:59';
    }
    if ($where) {
        $sql .= ' WHERE ' . implode(' AND ', $where);
    }
    $sql .= ' ORDER BY created_at DESC LIMIT ' . (int)$limit;

    try {
        $stmt = $db->prepare($sql);
        $stmt->execute($params);
        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

        foreach ($rows as $row) {
            $details = $row['details'] ? json_decode($row['details'], true) : [];
            $event   = $row['event_type'] ?? 'EVENT';
            $title   = str_replace('_', ' ', $event);

            $descParts = [];
            if ($row['username']) {
                $descParts[] = 'User: ' . $row['username'];
            }
            if ($row['ip_address']) {
                $descParts[] = 'IP: ' . $row['ip_address'];
            }
            if (is_array($details) && !empty($details)) {
                $flat = [];
                foreach ($details as $k => $v) {
                    if (is_scalar($v)) {
                        $flat[] = $k . ': ' . $v;
                    }
                }
                if ($flat) {
                    $descParts[] = implode(', ', $flat);
                }
            }

            $colorMap = [
                'LOGIN_SUCCESS'        => '#10B981',
                'LOGIN_FAILED'         => '#EF4444',
                'LOGIN_BLOCKED_LOCKOUT'=> '#F59E0B',
                'LOGOUT'               => '#6B7280',
                'PASSWORD_CHANGED'     => '#3B82F6',
                'USER_CREATED'         => '#8B5CF6',
                'USER_UPDATED'         => '#8B5CF6',
                'USER_DELETED'         => '#EF4444',
            ];

            $activities[] = [
                'id'          => 'sec_' . $row['id'],
                'source'      => 'security',
                'type'        => $event,
                'category'    => 'security',
                'title'       => $title,
                'description' => implode(' · ', $descParts),
                'user'        => $row['username'] ?? null,
                'details'     => $details,
                'created_at'  => $row['created_at'],
                'icon'        => 'security',
                'color'       => $colorMap[$event] ?? '#6B7280',
            ];
        }
    } catch (Throwable $e) {
        // Skip on error
    }
}

// ---------------------------------------------------------------------------
// Merge, sort, search filter, limit
// ---------------------------------------------------------------------------
usort($activities, function ($a, $b) {
    return strcmp($b['created_at'], $a['created_at']);
});

if ($search !== '') {
    $q = mb_strtolower($search);
    $activities = array_values(array_filter($activities, function ($a) use ($q) {
        $hay = mb_strtolower(
            ($a['title'] ?? '') . ' ' .
            ($a['description'] ?? '') . ' ' .
            ($a['user'] ?? '') . ' ' .
            ($a['type'] ?? '') . ' ' .
            json_encode($a['details'] ?? [])
        );
        return str_contains($hay, $q);
    }));
}

$activities = array_slice($activities, 0, $limit);

// Summary counts
$summary = [
    'total'     => count($activities),
    'inventory' => 0,
    'transfer'  => 0,
    'security'  => 0,
];
foreach ($activities as $a) {
    if (isset($summary[$a['category']])) {
        $summary[$a['category']]++;
    }
}

json_response([
    'success'  => true,
    'data'     => $activities,
    'summary'  => $summary,
    'limit'    => $limit,
]);
