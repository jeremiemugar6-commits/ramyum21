<?php
/**
 * Diagnostic script to test user API access
 */

error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once __DIR__ . '/../includes/auth.php';

header('Content-Type: application/json');

// Check if session is active
if (session_status() !== PHP_SESSION_ACTIVE) {
    echo json_encode(['error' => 'Session not active']);
    exit;
}

// Check if user is logged in
if (!is_logged_in()) {
    echo json_encode(['error' => 'Not logged in', 'session' => $_SESSION]);
    exit;
}

// Get current user
$user = current_user();
if (!$user) {
    echo json_encode(['error' => 'User not found', 'session' => $_SESSION]);
    exit;
}

// Check role
if ($user['role'] !== 'admin') {
    echo json_encode(['error' => 'Not admin', 'user' => $user]);
    exit;
}

// Try to fetch users
try {
    $db = getDB();
    $stmt = $db->query("SELECT id, name, email, username, role FROM users ORDER BY created_at ASC");
    $users = $stmt->fetchAll();
    echo json_encode(['success' => true, 'count' => count($users), 'users' => $users]);
} catch (Exception $e) {
    echo json_encode(['error' => 'Database error', 'message' => $e->getMessage()]);
}
