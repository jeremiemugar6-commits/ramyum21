<?php
/**
 * Lets the logged-in user update their own display name and avatar.
 */

require_once __DIR__ . '/../includes/auth.php';

$user = require_login_api();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_error('Method not allowed.', 405);
}

$input = get_json_input();
$name = trim($input['name'] ?? '');
$profilePicture = $input['profilePicture'] ?? null; // base64 data URL, or null to leave unchanged

if ($name === '') {
    json_error('Name cannot be empty.');
}

$db = getDB();
if ($profilePicture !== null) {
    $stmt = $db->prepare('UPDATE users SET name = ?, profile_picture = ? WHERE id = ?');
    $stmt->execute([sanitize_recursive($name), $profilePicture, $user['id']]);
} else {
    $stmt = $db->prepare('UPDATE users SET name = ? WHERE id = ?');
    $stmt->execute([sanitize_recursive($name), $user['id']]);
}

$fresh = current_user();
json_response(['success' => true, 'user' => $fresh]);
