<?php
require_once __DIR__ . '/../includes/auth.php';

require_admin_api();

$db = getDB();
$stmt = $db->query('SELECT event_type, user_id, username, details, ip_address, created_at FROM security_logs ORDER BY created_at DESC LIMIT 200');
$logs = $stmt->fetchAll();

foreach ($logs as &$log) {
    $log['details'] = $log['details'] ? json_decode($log['details'], true) : null;
}

json_response(['success' => true, 'data' => $logs]);
