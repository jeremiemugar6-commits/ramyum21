# 📦 Quick Reference: Consolidated Receiving & Inspection

## One-Page Guide for Staff

---

## 🎯 What Changed?

**OLD:** Receive items first → Inspect later → Adjust inventory manually
**NEW:** Inspect while receiving → Only good items enter inventory

---

## 📋 Step-by-Step Process

### 1. Start Receiving
```
Go to: Receiving & Inspection module
Click: "Receive & Inspect Delivery" button
Select: Approved Purchase Order from list
```

### 2. For Each Item, Enter 4 Numbers

| Input | What It Means | Example |
|-------|---------------|---------|
| **Received** | Total boxes delivered | 100 |
| **Accepted** | Good quality items | 95 |
| **Rejected** | Poor quality | 3 |
| **Damaged** | Broken/crushed | 2 |

**RULE:** Accepted + Rejected + Damaged = Received
**Example:** 95 + 3 + 2 = 100 ✓

### 3. Add Notes
```
Write down:
- Why items were rejected (expired, wrong product, etc.)
- Damage details (crushed box, torn packaging)
- Any other observations
```

### 4. Submit
```
Click: "Complete Receiving & Inspection"
System creates:
  ✓ Receiving record (GR-YYYY-NNNN)
  ✓ POR record (POR-YYYY-NNNN)
  ✓ Updates inventory (accepted items only)
```

---

## ✅ What Happens Automatically

1. **Receiving Number Generated** - Example: GR-2026-0001
2. **POR Number Generated** - Example: POR-2026-0001
3. **Inventory Updated** - Only accepted items added to stock
4. **PO Status Changed** - "Partially Received" or "Fully Received"
5. **Audit Trail Logged** - Complete history recorded

---

## ⚠️ Common Mistakes

### ❌ Quantities Don't Match
```
Received: 100
Accepted: 95
Rejected: 0
Damaged: 0
Total: 95 ≠ 100 ❌ ERROR
```

**Fix:** Make sure totals match!
```
Received: 100
Accepted: 95
Rejected: 5
Damaged: 0  
Total: 100 ✓ CORRECT
```

### ❌ Negative Numbers
```
Accepted: -5  ❌ Not allowed
```

**Fix:** All numbers must be 0 or positive

### ❌ Empty Fields
```
Received: 100
Accepted: (empty)  ❌ Required
```

**Fix:** Fill in all required fields

---

## 📊 What Gets Added to Inventory?

**ONLY the "Accepted" quantity!**

Example:
```
Item: Shin Ramyun
Received: 100 boxes
Accepted: 95 boxes ← Only this added to inventory
Rejected: 3 boxes  ← NOT added
Damaged: 2 boxes   ← NOT added

Result: Inventory increases by 95
```

---

## 🔍 Where to View Results

### Receiving Module
- Tab: "Receiving History"
- Shows: GR numbers, dates, quantities

### POR Module  
- Shows: Inspection results, acceptance rates
- Status: Passed/Failed/Conditional

### Inventory Module
- Shows: Updated stock levels
- Only reflects accepted items

---

## 🆘 Error Messages & Fixes

| Error Message | Cause | Solution |
|---------------|-------|----------|
| "Quantities don't match" | Math doesn't add up | Double-check your numbers |
| "PO not Approved" | Wrong PO status | Approve PO first |
| "Cannot exceed remaining" | Too many items | Check what's already received |
| "Product not found" | Deleted product | Contact admin |

---

## 📞 Need Help?

**Before calling support:**
1. ✓ Check quantities add up correctly
2. ✓ Make sure PO is approved
3. ✓ Verify all required fields filled
4. ✓ Try refreshing the page

**Still stuck?**
- Check CONSOLIDATED_RECEIVING_WORKFLOW.md (detailed guide)
- Contact IT support with GR/POR numbers

---

## 💡 Pro Tips

✅ **Enter received quantity first** - System auto-fills accepted
✅ **Use damaged for physical issues** - Torn, crushed, broken
✅ **Use rejected for quality issues** - Expired, wrong spec, contaminated  
✅ **Add detailed notes** - Helps with supplier complaints
✅ **Take photos** - Keep phone pictures for reference

---

## 🎯 Quick Example

**Scenario:** Receiving 50 boxes of Shin Ramyun

```
Step 1: Count physical delivery
        Truck delivered 50 boxes

Step 2: Inspect each box
        45 boxes = perfect condition
        3 boxes = slightly dented (acceptable)  
        2 boxes = badly crushed (reject)

Step 3: Enter numbers
        Received: 50
        Accepted: 48 (45 perfect + 3 dented)
        Rejected: 0
        Damaged: 2 (badly crushed)
        
Step 4: Add notes
        "2 boxes severely crushed, liquid leaking"

Step 5: Submit
        ✓ GR-2026-0001 created
        ✓ POR-2026-0001 created
        ✓ Inventory +48 (not +50!)
        ✓ PO updated
```

**Result:**
- Warehouse has 48 sellable units
- 2 damaged units not in inventory
- Supplier can be contacted about damage
- Accounting knows to deduct 2 units from invoice

---

## 📅 Daily Checklist

- [ ] Check for approved POs awaiting delivery
- [ ] Physically count all delivered items
- [ ] Inspect each item for quality/damage
- [ ] Record accurate quantities
- [ ] Add detailed notes for any issues
- [ ] Submit receiving form
- [ ] Verify success message
- [ ] Confirm inventory updated correctly

---

**Remember:** Inspect BEFORE receiving = Accurate inventory always! ✅

**Version:** 2.0 | **Last Updated:** October 3, 2026
