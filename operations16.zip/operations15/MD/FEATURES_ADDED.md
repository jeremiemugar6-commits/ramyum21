# Features Added

## 1. Promo Pricing (SRP management)
- **Where:** Product Catalog → **Promo Pricing** button (admin/manager)
- Also on each product form under "Promo Pricing (optional)"
- Fields: Promo SRP, Promo Start, Promo End
- Active promos show struck regular SRP + promo price with PROMO badge

## 2. Expiration Bridge
- **Where:** Inventory Management → **Expiration Bridge** tab
- Cards for Expired / 7 days / 30 days / 60 days
- Filter + search to see exactly which products expire when
- Urgency: EXPIRED, CRITICAL, SOON, WATCH, OK

## 3. Stock Movements — no Edit button
- Movements table uses **Details** (view-only) instead of Edit
- Audit trail stays immutable

## 4. Seasonal Events — Product Suggestions
- **Where:** Product Catalog → **Seasonal** button
- Event → category mapping (New Year, Summer, Christmas, Rainy season, etc.)
- Shows matching products, low stock, and near-expiry for promo focus
