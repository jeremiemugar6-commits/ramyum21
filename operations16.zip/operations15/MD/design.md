# Proof of Receiving (POR) Feature - Design Document

**Project:** RAM-YUM Product & Inventory Operations System  
**Feature:** Proof of Receiving (POR) Enhancement  
**Date:** October 3, 2026  
**Version:** 1.0

---

## EXECUTIVE SUMMARY

This document specifies the technical design for implementing the Proof of Receiving (POR) feature as an enhancement to the existing Receiving & Inspection module. The design follows a non-breaking, additive approach that preserves all existing functionality while adding formal inspection, damage tracking, and document generation capabilities.

---

## ARCHITECTURE OVERVIEW

**Design Principles:**
1. **Additive, not destructive** - Enhance existing `receivings` table, don't recreate
2. **Reuse existing patterns** - Follow `api/data.php` conventions, existing component patterns
3. **Backward compatible** - Existing receiving records continue to work
4. **Safe migrations** - Idempotent SQL, column additions only

**System Components:**
```
┌─────────────────────────────────────────────────────────────┐
│                    Frontend (Browser)                        │
├─────────────────────────────────────────────────────────────┤
│  modules/receiving/receiving.js (enhanced)                  │
│  - Multi-step receiving wizard                              │
│  - Inspection UI with quantity breakdown                    │
│  - Damage evidence upload integration                       │
│  - POR document view/print                                  │
└────────────┬────────────────────────────────────────────────┘
             │
             │ AJAX (fetch)
             │
┌────────────▼────────────────────────────────────────────────┐
│                    Backend (PHP)                             │
├─────────────────────────────────────────────────────────────┤
│  api/data.php (existing, enhanced validation)               │
│  api/upload-image.php (existing, reused)                    │
│  api/damage-evidence.php (new)                              │
│  includes/auth.php (existing, role checks)                  │
│  includes/functions.php (existing, audit logging)           │
└────────────┬────────────────────────────────────────────────┘
             │
             │ MySQL PDO
             │
┌────────────▼────────────────────────────────────────────────┐
│                    Database (MySQL)                          │
├─────────────────────────────────────────────────────────────┤
│  receivings (enhanced JSON schema)                          │
│  damage_evidence (existing, now used)                       │
│  inventory_movements (existing, enhanced)                   │
│  security_logs (existing, new event types)                  │
│  products (existing, unchanged)                             │
│  purchase_orders (existing, unchanged)                      │
└─────────────────────────────────────────────────────────────┘
```

---

## DATABASE DESIGN

### 1. Enhanced `receivings` Table Schema

**Current Structure:** JSON data storage in `receivings.data` column

**Enhanced JSON Schema:**

```json
{
  // === EXISTING FIELDS (preserve) ===
  "id": "receivings_1234567890_abc123",
  "receivingNumber": "GR-2026-0001",  // Keep existing format
  "poId": "purchase_orders_123_456",
  "poNumber": "PO-2026-0001",
  "supplierId": "s1",
  "supplier": "ABC Korean Food Distributor",
  "receivedDate": "2026-10-03T10:30:00.000Z",
  "receivedBy": "Admin User",
  "totalReceived": 98,
  "totalValue": 4900.00,
  "notes": "Delivery received",
  "status": "Completed",
  
  // === NEW POR FIELDS ===
  "porNumber": "GR-2026-0001",  // Same as receivingNumber for compatibility
  "deliveryReferenceNumber": "DEL-12345",
  "supplierInvoiceNumber": "INV-67890",
  "location": "Main Store",
  
  // Inspection tracking
  "inspectionStatus": "Completed",  // Draft | Pending Inspection | Inspected | Completed | Cancelled
  "inspectionDate": "2026-10-03T11:00:00.000Z",
  "inspectedBy": "Staff User",
  
  // Quantity summaries
  "totalOrdered": 100,
  "totalDelivered": 98,
  "totalAccepted": 95,
  "totalRejected": 1,
  "totalDamaged": 2,
  "totalMissing": 2,
  "totalExcess": 0,
  
  // === ENHANCED ITEMS ARRAY ===
  "items": [
    {
      // Existing fields (preserve)
      "productId": "p1",
      "productName": "Samyang Buldak Original",
      "orderedQuantity": 50,
      "previouslyReceived": 0,
      "quantityReceived": 50,  // DEPRECATED in favor of deliveredQuantity
      "newTotalReceived": 48,  // This is actually acceptedQuantity
      "unitCost": 65.00,
      "subtotal": 3120.00,  // acceptedQuantity * unitCost
      
      // New fields
      "sku": "SB-001",
      "unit": "Pack",
      "deliveredQuantity": 50,
      "acceptedQuantity": 48,
      "rejectedQuantity": 0,
      "damagedQuantity": 2,
      "missingQuantity": 0,
      "excessQuantity": 0,
      "batchNumber": "BATCH-2026-0123",
      "expirationDate": "2027-10-01",
      "inspectionResult": "Accepted with Discrepancy",  // Accepted | Accepted with Discrepancy | Partially Accepted | Rejected
      "discrepancyType": "Damaged",  // null | Damaged | Incorrect | Expired | Short | Excess | Quality Issue | Other
      "itemRemarks": "2 packages had torn outer wrapping",
      "damageEvidenceIds": ["damage_evidence_123", "damage_evidence_124"]
    }
  ]
}
```

**Backward Compatibility Strategy:**
- Existing records without new fields will still work
- Frontend checks for field existence before rendering
- `quantityReceived` maps to `acceptedQuantity` if new fields absent
- Migration script adds default values for existing records

**No Table Structure Changes:**
- Table structure remains: `id`, `data` (JSON), `created_at`, `updated_at`
- All changes are within JSON data column
- No ALTER TABLE required
- Safe and non-breaking

---

### 2. `damage_evidence` Table (Existing, Now Used)

**Current Schema:**
```sql
CREATE TABLE IF NOT EXISTS `damage_evidence` (
  `id` varchar(40) NOT NULL PRIMARY KEY,
  `receiving_id` varchar(40) NOT NULL,
  `po_id` varchar(40) NOT NULL,
  `po_number` varchar(50) NOT NULL,
  `product_id` varchar(40) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `ordered_quantity` decimal(12,2) NOT NULL DEFAULT 0,
  `received_quantity` decimal(12,2) NOT NULL DEFAULT 0,
  `damaged_quantity` decimal(12,2) NOT NULL DEFAULT 0,
  `damage_description` text DEFAULT NULL,
  `evidence_image_path` varchar(500) DEFAULT NULL,
  `recorded_by` varchar(100) NOT NULL,
  `recorded_at` datetime NOT NULL DEFAULT current_timestamp(),
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  KEY `idx_receiving_id` (`receiving_id`),
  KEY `idx_po_id` (`po_id`),
  KEY `idx_product_id` (`product_id`),
  KEY `idx_recorded_at` (`recorded_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
```

**Usage:**
- One record per damaged/rejected item per receiving
- `evidence_image_path`: relative path like `uploads/damage-evidence/2026/10/img_1696329000_abc123.jpg`
- Multiple photos per item: create multiple records or use comma-separated paths

**Photo Storage Structure:**
```
/uploads/
  /damage-evidence/
    /2026/
      /10/
        img_1696329000_abc123.jpg
        img_1696329001_def456.jpg
```

---

### 3. Enhanced `inventory_movements` Table

**Current Structure:** JSON data storage

**Enhanced JSON Schema:**

```json
{
  // Existing fields
  "id": "inventory_movements_123_abc",
  "productId": "p1",
  "productName": "Samyang Buldak Original",
  "sku": "SB-001",
  "date": "2026-10-03T11:00:00.000Z",
  "type": "Stock In",  // or "Stock Out" for rejected/damaged
  "referenceType": "RECEIVING",  // or "DAMAGE", "REJECTION"
  "referenceId": "GR-2026-0001",
  "referencePO": "PO-2026-0001",
  "quantity": 48,  // positive for accepted, negative for rejected/damaged
  "previousBalance": 100,
  "newBalance": 148,
  "change": 48,
  "reason": "Purchase Order Receiving - POR",
  "notes": "Delivered: 50, Accepted: 48, Damaged: 2",
  "user": "Admin User",
  "unitCost": 65.00,
  
  // New fields for better tracking
  "deliveredQuantity": 50,
  "acceptedQuantity": 48,
  "rejectedQuantity": 0,
  "damagedQuantity": 2,
  "inspectionResult": "Accepted with Discrepancy"
}
```

**Multiple Movement Records Per Receiving:**

1. **Accepted Quantity** (Stock In):
```json
{
  "type": "Stock In",
  "referenceType": "RECEIVING",
  "quantity": 48,
  "reason": "Purchase Order Receiving - Accepted"
}
```

2. **Damaged Quantity** (Stock Out/Adjustment):
```json
{
  "type": "Stock Adjustment",
  "referenceType": "DAMAGE",
  "quantity": -2,
  "reason": "Damaged During Receiving",
  "notes": "Linked to damage evidence: damage_evidence_123"
}
```

---

### 4. `security_logs` Table (Existing, New Event Types)

**New Event Types to Add:**

```php
// includes/functions.php - add these event types
const SECURITY_EVENT_TYPES = [
    // Existing events...
    'LOGIN_SUCCESS',
    'LOGIN_FAILED',
    // ... etc
    
    // New POR events
    'POR_CREATED',
    'POR_DRAFT_SAVED',
    'POR_INSPECTION_STARTED',
    'POR_INSPECTION_COMPLETED',
    'POR_COMPLETED',
    'POR_CANCELLED',
    'POR_EDITED',
    'POR_VIEWED',
    'POR_PRINTED',
    'DAMAGE_EVIDENCE_UPLOADED',
    'DAMAGE_EVIDENCE_VIEWED'
];
```

**Example Log Entry:**
```php
log_security_event('POR_COMPLETED', 'u1', 'admin', [
    'porNumber' => 'GR-2026-0001',
    'poNumber' => 'PO-2026-0001',
    'supplier' => 'ABC Foods',
    'totalOrdered' => 100,
    'totalDelivered' => 98,
    'totalAccepted' => 95,
    'totalDamaged' => 2,
    'totalRejected' => 1,
    'inventoryImpact' => '+95'
]);
```

---

## API DESIGN

### 1. Enhanced `api/data.php`

**Current Implementation:** Generic CRUD for all collections

**Enhancements Needed:**

**Add validation for `receivings` collection:**

```php
// In api/data.php, add special handling for receivings

case 'POST':
    $input = get_json_input();
    $input = sanitize_recursive($input);
    
    // Special validation for receivings
    if ($collection === 'receivings') {
        $input = validate_receiving_data($input);
    }
    
    $input = coerce_numeric_fields($input);
    $id = generate_id($collection);
    $input['id'] = $id;
    
    $stmt = $db->prepare("INSERT INTO `$collection` (id, data) VALUES (?, ?)");
    $stmt->execute([$id, json_encode($input)]);
    
    json_response(['success' => true, 'data' => $input], 201);
    break;

// Add validation function
function validate_receiving_data($data) {
    // Validate quantities add up correctly
    if (isset($data['items'])) {
        foreach ($data['items'] as &$item) {
            $delivered = $item['deliveredQuantity'] ?? 0;
            $accepted = $item['acceptedQuantity'] ?? 0;
            $rejected = $item['rejectedQuantity'] ?? 0;
            $damaged = $item['damagedQuantity'] ?? 0;
            
            // deliveredQuantity = acceptedQuantity + rejectedQuantity + damagedQuantity
            $sum = $accepted + $rejected + $damaged;
            if ($sum != $delivered) {
                json_error("Item {$item['productName']}: quantities don't add up. Delivered: {$delivered}, Sum: {$sum}", 400);
            }
            
            // Calculate missing/excess
            $ordered = $item['orderedQuantity'] ?? 0;
            $item['missingQuantity'] = max(0, $ordered - $delivered);
            $item['excessQuantity'] = max(0, $delivered - $ordered);
        }
    }
    
    return $data;
}
```

**No Changes to Existing Endpoints:**
- GET, PUT, DELETE remain unchanged
- POST enhanced with validation only
- Backward compatible with existing code

---

### 2. New `api/damage-evidence.php`

**Purpose:** Handle damage evidence creation and retrieval

**Endpoints:**

#### **POST** - Upload damage evidence with photo

```php
<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';

require_login_api();

$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'POST') {
    $receivingId = $_POST['receivingId'] ?? '';
    $poId = $_POST['poId'] ?? '';
    $poNumber = $_POST['poNumber'] ?? '';
    $productId = $_POST['productId'] ?? '';
    $productName = $_POST['productName'] ?? '';
    $orderedQty = floatval($_POST['orderedQuantity'] ?? 0);
    $receivedQty = floatval($_POST['receivedQuantity'] ?? 0);
    $damagedQty = floatval($_POST['damagedQuantity'] ?? 0);
    $description = sanitize($_POST['damageDescription'] ?? '');
    
    $currentUser = $_SESSION['user'] ?? null;
    if (!$currentUser) {
        json_error('Unauthorized', 401);
    }
    
    // Validate required fields
    if (!$receivingId || !$poId || !$productId || $damagedQty <= 0) {
        json_error('Missing required fields', 400);
    }
    
    // Handle photo upload
    if (!isset($_FILES['photo']) || $_FILES['photo']['error'] !== UPLOAD_ERR_OK) {
        json_error('Photo is required for damage evidence', 400);
    }
    
    // Reuse existing upload logic
    $uploadResult = upload_damage_photo($_FILES['photo']);
    if (!$uploadResult['success']) {
        json_error($uploadResult['message'], 400);
    }
    
    // Create damage evidence record
    $db = getDB();
    $evidenceId = generate_id('damage_evidence');
    
    $stmt = $db->prepare("
        INSERT INTO damage_evidence (
            id, receiving_id, po_id, po_number, product_id, product_name,
            ordered_quantity, received_quantity, damaged_quantity,
            damage_description, evidence_image_path, recorded_by
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ");
    
    $stmt->execute([
        $evidenceId,
        $receivingId,
        $poId,
        $poNumber,
        $productId,
        $productName,
        $orderedQty,
        $receivedQty,
        $damagedQty,
        $description,
        $uploadResult['path'],
        $currentUser['name']
    ]);
    
    log_security_event('DAMAGE_EVIDENCE_UPLOADED', $currentUser['id'], $currentUser['username'], [
        'evidenceId' => $evidenceId,
        'poNumber' => $poNumber,
        'productName' => $productName,
        'damagedQuantity' => $damagedQty
    ]);
    
    json_response([
        'success' => true,
        'data' => [
            'id' => $evidenceId,
            'path' => $uploadResult['path'],
            'url' => $uploadResult['url']
        ]
    ], 201);
}

if ($method === 'GET') {
    $receivingId = $_GET['receivingId'] ?? '';
    
    if (!$receivingId) {
        json_error('Missing receivingId', 400);
    }
    
    $db = getDB();
    $stmt = $db->prepare("SELECT * FROM damage_evidence WHERE receiving_id = ? ORDER BY recorded_at DESC");
    $stmt->execute([$receivingId]);
    $evidence = $stmt->fetchAll();
    
    json_response(['success' => true, 'data' => $evidence]);
}

function upload_damage_photo($file) {
    // Validation
    $allowedTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/webp'];
    $maxSize = 5 * 1024 * 1024; // 5MB
    
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mimeType = finfo_file($finfo, $file['tmp_name']);
    finfo_close($finfo);
    
    if (!in_array($mimeType, $allowedTypes)) {
        return ['success' => false, 'message' => 'Invalid file type. Only JPG, PNG, WEBP allowed.'];
    }
    
    if ($file['size'] > $maxSize) {
        return ['success' => false, 'message' => 'File too large. Maximum 5MB.'];
    }
    
    // Create directory structure
    $year = date('Y');
    $month = date('m');
    $uploadDir = __DIR__ . "/../uploads/damage-evidence/{$year}/{$month}";
    
    if (!is_dir($uploadDir)) {
        mkdir($uploadDir, 0755, true);
    }
    
    // Generate unique filename
    $extension = pathinfo($file['name'], PATHINFO_EXTENSION);
    $filename = 'img_' . time() . '_' . bin2hex(random_bytes(8)) . '.' . $extension;
    $fullPath = $uploadDir . '/' . $filename;
    $relativePath = "uploads/damage-evidence/{$year}/{$month}/{$filename}";
    
    // Move uploaded file
    if (!move_uploaded_file($file['tmp_name'], $fullPath)) {
        return ['success' => false, 'message' => 'Failed to save file'];
    }
    
    return [
        'success' => true,
        'path' => $relativePath,
        'url' => '/' . $relativePath
    ];
}
```

---

### 3. Enhanced Inventory Update Logic

**Current Location:** `modules/receiving/receiving.js` line ~440

**Current Code:**
```javascript
const newStock = parseInt(product.stock) + receivingItem.quantityReceived;
```

**New Code:**
```javascript
// Use acceptedQuantity, not deliveredQuantity or quantityReceived
const acceptedQty = receivingItem.acceptedQuantity ?? receivingItem.quantityReceived ?? 0;
const newStock = parseInt(product.stock) + acceptedQty;
```

**Additional: Create separate movement for damaged items:**
```javascript
// After creating accepted quantity movement, create damage movement if applicable
if (receivingItem.damagedQuantity && receivingItem.damagedQuantity > 0) {
    const damageMovement = {
        productId: product.id,
        productName: product.name,
        sku: product.sku || 'N/A',
        date: new Date().toISOString(),
        type: 'Stock Adjustment',
        referenceType: 'DAMAGE',
        referenceId: receivingNumber,
        referencePO: poData.poNumber,
        quantity: -receivingItem.damagedQuantity,  // Negative
        previousBalance: newStock,
        newBalance: newStock,  // No actual stock change (never entered inventory)
        change: 0,
        reason: 'Damaged During Receiving',
        notes: `Damaged items removed during POR ${receivingNumber}`,
        user: store.getState().user?.name || 'System',
        unitCost: receivingItem.unitCost,
        damagedQuantity: receivingItem.damagedQuantity
    };
    
    await dataService.create('inventory_movements', damageMovement);
}
```

---

## FRONTEND DESIGN

### 1. Enhanced `modules/receiving/receiving.js`

**New Structure:**

```javascript
// === EXISTING CODE (preserve) ===
import { DataService } from '../../assets/js/utils/data-service.js';
import { toast } from '../../assets/js/components/toast.js';
import { modal } from '../../assets/js/components/modal.js';
import { DataTable } from '../../assets/js/components/table.js';
import { store } from '../../assets/js/store.js';
import { formatCurrency } from '../../assets/js/utils/format.js';
import { BadgeHelper } from '../../assets/js/utils/badge-helper.js';

const dataService = new DataService();

// === NEW: Multi-step receiving state ===
let receivingState = {
    step: 1,  // 1: Delivery, 2: Inspection, 3: Review
    poData: null,
    deliveryData: {},
    inspectionData: {},
    damageEvidence: []
};

// === EXISTING: Generate receiving number (keep) ===
async function generateReceivingNumber() {
    // ... existing code unchanged ...
}

// === EXISTING: renderReceiving() (enhance tabs) ===
export async function renderReceiving() {
    // ... existing code ...
    
    // Add third tab for In Progress PORs
    container.innerHTML = `
        <div style="display:flex; gap:8px; margin-bottom:16px; border-bottom:1px solid var(--border-color); padding-bottom:12px;">
            <button class="view-tab active" data-view="pending">Pending Deliveries</button>
            <button class="view-tab" data-view="in-progress">In Progress</button>
            <button class="view-tab" data-view="history">Receiving History</button>
        </div>
        <div id="receivingDataContainer"></div>
    `;
    
    // Add tab click handlers (existing + new)
}

// === NEW: Render In Progress PORs ===
async function renderInProgressView() {
    const container = document.getElementById('receivingDataContainer');
    const allReceivings = await dataService.findAll('receivings');
    const inProgressPORs = allReceivings.filter(r => 
        r.inspectionStatus === 'Draft' || r.inspectionStatus === 'Pending Inspection'
    );
    
    if (inProgressPORs.length === 0) {
        container.innerHTML = `
            <div class="card" style="text-align:center; padding:40px;">
                <p style="color:var(--text-secondary);">No PORs in progress.</p>
            </div>
        `;
        return;
    }
    
    // ... render table of in-progress PORs with Resume button ...
}

// === ENHANCED: Multi-step receiving modal ===
async function openReceivingModal(existingPO = null) {
    // Reset state
    receivingState = {
        step: 1,
        poData: existingPO,
        deliveryData: {},
        inspectionData: {},
        damageEvidence: []
    };
    
    if (!existingPO) {
        // ... existing PO selection code ...
    } else {
        renderReceivingStep1(existingPO);
    }
}

// === NEW: Step 1 - Delivery Quantities ===
function renderReceivingStep1(poData) {
    receivingState.poData = poData;
    
    const headerHTML = `
        <div style="margin-bottom:16px;">
            <div style="display:flex; gap:16px; margin-bottom:12px;">
                <div style="flex:1;">
                    <label style="display:block; font-weight:500; margin-bottom:4px;">Delivery Reference #</label>
                    <input type="text" id="deliveryRef" class="form-input" placeholder="e.g., DEL-12345">
                </div>
                <div style="flex:1;">
                    <label style="display:block; font-weight:500; margin-bottom:4px;">Supplier Invoice #</label>
                    <input type="text" id="supplierInvoice" class="form-input" placeholder="e.g., INV-67890">
                </div>
            </div>
        </div>
    `;
    
    const itemsHTML = poData.items.map((item, index) => `
        <div class="delivery-item" style="display:grid; grid-template-columns:2fr 1fr 1fr 1fr 1fr; gap:8px; padding:12px; border:1px solid var(--border-color); border-radius:8px; margin-bottom:8px;">
            <div>
                <div style="font-weight:500;">${item.productName}</div>
                <div style="font-size:0.8rem; color:var(--text-secondary);">${item.sku || 'N/A'} • ${item.unit || 'Pack'} • ₱${formatCurrency(item.unitCost)} each</div>
            </div>
            <div style="text-align:center;">
                <label style="font-size:0.8rem; display:block; margin-bottom:2px;">Ordered</label>
                <div style="font-weight:600;">${item.quantity}</div>
            </div>
            <div style="text-align:center;">
                <label style="font-size:0.8rem; display:block; margin-bottom:2px;">Previously</label>
                <div style="font-weight:600; color:#10B981;">${item.receivedQuantity || 0}</div>
            </div>
            <div style="text-align:center;">
                <label style="font-size:0.8rem; display:block; margin-bottom:2px;">Remaining</label>
                <div style="font-weight:600; color:#F59E0B;">${item.quantity - (item.receivedQuantity || 0)}</div>
            </div>
            <div>
                <label style="font-size:0.8rem; display:block; margin-bottom:2px;">Delivered Now</label>
                <input type="number" class="delivered-qty" min="0" max="${item.quantity - (item.receivedQuantity || 0)}" 
                       value="${item.quantity - (item.receivedQuantity || 0)}" 
                       data-item-index="${index}" style="width:100%; padding:4px; border:1px solid var(--border-color); border-radius:4px;">
                
                <div style="margin-top:8px; display:flex; gap:4px;">
                    <input type="text" class="batch-number" placeholder="Batch #" data-item-index="${index}" style="flex:1; padding:4px; font-size:0.8rem;">
                    <input type="date" class="expiry-date" data-item-index="${index}" style="flex:1; padding:4px; font-size:0.8rem;">
                </div>
            </div>
        </div>
    `).join('');
    
    const formHTML = `
        <div style="margin-bottom:16px;">
            <div style="background:#EFF6FF; border-left:4px solid #3B82F6; padding:12px; border-radius:4px; margin-bottom:16px;">
                <strong style="color:#1E40AF;">Step 1 of 3:</strong> Record Delivery Quantities
            </div>
            
            ${headerHTML}
            
            <h4 style="margin-bottom:8px;">Items Delivered</h4>
            ${itemsHTML}
        </div>
    `;
    
    modal.open(`POR: ${poData.poNumber} - Delivery`, formHTML, {
        confirmText: 'Next: Inspection →',
        cancelText: 'Save Draft',
        onCancel: () => saveDraft(),
        onConfirm: () => {
            collectStep1Data();
            renderReceivingStep2();
        }
    });
}

// === NEW: Step 2 - Inspection ===
function renderReceivingStep2() {
    const poData = receivingState.poData;
    const deliveryData = receivingState.deliveryData;
    
    const itemsHTML = poData.items.map((item, index) => {
        const delivered = deliveryData.items[index].deliveredQuantity;
        
        return `
            <div class="inspection-item" style="border:1px solid var(--border-color); border-radius:8px; padding:16px; margin-bottom:16px;">
                <h4 style="margin-bottom:12px;">${item.productName}</h4>
                <div style="display:grid; grid-template-columns:repeat(6, 1fr); gap:8px; margin-bottom:12px;">
                    <div>
                        <label style="font-size:0.8rem; color:var(--text-secondary);">Ordered</label>
                        <div style="font-weight:600;">${item.quantity}</div>
                    </div>
                    <div>
                        <label style="font-size:0.8rem; color:var(--text-secondary);">Delivered</label>
                        <div style="font-weight:600; color:#3B82F6;">${delivered}</div>
                    </div>
                    <div>
                        <label style="font-size:0.8rem; color:var(--text-secondary);">Accepted</label>
                        <input type="number" class="accepted-qty" min="0" max="${delivered}" value="${delivered}" 
                               data-item-index="${index}" style="width:100%; padding:4px;">
                    </div>
                    <div>
                        <label style="font-size:0.8rem; color:var(--text-secondary);">Rejected</label>
                        <input type="number" class="rejected-qty" min="0" max="${delivered}" value="0" 
                               data-item-index="${index}" style="width:100%; padding:4px;">
                    </div>
                    <div>
                        <label style="font-size:0.8rem; color:var(--text-secondary);">Damaged</label>
                        <input type="number" class="damaged-qty" min="0" max="${delivered}" value="0" 
                               data-item-index="${index}" style="width:100%; padding:4px;">
                    </div>
                    <div>
                        <label style="font-size:0.8rem; color:var(--text-secondary);">Missing</label>
                        <div class="missing-qty" style="font-weight:600; color:#F59E0B;" data-item-index="${index}">${item.quantity - delivered}</div>
                    </div>
                </div>
                
                <div style="margin-bottom:12px;">
                    <label style="font-size:0.8rem; display:block; margin-bottom:4px;">Inspection Result</label>
                    <select class="inspection-result" data-item-index="${index}" style="width:100%; padding:8px;">
                        <option value="Accepted">Accepted</option>
                        <option value="Accepted with Discrepancy">Accepted with Discrepancy</option>
                        <option value="Partially Accepted">Partially Accepted</option>
                        <option value="Rejected">Rejected</option>
                    </select>
                </div>
                
                <div style="margin-bottom:12px;">
                    <label style="font-size:0.8rem; display:block; margin-bottom:4px;">Remarks</label>
                    <textarea class="item-remarks" data-item-index="${index}" rows="2" style="width:100%; padding:8px; resize:vertical;"></textarea>
                </div>
                
                <div class="damage-upload-section" style="display:none; background:#FEF2F2; padding:12px; border-radius:4px; border:1px solid #FCA5A5;">
                    <label style="font-size:0.8rem; font-weight:600; color:#991B1B; display:block; margin-bottom:8px;">
                        📸 Damage Evidence Required
                    </label>
                    <input type="file" class="damage-photo" accept="image/jpeg,image/jpg,image/png,image/webp" 
                           data-item-index="${index}" style="width:100%;">
                    <div class="photo-preview" data-item-index="${index}" style="margin-top:8px;"></div>
                </div>
            </div>
        `;
    }).join('');
    
    const formHTML = `
        <div>
            <div style="background:#FEF3C7; border-left:4px solid #F59E0B; padding:12px; border-radius:4px; margin-bottom:16px;">
                <strong style="color:#92400E;">Step 2 of 3:</strong> Inspect Items
            </div>
            ${itemsHTML}
        </div>
    `;
    
    modal.open(`POR: ${poData.poNumber} - Inspection`, formHTML, {
        confirmText: 'Next: Review →',
        cancelText: '← Back',
        onCancel: () => renderReceivingStep1(poData),
        onConfirm: async () => {
            if (await collectStep2Data()) {
                renderReceivingStep3();
            }
        }
    });
    
    // Add quantity validation
    attachInspectionValidation();
}

// === NEW: Step 3 - Review & Confirm ===
function renderReceivingStep3() {
    const poData = receivingState.poData;
    const deliveryData = receivingState.deliveryData;
    const inspectionData = receivingState.inspectionData;
    
    // Calculate totals
    const totals = {
        ordered: 0,
        delivered: 0,
        accepted: 0,
        rejected: 0,
        damaged: 0,
        missing: 0
    };
    
    inspectionData.items.forEach(item => {
        totals.ordered += item.orderedQuantity;
        totals.delivered += item.deliveredQuantity;
        totals.accepted += item.acceptedQuantity;
        totals.rejected += item.rejectedQuantity;
        totals.damaged += item.damagedQuantity;
        totals.missing += item.missingQuantity;
    });
    
    const summaryHTML = `
        <div style="display:grid; grid-template-columns:repeat(3, 1fr); gap:16px; margin-bottom:24px;">
            <div style="background:#DBEAFE; padding:16px; border-radius:8px; text-align:center;">
                <div style="font-size:2rem; font-weight:700; color:#1E40AF;">${totals.delivered}</div>
                <div style="font-size:0.9rem; color:#1E3A8A;">Delivered</div>
            </div>
            <div style="background:#D1FAE5; padding:16px; border-radius:8px; text-align:center;">
                <div style="font-size:2rem; font-weight:700; color:#065F46;">${totals.accepted}</div>
                <div style="font-size:0.9rem; color:#064E3B;">Accepted</div>
            </div>
            <div style="background:#FEE2E2; padding:16px; border-radius:8px; text-align:center;">
                <div style="font-size:2rem; font-weight:700; color:#991B1B;">${totals.damaged + totals.rejected}</div>
                <div style="font-size:0.9rem; color:#7F1D1D;">Damaged/Rejected</div>
            </div>
        </div>
    `;
    
    const itemsTableHTML = `
        <table style="width:100%; border-collapse:collapse; margin-bottom:24px;">
            <thead>
                <tr style="background:var(--bg-gray); border-bottom:2px solid var(--border-color);">
                    <th style="padding:8px; text-align:left;">Product</th>
                    <th style="padding:8px; text-align:center;">Ordered</th>
                    <th style="padding:8px; text-align:center;">Delivered</th>
                    <th style="padding:8px; text-align:center;">Accepted</th>
                    <th style="padding:8px; text-align:center;">Rejected</th>
                    <th style="padding:8px; text-align:center;">Damaged</th>
                    <th style="padding:8px; text-align:center;">Result</th>
                </tr>
            </thead>
            <tbody>
                ${inspectionData.items.map(item => `
                    <tr style="border-bottom:1px solid var(--border-color);">
                        <td style="padding:8px;">${item.productName}</td>
                        <td style="padding:8px; text-align:center;">${item.orderedQuantity}</td>
                        <td style="padding:8px; text-align:center; color:#3B82F6; font-weight:600;">${item.deliveredQuantity}</td>
                        <td style="padding:8px; text-align:center; color:#059669; font-weight:600;">${item.acceptedQuantity}</td>
                        <td style="padding:8px; text-align:center; color:#DC2626;">${item.rejectedQuantity}</td>
                        <td style="padding:8px; text-align:center; color:#F59E0B;">${item.damagedQuantity}</td>
                        <td style="padding:8px; text-align:center; font-size:0.85rem;">${item.inspectionResult}</td>
                    </tr>
                `).join('')}
            </tbody>
        </table>
    `;
    
    const inventoryImpactHTML = `
        <div style="background:#FEF3C7; border:1px solid #F59E0B; padding:16px; border-radius:8px; margin-bottom:16px;">
            <h4 style="margin-bottom:8px; color:#92400E;">📦 Inventory Impact</h4>
            <p style="font-size:0.95rem; color:#78350F;">
                <strong>${totals.accepted}</strong> units will be added to inventory.<br>
                <strong>${totals.damaged + totals.rejected}</strong> units will NOT enter inventory.
            </p>
        </div>
    `;
    
    const formHTML = `
        <div>
            <div style="background:#D1FAE5; border-left:4px solid #10B981; padding:12px; border-radius:4px; margin-bottom:16px;">
                <strong style="color:#065F46;">Step 3 of 3:</strong> Review & Confirm
            </div>
            
            ${summaryHTML}
            ${itemsTableHTML}
            ${inventoryImpactHTML}
            
            <div style="margin-top:16px;">
                <label style="display:block; font-weight:500; margin-bottom:4px;">Final Remarks</label>
                <textarea id="finalRemarks" rows="3" class="form-input" style="resize:vertical;" 
                          placeholder="Any final notes about this receiving..."></textarea>
            </div>
        </div>
    `;
    
    modal.open(`POR: ${poData.poNumber} - Review`, formHTML, {
        confirmText: 'Complete POR ✓',
        cancelText: '← Back',
        onCancel: () => renderReceivingStep2(),
        onConfirm: async () => {
            await completeReceiving();
        }
    });
}

// === NEW: Complete receiving with POR ===
async function completeReceiving() {
    const { poData, deliveryData, inspectionData, damageEvidence } = receivingState;
    
    try {
        // Generate POR number
        const porNumber = await generateReceivingNumber();
        
        // Calculate totals
        const totals = {
            ordered: 0,
            delivered: 0,
            accepted: 0,
            rejected: 0,
            damaged: 0,
            missing: 0
        };
        
        inspectionData.items.forEach(item => {
            totals.ordered += item.orderedQuantity;
            totals.delivered += item.deliveredQuantity;
            totals.accepted += item.acceptedQuantity;
            totals.rejected += item.rejectedQuantity;
            totals.damaged += item.damagedQuantity;
            totals.missing += item.missingQuantity;
        });
        
        // Create POR record
        const porRecord = {
            receivingNumber: porNumber,
            porNumber: porNumber,
            poId: poData.id,
            poNumber: poData.poNumber,
            supplierId: poData.supplierId,
            supplier: poData.supplier,
            receivedDate: new Date().toISOString(),
            receivedBy: store.getState().user?.name || 'System',
            deliveryReferenceNumber: deliveryData.deliveryRef || '',
            supplierInvoiceNumber: deliveryData.supplierInvoice || '',
            location: 'Main Store',  // TODO: Get from settings or user
            inspectionStatus: 'Completed',
            inspectionDate: new Date().toISOString(),
            inspectedBy: store.getState().user?.name || 'System',
            totalOrdered: totals.ordered,
            totalDelivered: totals.delivered,
            totalAccepted: totals.accepted,
            totalRejected: totals.rejected,
            totalDamaged: totals.damaged,
            totalMissing: totals.missing,
            totalReceived: totals.accepted,  // For backward compatibility
            totalValue: inspectionData.items.reduce((sum, item) => sum + (item.acceptedQuantity * item.unitCost), 0),
            items: inspectionData.items,
            notes: document.getElementById('finalRemarks')?.value || '',
            status: 'Completed'
        };
        
        // Update inventory (ONLY accepted quantities)
        await updateInventoryForPOR(porRecord);
        
        // Update PO status
        await updatePOStatus(poData, porRecord);
        
        // Save POR
        await dataService.create('receivings', porRecord);
        
        // Log event
        log_security_event('POR_COMPLETED', {
            porNumber: porNumber,
            poNumber: poData.poNumber,
            totalAccepted: totals.accepted,
            totalDamaged: totals.damaged
        });
        
        toast.show(`POR ${porNumber} completed successfully!`, 'success');
        modal.close();
        
        // Show view/print options
        showPORCompletionModal(porRecord);
        
    } catch (error) {
        console.error('POR Completion Error:', error);
        toast.show('Failed to complete POR. Please try again.', 'error');
    }
}

// === NEW: POR completion modal ===
function showPORCompletionModal(porRecord) {
    const html = `
        <div style="text-align:center;">
            <div style="width:80px; height:80px; margin:0 auto 16px; background:#D1FAE5; border-radius:50%; display:flex; align-items:center; justify-content:center;">
                <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="#10B981" stroke-width="2">
                    <path d="M20 6L9 17l-5-5"/>
                </svg>
            </div>
            <h3 style="margin-bottom:8px; color:var(--text-primary);">POR Completed</h3>
            <p style="font-size:1.1rem; color:var(--text-secondary); margin-bottom:24px;">
                POR #: <strong style="color:var(--primary-red);">${porRecord.porNumber}</strong>
            </p>
            <div style="display:flex; gap:12px; justify-content:center;">
                <button id="viewPORBtn" style="background:var(--primary-orange); color:white; padding:10px 20px; border:none; border-radius:8px; cursor:pointer;">
                    View POR
                </button>
                <button id="printPORBtn" style="background:var(--primary-red); color:white; padding:10px 20px; border:none; border-radius:8px; cursor:pointer;">
                    Print POR
                </button>
            </div>
        </div>
    `;
    
    modal.open('Success', html, {
        confirmText: 'Close',
        onConfirm: () => {
            modal.close();
            renderReceiving();  // Refresh main view
        }
    });
    
    document.getElementById('viewPORBtn')?.addEventListener('click', () => {
        modal.close();
        viewPORDetails(porRecord);
    });
    
    document.getElementById('printPORBtn')?.addEventListener('click', () => {
        modal.close();
        printPOR(porRecord);
    });
}

// === NEW: View POR details ===
function viewPORDetails(porData) {
    // ... implementation for viewing POR with all details ...
}

// === NEW: Print POR ===
function printPOR(porData) {
    // Open print-friendly view in new window
    const printWindow = window.open('', '_blank');
    printWindow.document.write(generatePORHTML(porData));
    printWindow.document.close();
    printWindow.focus();
    printWindow.print();
}

function generatePORHTML(porData) {
    return `
        <!DOCTYPE html>
        <html>
        <head>
            <title>POR ${porData.porNumber}</title>
            <style>
                @media print {
                    body { margin: 0; padding: 20px; }
                    .no-print { display: none; }
                }
                body { font-family: Arial, sans-serif; line-height: 1.6; }
                .header { text-align: center; margin-bottom: 30px; }
                table { width: 100%; border-collapse: collapse; margin: 20px 0; }
                th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
                th { background-color: #f4f4f4; }
                .signatures { display: flex; justify-content: space-between; margin-top: 60px; }
                .signature-line { width: 200px; border-top: 1px solid #000; padding-top: 5px; }
            </style>
        </head>
        <body>
            <div class="header">
                <h1>RAM-YUM KOREAN & JAPANESE STORE</h1>
                <h2>PROOF OF RECEIVING</h2>
            </div>
            
            <p><strong>POR No.:</strong> ${porData.porNumber}</p>
            <p><strong>PO No.:</strong> ${porData.poNumber}</p>
            <p><strong>Supplier:</strong> ${porData.supplier}</p>
            <p><strong>Date:</strong> ${new Date(porData.receivedDate).toLocaleString()}</p>
            <p><strong>Received By:</strong> ${porData.receivedBy}</p>
            
            <table>
                <thead>
                    <tr>
                        <th>Product</th>
                        <th>SKU</th>
                        <th>Ordered</th>
                        <th>Delivered</th>
                        <th>Accepted</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    ${porData.items.map(item => `
                        <tr>
                            <td>${item.productName}</td>
                            <td>${item.sku || 'N/A'}</td>
                            <td>${item.orderedQuantity}</td>
                            <td>${item.deliveredQuantity}</td>
                            <td>${item.acceptedQuantity}</td>
                            <td>${item.inspectionResult}</td>
                        </tr>
                    `).join('')}
                </tbody>
            </table>
            
            <div style="margin-top:20px;">
                <h4>Remarks:</h4>
                <p>${porData.notes || 'None'}</p>
            </div>
            
            <div class="signatures">
                <div>
                    <p>Received By:</p>
                    <div class="signature-line"></div>
                    <p style="font-size:0.9rem;">Date: _____________</p>
                </div>
                <div>
                    <p>Inspected By:</p>
                    <div class="signature-line"></div>
                    <p style="font-size:0.9rem;">Date: _____________</p>
                </div>
                <div>
                    <p>Authorized By:</p>
                    <div class="signature-line"></div>
                    <p style="font-size:0.9rem;">Date: _____________</p>
                </div>
            </div>
            
            <button class="no-print" onclick="window.print()" style="margin-top:20px; padding:10px 20px; background:#FF7A00; color:white; border:none; border-radius:4px; cursor:pointer;">
                Print
            </button>
        </body>
        </html>
    `;
}
```

---

## MIGRATION STRATEGY

### Phase 1: Database Preparation

**File:** `database/por-enhancement-migration.sql`

```sql
-- ============================================================
-- POR Enhancement Migration
-- ============================================================
-- This migration prepares the system for POR feature
-- No table structure changes, only data validation
-- ============================================================

-- Verify damage_evidence table exists (should be from panel-revisions-migration.sql)
SELECT COUNT(*) as table_exists FROM information_schema.tables 
WHERE table_schema = DATABASE() AND table_name = 'damage_evidence';

-- If not exists, create it
CREATE TABLE IF NOT EXISTS `damage_evidence` (
  `id` varchar(40) NOT NULL PRIMARY KEY,
  `receiving_id` varchar(40) NOT NULL,
  `po_id` varchar(40) NOT NULL,
  `po_number` varchar(50) NOT NULL,
  `product_id` varchar(40) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `ordered_quantity` decimal(12,2) NOT NULL DEFAULT 0,
  `received_quantity` decimal(12,2) NOT NULL DEFAULT 0,
  `damaged_quantity` decimal(12,2) NOT NULL DEFAULT 0,
  `damage_description` text DEFAULT NULL,
  `evidence_image_path` varchar(500) DEFAULT NULL,
  `recorded_by` varchar(100) NOT NULL,
  `recorded_at` datetime NOT NULL DEFAULT current_timestamp(),
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  KEY `idx_receiving_id` (`receiving_id`),
  KEY `idx_po_id` (`po_id`),
  KEY `idx_product_id` (`product_id`),
  KEY `idx_recorded_at` (`recorded_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Create damage evidence upload directory
-- (To be created via PHP or manually: /uploads/damage-evidence/)

-- Verification
SELECT 'POR Enhancement Migration Complete' as status;
SELECT COUNT(*) as existing_receivings FROM receivings;
SELECT COUNT(*) as existing_damage_evidence FROM damage_evidence;
```

### Phase 2: Backward Compatibility

**No migration script needed for existing data.**

Existing `receivings` records will continue to work because:
1. Frontend checks for field existence: `item.acceptedQuantity ?? item.quantityReceived ?? 0`
2. New fields are optional additions to JSON
3. Old records display correctly with available data

---

## TESTING REQUIREMENTS

### Unit Tests

1. **Quantity Validation:**
   - delivered = accepted + rejected + damaged
   - missing = ordered - delivered
   - excess = delivered - ordered

2. **Inventory Update:**
   - Only accepted quantity added to stock
   - Damage movement records created
   - No duplicate updates

3. **PO Status:**
   - Correct status based on accepted quantities
   - Partial receiving supported
   - Full receiving detected

### Integration Tests

1. **Complete POR Workflow:**
   - Create PO
   - Approve PO
   - Start receiving
   - Enter delivery quantities
   - Perform inspection with discrepancies
   - Upload damage photos
   - Review and confirm
   - Verify inventory updated
   - Verify PO status updated
   - View POR details
   - Print POR

2. **Damage Evidence:**
   - Upload photo (valid formats)
   - Reject invalid formats
   - Link evidence to receiving
   - Display in POR view

3. **Draft Saving:**
   - Save draft at any step
   - Resume draft
   - Complete from draft

### Manual Testing Checklist

```
[ ] Can select pending PO
[ ] Can enter delivery quantities
[ ] Batch/expiry fields save correctly
[ ] Can proceed to inspection step
[ ] Quantity validation works (accepted + rejected + damaged = delivered)
[ ] Cannot proceed if damaged items have no photo
[ ] Photo upload validates file types
[ ] Can go back and edit previous steps
[ ] Review step shows correct totals
[ ] Inventory increases by accepted quantity only
[ ] PO status updates correctly
[ ] POR appears in history
[ ] Can view POR details
[ ] Can print POR (clean format, no sidebar/nav)
[ ] Damage evidence photos visible in POR view
[ ] Security logs record all actions
[ ] Role permissions enforced (staff vs admin)
[ ] Works on mobile devices
```

---

## DEPLOYMENT CHECKLIST

```
[ ] Backup database
[ ] Run migration: database/por-enhancement-migration.sql
[ ] Create directory: /uploads/damage-evidence/ (chmod 755)
[ ] Upload files:
    [ ] api/damage-evidence.php
    [ ] modules/receiving/receiving.js (enhanced)
    [ ] includes/functions.php (add new event types)
[ ] Test on staging environment
[ ] Verify existing receivings still work
[ ] Test complete POR workflow
[ ] Test backward compatibility
[ ] Deploy to production
[ ] Monitor security_logs for errors
[ ] Train users on new workflow
```

---

## RISKS & MITIGATION

| Risk | Probability | Impact | Mitigation |
|------|-------------|--------|------------|
| Breaking existing receiving | Low | High | Extensive backward compatibility checks, fallback to old fields |
| Duplicate inventory updates | Medium | High | Add processing flag, check before update, transaction safety |
| Photo upload failures | Medium | Medium | Validation, error handling, manual upload fallback |
| Complex UI confusing users | Medium | Low | Step-by-step wizard, clear labels, help text |
| Performance with large POs | Low | Medium | Pagination, lazy loading if needed |

---

## FUTURE ENHANCEMENTS (Out of Scope)

- Email notifications for completed PORs
- Barcode scanning integration
- Mobile app for receiving
- Supplier portal access to PORs
- Return to supplier workflow
- Credit note generation
- QR code on POs for scanning
- Multi-location support
- Batch/lot tracking across system
- Expiry date alerts

---

## APPROVAL REQUIRED

This design document must be approved before proceeding to tasks.md.

**Next Steps:**
1. ✅ Review technical design
2. ✅ Verify API design is sound
3. ✅ Confirm database approach is safe
4. ✅ Check UI/UX flow makes sense
5. ➡️ Proceed to tasks.md

---

**Status:** ⏳ AWAITING APPROVAL
