# RAM-YUM PANEL REVISIONS - TESTING GUIDE

**Version:** 1.0  
**Date:** October 2, 2026  
**Purpose:** Comprehensive testing checklist for all panel revisions

---

## PRE-TESTING SETUP

### Step 1: Run Database Migrations
```bash
# Execute SQL migration
mysql -u username -p database_name < database/panel-revisions-migration.sql

# Run product data migration
php migrate-products-panel-revisions.php
```

**Expected Output:**
- ✓ Database tables created/verified
- ✓ Found X products
- ✓ Migrated X products
- ✓ Upload directories created

### Step 2: Setup Demo Data (Optional)
```bash
php setup-panel-revisions-demo-data.php
```

**Expected Output:**
- ✓ 3 Stock Transfers created
- ✓ 2 POD records created with QR tokens
- QR Token URLs displayed

### Step 3: Verify File Permissions
```bash
# Check upload directories
ls -la uploads/
ls -la uploads/product-images/
ls -la uploads/damage-evidence/

# Should show: drwxr-xr-x (755 permissions)
```

---

## TEST SUITE 1: PRODUCT CATALOG MANAGEMENT

### TEST 1.1: Create Product with All New Fields
**Status:** 🔴 NOT STARTED | 🟡 IN PROGRESS | 🟢 PASSED | ❌ FAILED

**Steps:**
1. Login as admin/manager
2. Navigate to Products page
3. Click "Add Product"
4. Fill in all fields:
   - Product Name: "Test Product ABC"
   - SKU: "TEST-001"
   - Category: Select any
   - Unit: Select "Pack"
   - Costing Price: 100.00
   - SRP: 120.00
   - Current Stock: 50
   - Minimum Stock: 10
   - Maximum Stock: 100
   - Batch Number: "BATCH-TEST-001"
   - Expiration Date: Future date
   - Status: In Stock
   - Description: "Test description"
5. Click upload image button
6. Select a valid image file (JPG/PNG, < 5MB)
7. Verify image preview appears
8. Click "Add Product"

**Expected Results:**
- ✓ Form validation works (required fields)
- ✓ Image uploads successfully
- ✓ Image preview displays
- ✓ Product saved successfully
- ✓ Toast notification: "Product added!"
- ✓ Product appears in list

**Actual Results:**
- [ ] Status: _____________
- [ ] Notes: _____________

---

### TEST 1.2: View Product in Table Mode
**Status:** 🔴 NOT STARTED | 🟡 IN PROGRESS | 🟢 PASSED | ❌ FAILED

**Steps:**
1. Ensure "Table" view is selected
2. Locate test product in table
3. Verify all columns display correctly

**Expected Results:**
- ✓ Image thumbnail displays (50x50px)
- ✓ SKU: "TEST-001"
- ✓ Name: "Test Product ABC"
- ✓ Unit: "Pack"
- ✓ Stock: "50"
- ✓ Costing: "₱100.00"
- ✓ SRP: "₱120.00"
- ✓ Stock Status: Green "Within Limits" badge
- ✓ Status: Green "In Stock" badge
- ✓ Edit/Archive buttons visible (if admin)

**Actual Results:**
- [ ] Status: _____________
- [ ] Notes: _____________

---

### TEST 1.3: View Product in Grid Mode
**Status:** 🔴 NOT STARTED | 🟡 IN PROGRESS | 🟢 PASSED | ❌ FAILED

**Steps:**
1. Click "Grid" view toggle button
2. Locate test product card
3. Verify card displays all information

**Expected Results:**
- ✓ Product image displays (full size, aspect ratio maintained)
- ✓ Product name: "Test Product ABC"
- ✓ SKU: "TEST-001"
- ✓ Costing box shows: "₱100.00"
- ✓ SRP box shows: "₱120.00"
- ✓ Stock shows: "50 Pack"
- ✓ Stock level badge: Green "OK"
- ✓ Status badge: Green "In Stock"
- ✓ Edit/Archive buttons visible
- ✓ Card has hover effect (shadow)

**Actual Results:**
- [ ] Status: _____________
- [ ] Notes: _____________

---

### TEST 1.4: Edit Product
**Status:** 🔴 NOT STARTED | 🟡 IN PROGRESS | 🟢 PASSED | ❌ FAILED

**Steps:**
1. Click Edit button on test product
2. Modify:
   - Current Stock: Change to 5 (below minimum)
   - Costing Price: 110.00
   - SRP: 130.00
3. Click "Update Product"
4. Verify changes reflected

**Expected Results:**
- ✓ Form pre-fills with existing data
- ✓ Image shows in preview
- ✓ Changes save successfully
- ✓ Stock status badge changes to Red "Below Minimum"
- ✓ Prices update correctly

**Actual Results:**
- [ ] Status: _____________
- [ ] Notes: _____________

---

### TEST 1.5: Stock Level Indicators
**Status:** 🔴 NOT STARTED | 🟡 IN PROGRESS | 🟢 PASSED | ❌ FAILED

**Test Cases:**

**Case A: Below Minimum**
- Set stock to 5 (min: 10, max: 100)
- Expected: Red "Below Minimum" badge

**Case B: Within Limits**
- Set stock to 50 (min: 10, max: 100)
- Expected: Green "Within Limits" badge

**Case C: Above Maximum**
- Set stock to 150 (min: 10, max: 100)
- Expected: Yellow "Above Maximum" badge

**Actual Results:**
- [ ] Case A: _____________
- [ ] Case B: _____________
- [ ] Case C: _____________

---

### TEST 1.6: Image Upload Validation
**Status:** 🔴 NOT STARTED | 🟡 IN PROGRESS | 🟢 PASSED | ❌ FAILED

**Test Cases:**

**Case A: Valid Image**
- Upload JPG < 5MB
- Expected: Success, preview displays

**Case B: File Too Large**
- Upload image > 5MB
- Expected: Error toast "Image size must be less than 5MB"

**Case C: Invalid File Type**
- Upload PDF/TXT file
- Expected: Error toast "Please select an image file"

**Case D: No Image**
- Save product without image
- Expected: Success, "No Image" placeholder displays

**Actual Results:**
- [ ] Case A: _____________
- [ ] Case B: _____________
- [ ] Case C: _____________
- [ ] Case D: _____________

---

## TEST SUITE 2: PURCHASE ORDERS

### TEST 2.1: View PO Status Legend
**Status:** 🔴 NOT STARTED | 🟡 IN PROGRESS | 🟢 PASSED | ❌ FAILED

**Steps:**
1. Navigate to Purchase Orders page
2. Scroll to view Status Key box (below filters)

**Expected Results:**
- ✓ Legend box visible
- ✓ Shows info icon and "Status Key" title
- ✓ Displays all 5 statuses:
  - Draft (gray badge) - "Not yet submitted"
  - Pending (yellow badge) - "Awaiting approval"
  - Approved (blue badge) - "Ready to receive"
  - Fully Received (green badge) - "All items received"
  - Cancelled (red badge) - "Order cancelled"
- ✓ Responsive grid layout
- ✓ Professional styling

**Actual Results:**
- [ ] Status: _____________
- [ ] Notes: _____________

---

### TEST 2.2: Create PO with Units (Manual Test - Needs UI Update)
**Status:** ⚠️ PENDING UI IMPLEMENTATION

**Expected Behavior (When Implemented):**
- PO items should display unit next to quantity
- Example: "25 Packs" not just "25"

**Notes:**
- Backend supports units
- UI update needed in purchase-orders.js

---

## TEST SUITE 3: DATABASE & MIGRATION

### TEST 3.1: Verify New Tables Created
**Status:** 🔴 NOT STARTED | 🟡 IN PROGRESS | 🟢 PASSED | ❌ FAILED

**Steps:**
```sql
-- Check tables exist
SHOW TABLES LIKE 'damage_evidence';
SHOW TABLES LIKE 'proof_of_delivery';

-- Check structure
DESCRIBE damage_evidence;
DESCRIBE proof_of_delivery;
```

**Expected Results:**
- ✓ damage_evidence table exists
- ✓ proof_of_delivery table exists
- ✓ All columns present and correct types
- ✓ Indexes created

**Actual Results:**
- [ ] Status: _____________
- [ ] Notes: _____________

---

### TEST 3.2: Verify Product Data Migration
**Status:** 🔴 NOT STARTED | 🟡 IN PROGRESS | 🟢 PASSED | ❌ FAILED

**Steps:**
```sql
-- Check products have new fields
SELECT 
    id,
    JSON_EXTRACT(data, '$.name') as name,
    JSON_EXTRACT(data, '$.unit') as unit,
    JSON_EXTRACT(data, '$.costingPrice') as costing,
    JSON_EXTRACT(data, '$.srp') as srp,
    JSON_EXTRACT(data, '$.minimumStock') as min_stock,
    JSON_EXTRACT(data, '$.maximumStock') as max_stock
FROM products
LIMIT 5;
```

**Expected Results:**
- ✓ All products have unit field
- ✓ All products have costingPrice
- ✓ All products have srp
- ✓ All products have minimumStock
- ✓ All products have maximumStock
- ✓ Values are reasonable (not null/zero)

**Actual Results:**
- [ ] Status: _____________
- [ ] Notes: _____________

---

## TEST SUITE 4: API ENDPOINTS

### TEST 4.1: Upload Image API
**Status:** 🔴 NOT STARTED | 🟡 IN PROGRESS | 🟢 PASSED | ❌ FAILED

**Test with cURL:**
```bash
# Test product image upload
curl -X POST http://localhost/api/upload-image.php \
  -F "image=@test-image.jpg" \
  -F "type=product" \
  -b "PHPSESSID=your_session_id"
```

**Expected Response:**
```json
{
  "success": true,
  "data": {
    "path": "uploads/product-images/product_1234567890_abcdef.jpg",
    "filename": "product_1234567890_abcdef.jpg",
    "url": "/uploads/product-images/product_1234567890_abcdef.jpg",
    "size": 123456,
    "type": "image/jpeg"
  }
}
```

**Actual Results:**
- [ ] Status: _____________
- [ ] Response: _____________

---

### TEST 4.2: Damage Evidence API
**Status:** 🔴 NOT STARTED | 🟡 IN PROGRESS | 🟢 PASSED | ❌ FAILED

**Test Cases:**

**Case A: Create Damage Record**
```bash
curl -X POST http://localhost/api/damage-evidence.php \
  -H "Content-Type: application/json" \
  -d '{
    "receiving_id": "test_gr_001",
    "po_id": "test_po_001",
    "po_number": "PO-2026-TEST",
    "product_id": "p1",
    "product_name": "Test Product",
    "ordered_quantity": 100,
    "received_quantity": 97,
    "damaged_quantity": 3,
    "damage_description": "Boxes crushed during transit",
    "evidence_image_path": "uploads/damage-evidence/damage_123.jpg"
  }' \
  -b "PHPSESSID=your_session_id"
```

**Expected Response:**
```json
{
  "success": true,
  "data": {
    "id": "dmg_1234567890_abcd",
    "message": "Damage evidence recorded successfully"
  }
}
```

**Case B: Get Damage by PO**
```bash
curl "http://localhost/api/damage-evidence.php?po_id=test_po_001" \
  -b "PHPSESSID=your_session_id"
```

**Expected Response:**
```json
{
  "success": true,
  "data": [
    {
      "id": "dmg_1234567890_abcd",
      "po_number": "PO-2026-TEST",
      "product_name": "Test Product",
      "damaged_quantity": "3.00",
      "damage_description": "Boxes crushed during transit",
      "evidence_image_path": "uploads/damage-evidence/damage_123.jpg",
      "recorded_by": "admin",
      "recorded_at": "2026-10-02 12:00:00"
    }
  ]
}
```

**Actual Results:**
- [ ] Case A: _____________
- [ ] Case B: _____________

---

### TEST 4.3: Proof of Delivery API
**Status:** 🔴 NOT STARTED | 🟡 IN PROGRESS | 🟢 PASSED | ❌ FAILED

**Test Cases:**

**Case A: Create POD**
```bash
curl -X POST http://localhost/api/proof-of-delivery.php \
  -H "Content-Type: application/json" \
  -d '{
    "action": "create",
    "transfer_id": "st_test_001",
    "transfer_number": "ST-2026-TEST"
  }' \
  -b "PHPSESSID=your_session_id"
```

**Expected Response:**
```json
{
  "success": true,
  "data": {
    "id": "pod_1234567890_abcd",
    "qr_token": "POD-ABCDEF1234567890ABCDEF1234567890",
    "qr_url": "/scan-pod.php?token=POD-ABCDEF..."
  }
}
```

**Case B: Verify QR Token**
```bash
curl "http://localhost/api/proof-of-delivery.php?action=verify&token=POD-ABCDEF..." \
  -b "PHPSESSID=your_session_id"
```

**Expected Response:**
```json
{
  "success": true,
  "data": {
    "pod": {
      "id": "pod_1234567890_abcd",
      "transfer_id": "st_test_001",
      "transfer_number": "ST-2026-TEST",
      "status": "Pending"
    },
    "transfer": {
      "transferNumber": "ST-2026-TEST",
      "sourceName": "Main Warehouse",
      "destinationName": "Branch 1",
      "items": [...]
    }
  }
}
```

**Case C: Confirm Receipt**
```bash
curl -X POST http://localhost/api/proof-of-delivery.php \
  -H "Content-Type: application/json" \
  -d '{
    "action": "confirm",
    "token": "POD-ABCDEF...",
    "notes": "All items received in good condition"
  }' \
  -b "PHPSESSID=your_session_id"
```

**Expected Response:**
```json
{
  "success": true,
  "message": "Delivery confirmed successfully"
}
```

**Actual Results:**
- [ ] Case A: _____________
- [ ] Case B: _____________
- [ ] Case C: _____________

---

## TEST SUITE 5: QR CODE & POD WORKFLOW

### TEST 5.1: QR Code Generation
**Status:** 🔴 NOT STARTED | 🟡 IN PROGRESS | 🟢 PASSED | ❌ FAILED

**Steps:**
1. Create test HTML page with QR generator:
```html
<!DOCTYPE html>
<html>
<head>
    <script src="https://cdn.jsdelivr.net/npm/qrcodejs@1.0.0/qrcode.min.js"></script>
    <script type="module">
        import { QRGenerator } from './assets/js/utils/qr-generator.js';
        
        // Wait for library to load
        await QRGenerator.loadLibrary();
        
        // Generate QR code
        const token = 'POD-TEST1234567890ABCDEF';
        const url = QRGenerator.generatePODUrl(token);
        
        QRGenerator.generateInContainer('qrContainer', url, 256);
        
        document.getElementById('url').textContent = url;
    </script>
</head>
<body>
    <h1>QR Code Test</h1>
    <div id="qrContainer"></div>
    <p>URL: <span id="url"></span></p>
</body>
</html>
```

**Expected Results:**
- ✓ QR code displays (256x256px)
- ✓ QR code is scannable
- ✓ URL contains correct token
- ✓ Scanning redirects to scan-pod.php with token

**Actual Results:**
- [ ] Status: _____________
- [ ] Notes: _____________

---

### TEST 5.2: POD Scanning Page
**Status:** 🔴 NOT STARTED | 🟡 IN PROGRESS | 🟢 PASSED | ❌ FAILED

**Steps:**
1. Get QR token from demo data setup
2. Access: `http://localhost/scan-pod.php?token=YOUR_TOKEN`
3. Verify page loads and displays transfer details

**Expected Results:**
- ✓ Page loads without errors
- ✓ Transfer details display:
  - Transfer Number
  - Source location
  - Destination location
  - Status
- ✓ Product list displays with quantities and units
- ✓ Confirmation notes textarea visible
- ✓ "Confirm Receipt" button visible and enabled

**Actual Results:**
- [ ] Status: _____________
- [ ] Notes: _____________

---

### TEST 5.3: POD Confirmation
**Status:** 🔴 NOT STARTED | 🟡 IN PROGRESS | 🟢 PASSED | ❌ FAILED

**Steps:**
1. On scan-pod.php page
2. Enter confirmation notes: "All items verified and in good condition"
3. Click "Confirm Receipt" button
4. Wait for confirmation
5. Check transfer status in database

**Expected Results:**
- ✓ Button changes to "Confirming..."
- ✓ Success toast appears
- ✓ Page reloads showing completed state
- ✓ Shows: "✓ Delivery Confirmed"
- ✓ Shows received date/time and username
- ✓ Database: POD status = "Received"
- ✓ Database: Stock transfer status = "Completed"

**Actual Results:**
- [ ] Status: _____________
- [ ] Notes: _____________

---

## TEST SUITE 6: SECURITY

### TEST 6.1: Upload Security
**Status:** 🔴 NOT STARTED | 🟡 IN PROGRESS | 🟢 PASSED | ❌ FAILED

**Test Cases:**

**Case A: Block PHP Upload**
- Attempt to upload .php file
- Expected: Rejected, error message

**Case B: Block Executable**
- Attempt to upload .exe file
- Expected: Rejected, error message

**Case C: Verify .htaccess**
- Check uploads/.htaccess exists
- Content should disable PHP execution

**Case D: Test PHP Execution Block**
- Place test.php in uploads/
- Access via URL
- Expected: Download/plain text, not executed

**Actual Results:**
- [ ] Case A: _____________
- [ ] Case B: _____________
- [ ] Case C: _____________
- [ ] Case D: _____________

---

### TEST 6.2: Authentication Requirements
**Status:** 🔴 NOT STARTED | 🟡 IN PROGRESS | 🟢 PASSED | ❌ FAILED

**Test Cases:**

**Case A: API Without Auth**
- Access API endpoint without session
- Expected: 401 Unauthorized or redirect to login

**Case B: scan-pod.php Without Auth**
- Access scan-pod.php without login
- Expected: Redirect to login page

**Case C: Role-Based Access**
- Test admin-only operations as staff user
- Expected: Denied with appropriate message

**Actual Results:**
- [ ] Case A: _____________
- [ ] Case B: _____________
- [ ] Case C: _____________

---

## TEST SUITE 7: RESPONSIVE DESIGN

### TEST 7.1: Product Catalog - Mobile
**Status:** 🔴 NOT STARTED | 🟡 IN PROGRESS | 🟢 PASSED | ❌ FAILED

**Steps:**
1. Open product catalog
2. Resize browser to 375px width (mobile)
3. Test both table and grid views

**Expected Results:**
- ✓ Page responsive, no horizontal scroll
- ✓ Grid view: 1 column on mobile
- ✓ Table view: Readable on mobile
- ✓ Filters stack vertically
- ✓ View toggle buttons remain accessible
- ✓ Product cards maintain proper sizing

**Actual Results:**
- [ ] Status: _____________
- [ ] Notes: _____________

---

### TEST 7.2: POD Scan Page - Mobile
**Status:** 🔴 NOT STARTED | 🟡 IN PROGRESS | 🟢 PASSED | ❌ FAILED

**Steps:**
1. Access scan-pod.php on mobile device
2. Test confirmation workflow

**Expected Results:**
- ✓ Page displays correctly on mobile
- ✓ Transfer details readable
- ✓ Product list scrollable
- ✓ Textarea for notes functional
- ✓ Confirm button easily tappable
- ✓ No zoom issues

**Actual Results:**
- [ ] Status: _____________
- [ ] Notes: _____________

---

## TEST SUITE 8: DATA INTEGRITY

### TEST 8.1: Product Data Consistency
**Status:** 🔴 NOT STARTED | 🟡 IN PROGRESS | 🟢 PASSED | ❌ FAILED

**Steps:**
```sql
-- Check for products missing new fields
SELECT id, 
    JSON_EXTRACT(data, '$.name') as name,
    JSON_EXTRACT(data, '$.unit') IS NULL as missing_unit,
    JSON_EXTRACT(data, '$.costingPrice') IS NULL as missing_costing,
    JSON_EXTRACT(data, '$.srp') IS NULL as missing_srp,
    JSON_EXTRACT(data, '$.minimumStock') IS NULL as missing_min,
    JSON_EXTRACT(data, '$.maximumStock') IS NULL as missing_max
FROM products
WHERE JSON_EXTRACT(data, '$.unit') IS NULL
   OR JSON_EXTRACT(data, '$.costingPrice') IS NULL
   OR JSON_EXTRACT(data, '$.srp') IS NULL;
```

**Expected Results:**
- ✓ No products missing unit
- ✓ No products missing costingPrice
- ✓ No products missing srp
- ✓ No products missing minimumStock
- ✓ No products missing maximumStock

**Actual Results:**
- [ ] Status: _____________
- [ ] Count: _____________

---

### TEST 8.2: Stock Transfer Units
**Status:** 🔴 NOT STARTED | 🟡 IN PROGRESS | 🟢 PASSED | ❌ FAILED

**Steps:**
1. Check demo stock transfers have units
```sql
SELECT id, 
    JSON_EXTRACT(data, '$.transferNumber') as number,
    JSON_EXTRACT(data, '$.items[0].unit') as first_item_unit
FROM stock_transfers
WHERE id LIKE 'st_demo_rev_%';
```

**Expected Results:**
- ✓ All demo transfers have items with units
- ✓ Units are valid (Pack, Bottle, Box, etc.)

**Actual Results:**
- [ ] Status: _____________
- [ ] Notes: _____________

---

## TEST SUITE 9: BROWSER COMPATIBILITY

### TEST 9.1: Cross-Browser Testing
**Status:** 🔴 NOT STARTED | 🟡 IN PROGRESS | 🟢 PASSED | ❌ FAILED

**Test on:**
- [ ] Chrome/Edge (Latest)
- [ ] Firefox (Latest)
- [ ] Safari (Latest)
- [ ] Mobile Safari (iOS)
- [ ] Mobile Chrome (Android)

**Test Features:**
- Product catalog grid/table views
- Image upload
- Modal dialogs
- Toast notifications
- QR code display (if integrated)

**Results:**
- Chrome/Edge: _____________
- Firefox: _____________
- Safari: _____________
- Mobile Safari: _____________
- Mobile Chrome: _____________

---

## TEST SUMMARY

### Completion Checklist

**Product Catalog:**
- [ ] TEST 1.1: Create Product
- [ ] TEST 1.2: Table View
- [ ] TEST 1.3: Grid View
- [ ] TEST 1.4: Edit Product
- [ ] TEST 1.5: Stock Level Indicators
- [ ] TEST 1.6: Image Upload Validation

**Purchase Orders:**
- [ ] TEST 2.1: Status Legend

**Database:**
- [ ] TEST 3.1: Tables Created
- [ ] TEST 3.2: Data Migration

**APIs:**
- [ ] TEST 4.1: Upload Image
- [ ] TEST 4.2: Damage Evidence
- [ ] TEST 4.3: POD API

**QR & POD:**
- [ ] TEST 5.1: QR Generation
- [ ] TEST 5.2: Scan Page
- [ ] TEST 5.3: Confirmation

**Security:**
- [ ] TEST 6.1: Upload Security
- [ ] TEST 6.2: Authentication

**Responsive:**
- [ ] TEST 7.1: Mobile Catalog
- [ ] TEST 7.2: Mobile POD

**Data Integrity:**
- [ ] TEST 8.1: Product Data
- [ ] TEST 8.2: Transfer Units

**Browser:**
- [ ] TEST 9.1: Cross-Browser

---

## ISSUES LOG

### Critical Issues
| ID | Description | Status | Notes |
|----|-------------|--------|-------|
|    |             |        |       |

### Major Issues
| ID | Description | Status | Notes |
|----|-------------|--------|-------|
|    |             |        |       |

### Minor Issues
| ID | Description | Status | Notes |
|----|-------------|--------|-------|
|    |             |        |       |

---

## SIGN-OFF

**Tester:** ___________________________  
**Date:** _____________________________  
**Overall Status:** ⚪ Not Started | 🟡 In Progress | 🟢 Passed | ❌ Failed

**Notes:**
________________________________________________________________
________________________________________________________________
________________________________________________________________

---

**End of Testing Guide**
