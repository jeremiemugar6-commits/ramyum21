GUIDE101:
---

```markdown
RAM-YUM Product & Inventory Operations System

Capstone / Subject Project 
A complete Product & Inventory Operations System for RAM-YUM Korean & Japanese Store.

---

Project Overview

This system manages the complete inventory operations of RAM-YUM store, including:

- Product Catalog Management
- Inventory Tracking
- Supplier Management
- Purchase Orders
- Receiving & Proof of Receiving (POR)
- Stock Transfers between locations
- Reports & AI Analytics
- User Authentication with OTP support

The system is fully containerized using Docker for easy setup and deployment.

---

Tech Stack

| Component       | Technology              |
|----------------|-------------------------|
| Backend        | PHP 8.2                 |
| Web Server     | Apache                  |
| Database       | MySQL 8.0               |
| Email          | PHPMailer               |
| Containerization | Docker + Docker Compose |

---

How to Run the Project (Docker)

Requirements
- Docker Desktop installed and running

Steps

1. Open terminal / Command Prompt in the project folder
2. Run the following command:

```bash
docker compose up -d --build
```

3. Wait until both containers are running
4. Open your browser and go to:

```
http://localhost:8080
```

Stop the System
```bash
docker compose down
```

Restart the System
```bash
docker compose up -d
```

---

Demo Login Credentials

| Role  | Username | Password  |
|-------|----------|-----------|
| Admin | admin    | admin123  |
| Staff | staff    | staff123  |

---

System Modules

- Dashboard
- Products
- Inventory
- Suppliers
- Purchase Orders
- Receiving
- Proof of Receiving (POR)
- Locations
- Stock Transfer
- Reports
- AI Analytics
- Settings

---

Project Structure

```
operations14/
├── api/                  # Backend API endpoints
├── assets/               # CSS, JS, images
├── config/               # Database and mail configuration
├── database/             # SQL dump and migrations
├── Dockerfile            # PHP + Apache container
├── docker-compose.yml    # Multi-container setup (Web + MySQL)
└── README.md
```

---

Notes

- The database is automatically imported when the containers start for the first time.
- Default database name: `u479471141_ramyum_db2`
- The system runs on port **8080**
- MySQL is accessible on port **3307** (optional)

---

Developed for

Academic / Capstone purposes – RAM-YUM Product & Inventory Operations System
```

---
