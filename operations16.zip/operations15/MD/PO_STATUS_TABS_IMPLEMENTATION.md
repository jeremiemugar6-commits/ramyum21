# Purchase Order Status Tabs Implementation Guide

## Overview
This document explains the tabbed status filter system implemented for the Purchase Orders page. The system provides a clean, organized way to filter orders by status with visual badges and dynamic counts.

---

## 1. Visual Layout (HTML/CSS)

### Tabbed Navigation Structure
The tabs are implemented using a horizontal button layout with the following features:

**HTML Structure:**
```html
<div class="status-tabs-container">
    <div class="status-tabs">
        <button class="status-tab active" data-status="">
            <span>All Orders</span>
            <span class="tab-count">0</span>
        </button>
        <button class="status-tab" data-status="Pending">
            <span>⏳ Pending</span>
            <span class="tab-count">0</span>
        </button>
        <!-- More tabs... -->
    </div>
</div>
```

**CSS Styling:**
```css
/* Active tab gets gradient background */
.status-tab.active {
    background: linear-gradient(135deg, var(--primary-orange), var(--primary-red)) !important;
    color: white !important;
    box-shadow: 0 4px 12px rgba(255, 122, 0, 0.3);
}

/* Hover effect for inactive tabs */
.status-tab:hover:not(.active) {
    background: var(--bg-gray) !important;
}
```

### Tab Categories with Emojis & Colors:
1. **All Orders** - Shows everything
2. **⏳ Pending** - Yellow (#F59E0B) - Awaiting approval
3. **✓ Approved** - Blue (#3B82F6) - Ready to receive
4. **📦 Received** - Green (#10B981) - Partially/Fully received
5. **📝 Draft** - Gray (#9CA3AF) - Not yet submitted
6. **✕ Cancelled** - Red (#EF4444) - Cancelled orders

---

## 2. Backend Filtering Logic (PHP/SQL)

### API Endpoint: `api/data.php`

The backend now sorts Purchase Orders with **PENDING first** and **latest dates on top**:

```php
// Special sorting for purchase_orders: PENDING first, then by latest date
if ($collection === 'purchase_orders') {
    $stmt = $db->query("
        SELECT data FROM `$collection` 
        ORDER BY 
            CASE JSON_UNQUOTE(JSON_EXTRACT(data, '$.status'))
                WHEN 'PENDING' THEN 1
                WHEN 'RECEIVED' THEN 2
                ELSE 3
            END ASC,
            created_at DESC
    ");
} else {
    $stmt = $db->query("SELECT data FROM `$collection` ORDER BY created_at ASC");
}
```

### SQL Query Breakdown:
- **CASE Statement**: Assigns priority numbers to statuses (1 = highest priority)
- **ORDER BY priority ASC**: Shows PENDING orders first
- **ORDER BY created_at DESC**: Within each status group, newest orders appear first

### Example Result Order:
1. PENDING orders (newest → oldest)
2. RECEIVED orders (newest → oldest)
3. All other statuses (newest → oldest)

---

## 3. Frontend JavaScript Logic

### File: `modules/purchase-orders/purchase-orders.js`

#### Tab Click Handler
```javascript
document.querySelectorAll('.status-tab').forEach(tab => {
    tab.addEventListener('click', () => {
        // Remove active class from all tabs
        document.querySelectorAll('.status-tab').forEach(t => t.classList.remove('active'));
        // Add active class to clicked tab
        tab.classList.add('active');
        // Filter data
        filterPOData();
    });
});
```

#### Filter Function
```javascript
function filterPOData() {
    const searchTerm = document.getElementById('poSearch').value.toLowerCase();
    
    // Get active tab's status filter
    const activeTab = document.querySelector('.status-tab.active');
    const statusFilter = activeTab ? activeTab.getAttribute('data-status') : '';

    const filtered = currentPOs.filter(po => {
        // Search filter (PO Number or Supplier)
        const matchesSearch = po.poNumber.toLowerCase().includes(searchTerm) || 
                              po.supplier.toLowerCase().includes(searchTerm);
        
        // Status filter
        let matchesStatus = true;
        if (statusFilter) {
            if (statusFilter === 'RECEIVED') {
                // "Received" tab includes both statuses
                matchesStatus = po.status === 'Partially Received' || 
                               po.status === 'Fully Received' || 
                               po.status === 'RECEIVED';
            } else if (statusFilter === 'Pending') {
                matchesStatus = po.status === 'Pending' || po.status === 'PENDING';
            } else {
                matchesStatus = po.status === statusFilter;
            }
        }
        
        return matchesSearch && matchesStatus;
    });

    renderPOTable(filtered);
}
```

#### Dynamic Count Updates
```javascript
function updateSummaryStats() {
    const counts = {
        all: currentPOs.length,
        pending: currentPOs.filter(p => p.status === 'Pending' || p.status === 'PENDING').length,
        approved: currentPOs.filter(p => p.status === 'Approved').length,
        received: currentPOs.filter(p => 
            p.status === 'Partially Received' || 
            p.status === 'Fully Received' || 
            p.status === 'RECEIVED'
        ).length,
        draft: currentPOs.filter(p => p.status === 'Draft').length,
        cancelled: currentPOs.filter(p => p.status === 'Cancelled').length
    };
    
    // Update each tab's count badge
    document.querySelectorAll('.status-tab').forEach(tab => {
        const status = tab.getAttribute('data-status');
        const countSpan = tab.querySelector('.tab-count');
        // Map status to count and update display
    });
}
```

---

## 4. Color-Coded Status Badges

### Badge Helper System
Location: `assets/js/utils/badge-helper.js`

The system uses the `BadgeHelper.getPOStatusBadge(status)` function to generate color-coded badges:

```javascript
getPOStatusBadge(status) {
    const badges = {
        'Draft': { bg: '#E5E7EB', color: '#6B7280', label: 'Draft' },
        'Pending': { bg: '#FEF3C7', color: '#92400E', label: 'Pending' },
        'PENDING': { bg: '#FEF3C7', color: '#92400E', label: 'Pending' },
        'Approved': { bg: '#DBEAFE', color: '#1E40AF', label: 'Approved' },
        'Partially Received': { bg: '#D1FAE5', color: '#065F46', label: 'Partially Received' },
        'Fully Received': { bg: '#D1FAE5', color: '#065F46', label: 'Fully Received' },
        'RECEIVED': { bg: '#D1FAE5', color: '#065F46', label: 'Received' },
        'Cancelled': { bg: '#FEE2E2', color: '#991B1B', label: 'Cancelled' }
    };
    
    const badge = badges[status] || { bg: '#F3F4F6', color: '#6B7280', label: status };
    
    return `<span style="padding:4px 12px; border-radius:999px; font-size:0.75rem; 
            font-weight:600; background:${badge.bg}; color:${badge.color};">
                ${badge.label}
            </span>`;
}
```

### Badge Visual Examples:
| Status | Background | Text Color | Visual |
|--------|-----------|------------|--------|
| Draft | Light Gray | Dark Gray | 📝 Draft |
| Pending | Light Yellow | Dark Orange | ⏳ Pending |
| Approved | Light Blue | Dark Blue | ✓ Approved |
| Received | Light Green | Dark Green | 📦 Received |
| Cancelled | Light Red | Dark Red | ✕ Cancelled |

---

## 5. User Experience Flow

### Step-by-Step Interaction:

1. **Page Load**
   - System fetches all POs from API
   - "All Orders" tab is active by default
   - All POs are displayed (PENDING first, newest dates on top)
   - Tab counts update automatically

2. **User Clicks "Pending" Tab**
   - Tab becomes active (gradient background)
   - Table filters to show only PENDING orders
   - Search box still works within filtered results
   - Count badge shows number of pending orders

3. **User Types in Search**
   - Real-time filtering within active tab's status
   - If "Pending" tab is active, searches only pending orders
   - If "All Orders" tab is active, searches all orders

4. **User Switches Tabs**
   - Previous tab becomes inactive
   - New tab becomes active
   - Table instantly filters to new status
   - Search persists (filters within new status)

---

## 6. Mobile Responsiveness

The tabs are responsive with horizontal scrolling on small screens:

```css
.status-tabs {
    display: flex;
    gap: 6px;
    overflow-x: auto; /* Enables horizontal scroll */
}

.status-tabs::-webkit-scrollbar {
    height: 4px; /* Thin scrollbar */
}

.status-tab {
    flex: 1;
    min-width: 100px; /* Prevents tabs from becoming too narrow */
    white-space: nowrap; /* Prevents text wrapping */
}
```

---

## 7. Performance Optimization

### Client-Side Filtering
- All POs are loaded once from the API
- Filtering happens in JavaScript (instant, no server requests)
- Only initial page load hits the database
- Ideal for datasets up to ~1000 records

### For Larger Datasets (Optional Future Enhancement)
If you have 5000+ purchase orders, consider:
```php
// Server-side filtering in api/data.php
$status = $_GET['status'] ?? '';
if ($status) {
    $stmt = $db->prepare("
        SELECT data FROM purchase_orders 
        WHERE JSON_UNQUOTE(JSON_EXTRACT(data, '$.status')) = ?
        ORDER BY created_at DESC
    ");
    $stmt->execute([$status]);
}
```

---

## 8. Testing Checklist

- [x] Click each tab and verify correct filtering
- [x] Search within each tab status
- [x] Verify counts update when data changes
- [x] Check mobile responsiveness (horizontal scroll)
- [x] Test with 0 orders in a status
- [x] Test active tab styling (gradient background)
- [x] Verify PENDING orders appear first
- [x] Verify newest dates appear first within each status

---

## 9. Customization Guide

### To Add a New Status Tab:
1. Add button to HTML:
```javascript
<button class="status-tab" data-status="YourStatus">
    <span>🔔 Your Status</span>
    <span class="tab-count">0</span>
</button>
```

2. Update `updateSummaryStats()`:
```javascript
yourStatus: currentPOs.filter(p => p.status === 'YourStatus').length
```

3. Add badge color in `BadgeHelper`:
```javascript
'YourStatus': { bg: '#COLOR', color: '#TEXT_COLOR', label: 'Your Status' }
```

### To Change Tab Colors:
Edit the CSS gradient in the active tab styling:
```css
.status-tab.active {
    background: linear-gradient(135deg, #YOUR_COLOR_1, #YOUR_COLOR_2) !important;
}
```

---

## 10. Files Modified

| File | Changes |
|------|---------|
| `api/data.php` | Added ORDER BY logic for PENDING first, newest dates on top |
| `modules/purchase-orders/purchase-orders.js` | Replaced dropdown with tabs, updated filter logic |
| `assets/js/utils/badge-helper.js` | Status badges already implemented |

---

## Summary

✅ **Clean Tabbed Navigation** - 6 status tabs with emoji indicators  
✅ **Dynamic Counts** - Real-time badge updates  
✅ **Color-Coded Badges** - Consistent status colors throughout  
✅ **Smart Sorting** - PENDING first, newest on top  
✅ **Fast Filtering** - Client-side instant filtering  
✅ **Mobile Responsive** - Horizontal scroll on small screens  
✅ **Search Integration** - Works within active tab  

Your Purchase Orders page is now highly organized and professional! 🎉
