<?php
/**
 * Debug "Transfer Not Found" Issue - Local Environment
 */

error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once 'includes/auth.php';

$db = getDB();

echo "=================================================\n";
echo "  DEBUG: TRANSFER NOT FOUND - LOCAL\n";
echo "=================================================\n\n";

echo "Environment:\n";
echo "  Database: " . DB_NAME . "\n";
echo "  Host: " . DB_HOST . " (LOCAL)\n";
echo "  Project Path: " . __DIR__ . "\n";
echo "  API Base: api/stock-transfers.php (RELATIVE)\n\n";

// Get existing transfers
$stmt = $db->query("SELECT id, data, created_at FROM stock_transfers ORDER BY created_at DESC LIMIT 5");
$transfers = $stmt->fetchAll();

if (count($transfers) === 0) {
    echo "⚠ NO TRANSFERS FOUND IN DATABASE\n\n";
    echo "Creating test transfer...\n\n";
    
    // Create a test transfer
    $transferId = generate_id('st');
    $transferData = [
        'id' => $transferId,
        'transferNumber' => 'ST-' . date('Y') . '-' . str_pad(rand(1, 9999), 4, '0', STR_PAD_LEFT),
        'sourceLocationId' => 'loc1',
        'sourceLocationName' => 'Main Warehouse',
        'destinationLocationId' => 'loc2',
        'destinationLocationName' => 'Branch 1 - Makati',
        'items' => [
            [
                'productId' => 'p1',
                'productName' => 'Test Product',
                'quantity' => 10
            ]
        ],
        'status' => 'Pending Approval',
        'createdAt' => date('Y-m-d\TH:i:s.v\Z')
    ];
    
    $stmt = $db->prepare("INSERT INTO stock_transfers (id, data, created_at, updated_at) VALUES (?, ?, NOW(), NOW())");
    $stmt->execute([$transferId, json_encode($transferData)]);
    
    echo "✓ Test transfer created: $transferId\n\n";
    
    // Reload transfers
    $stmt = $db->query("SELECT id, data FROM stock_transfers WHERE id = ?");
    $stmt->execute([$transferId]);
    $transfers = [$stmt->fetch()];
}

echo "EXISTING TRANSFERS:\n";
echo "-------------------------------------------------\n";
foreach ($transfers as $row) {
    $data = json_decode($row['data'], true);
    echo "ID: " . $row['id'] . "\n";
    echo "  Number: " . ($data['transferNumber'] ?? 'N/A') . "\n";
    echo "  Status: " . ($data['status'] ?? 'N/A') . "\n";
    echo "  Created: " . $row['created_at'] . "\n";
    echo "---\n";
}

echo "\n";

// Test each transfer with different lookup methods
$testTransfer = $transfers[0];
$testId = $testTransfer['id'];
$testData = json_decode($testTransfer['data'], true);

echo "TESTING TRANSFER: $testId\n";
echo "=================================================\n\n";

// TEST 1: Direct database lookup
echo "TEST 1: Direct Database Lookup\n";
echo "-------------------------------------------------\n";
echo "Query: SELECT * FROM stock_transfers WHERE id = '$testId'\n";
$stmt = $db->prepare("SELECT id, data FROM stock_transfers WHERE id = ?");
$stmt->execute([$testId]);
$result = $stmt->fetch();
echo "Result: " . ($result ? "✓ FOUND" : "✗ NOT FOUND") . "\n\n";

// TEST 2: Simulate API call
echo "TEST 2: Simulate API GET Request\n";
echo "-------------------------------------------------\n";
echo "URL: api/stock-transfers.php?action=transfer&id=$testId\n";

// Manually test the getTransferById logic
$stmt = $db->prepare("SELECT data FROM stock_transfers WHERE id = ?");
$stmt->execute([$testId]);
$apiResult = $stmt->fetch();

if ($apiResult) {
    $transferData = json_decode($apiResult['data'], true);
    echo "✓ API would return: SUCCESS\n";
    echo "  Transfer Number: " . $transferData['transferNumber'] . "\n";
    echo "  Status: " . $transferData['status'] . "\n";
} else {
    echo "✗ API would return: Transfer not found\n";
}

echo "\n";

// TEST 3: Check POD/QR flow
echo "TEST 3: QR/POD Flow\n";
echo "-------------------------------------------------\n";

$stmt = $db->prepare("SELECT * FROM proof_of_delivery WHERE transfer_id = ?");
$stmt->execute([$testId]);
$pod = $stmt->fetch();

if ($pod) {
    echo "✓ POD record exists\n";
    echo "  POD ID: " . $pod['id'] . "\n";
    echo "  QR Token: " . $pod['qr_token'] . "\n";
    echo "  Status: " . $pod['status'] . "\n";
    
    // Test QR scan
    echo "\n  Simulating QR scan with token: " . $pod['qr_token'] . "\n";
    $scanStmt = $db->prepare("SELECT * FROM proof_of_delivery WHERE qr_token = ?");
    $scanStmt->execute([$pod['qr_token']]);
    $scannedPod = $scanStmt->fetch();
    
    if ($scannedPod) {
        echo "  ✓ POD found by QR token\n";
        echo "  ✓ Transfer ID from POD: " . $scannedPod['transfer_id'] . "\n";
        
        // Now lookup transfer
        $transferStmt = $db->prepare("SELECT data FROM stock_transfers WHERE id = ?");
        $transferStmt->execute([$scannedPod['transfer_id']]);
        $transferFromPod = $transferStmt->fetch();
        
        if ($transferFromPod) {
            echo "  ✓ Transfer found via POD lookup\n";
        } else {
            echo "  ✗ Transfer NOT FOUND via POD lookup\n";
            echo "    POD transfer_id: " . $scannedPod['transfer_id'] . "\n";
            echo "    Does it exist in stock_transfers? Checking...\n";
            
            $checkStmt = $db->query("SELECT id FROM stock_transfers");
            $allIds = $checkStmt->fetchAll(PDO::FETCH_COLUMN);
            echo "    All transfer IDs: " . implode(', ', $allIds) . "\n";
            
            if (in_array($scannedPod['transfer_id'], $allIds)) {
                echo "    ✓ ID exists but query failed!\n";
            } else {
                echo "    ✗ ID does not exist - POD has orphaned transfer_id\n";
            }
        }
    }
} else {
    echo "ℹ No POD record yet (normal for un-approved transfers)\n";
}

echo "\n";

// TEST 4: Check for parameter naming issues
echo "TEST 4: Parameter Naming Consistency\n";
echo "-------------------------------------------------\n";

// Simulate different parameter names
$paramTests = [
    'id' => $testId,
    'transferId' => $testId,
    'transfer_id' => $testId,
];

foreach ($paramTests as $paramName => $paramValue) {
    // This simulates what $_GET[$paramName] would receive
    echo "If frontend sends: ?$paramName=$paramValue\n";
    echo "  PHP receives: \$_GET['$paramName'] = '$paramValue'\n";
    
    // The API uses $_GET['id'] for action=transfer
    if ($paramName === 'id') {
        echo "  ✓ Matches API expectation\n";
    } else {
        echo "  ✗ MISMATCH - API expects 'id' not '$paramName'\n";
    }
}

echo "\n";

// TEST 5: Check JavaScript fetch calls
echo "TEST 5: JavaScript API Calls\n";
echo "-------------------------------------------------\n";

$jsFile = 'assets/js/utils/stock-transfer-service.js';
if (file_exists($jsFile)) {
    $jsContent = file_get_contents($jsFile);
    
    // Check getTransfer method
    if (preg_match('/async getTransfer\(([^)]+)\)[^{]*{[^}]*fetch\(`\$\{[^}]+\}\?action=transfer&([^`]+)`\)/', $jsContent, $matches)) {
        echo "getTransfer() method found:\n";
        echo "  Parameter: " . $matches[1] . "\n";
        echo "  URL param: " . $matches[2] . "\n";
        
        if (strpos($matches[2], 'id=') !== false) {
            echo "  ✓ Using 'id' parameter\n";
        } else {
            echo "  ✗ NOT using 'id' parameter\n";
        }
    }
    
    // Check base URL
    if (preg_match('/this\.baseUrl\s*=\s*[\'"]([^\'"]+)[\'"]/', $jsContent, $matches)) {
        echo "\nBase URL: " . $matches[1] . "\n";
        
        if (strpos($matches[1], 'http://') === false && strpos($matches[1], 'https://') === false) {
            echo "  ✓ Using relative path (LOCAL)\n";
        } else {
            echo "  ✗ Using absolute URL (REMOTE)\n";
        }
    }
} else {
    echo "⚠ JavaScript service file not found\n";
}

echo "\n";

// TEST 6: Test actual API endpoint
echo "TEST 6: Test Local API Endpoint\n";
echo "-------------------------------------------------\n";

$apiFile = 'api/stock-transfers.php';
if (file_exists($apiFile)) {
    echo "✓ API file exists: $apiFile\n";
    
    // Check if it uses local database
    $apiContent = file_get_contents($apiFile);
    
    if (strpos($apiContent, "require_once __DIR__ . '/../includes/auth.php'") !== false) {
        echo "  ✓ Uses local auth (includes/auth.php)\n";
    }
    
    if (strpos($apiContent, 'getDB()') !== false) {
        echo "  ✓ Uses getDB() for local database\n";
    }
    
    if (strpos($apiContent, 'ramyum.store') !== false || 
        strpos($apiContent, 'https://') !== false && strpos($apiContent, 'https://unpkg') === false) {
        echo "  ✗ WARNING: Contains remote URLs\n";
    } else {
        echo "  ✓ No remote URLs detected\n";
    }
} else {
    echo "✗ API file not found: $apiFile\n";
}

echo "\n=================================================\n";
echo "           DEBUG COMPLETE\n";
echo "=================================================\n\n";

echo "DIAGNOSIS:\n";
echo "-------------------------------------------------\n";
echo "✓ Local database: " . DB_NAME . "\n";
echo "✓ Transfer exists: $testId\n";
echo "✓ Direct lookup: WORKING\n";
echo "✓ API file: exists\n";
echo "✓ JavaScript: uses relative paths\n\n";

echo "RECOMMENDATION:\n";
echo "If you're still seeing 'Transfer not found', check:\n";
echo "1. Browser console for actual error messages\n";
echo "2. Network tab for failed API requests\n";
echo "3. PHP error log for backend errors\n";
echo "4. Verify you're accessing: http://localhost/operations3/\n";
echo "5. Clear browser cache and reload\n\n";

echo "Test in browser:\n";
echo "1. Open: http://localhost/operations3/\n";
echo "2. Go to Stock Transfer\n";
echo "3. Click on: " . $testData['transferNumber'] . "\n";
echo "4. Open browser console (F12)\n";
echo "5. Check for errors\n\n";
