/**
 * Unit conversion utilities for RAM-YUM
 * When a unit with a fixed piece count is selected, quantity is auto-set and locked.
 */

export const PRODUCT_UNITS = ['Piece', 'Pack', 'Bundle', 'Box', 'Bottle', 'Can', 'Bag', 'Jar'];

/**
 * Predefined quantity (in base pieces) for each unit.
 * Piece = 1 (editable free quantity of individual pieces).
 * Units with fixed packaging get locked auto-quantity.
 */
export const UNIT_QUANTITIES = {
    'Piece': 1,
    'Pack': 10,
    'Bundle': 50,
    'Box': 50,
    'Bottle': 1,
    'Can': 1,
    'Bag': 1,
    'Jar': 1
};

/**
 * Units that have a fixed packaging quantity (user cannot override qty).
 * Piece is free-entry so staff can order any number of pieces.
 */
export const FIXED_QTY_UNITS = new Set(['Pack', 'Bundle', 'Box']);

/**
 * Get the automatic quantity for a unit. Returns null if free-entry (Piece etc.).
 */
export function getAutoQuantity(unit) {
    if (!unit) return null;
    if (FIXED_QTY_UNITS.has(unit)) {
        return UNIT_QUANTITIES[unit] ?? null;
    }
    return null;
}

/**
 * Whether quantity field should be read-only for this unit.
 */
export function isQuantityLocked(unit) {
    return FIXED_QTY_UNITS.has(unit);
}

/**
 * Validate that submitted quantity matches the unit's required quantity (backend-safe).
 * Returns { valid: boolean, expected?: number, message?: string }
 */
export function validateUnitQuantity(unit, quantity) {
    const expected = getAutoQuantity(unit);
    if (expected === null) {
        // free-entry unit
        if (!quantity || quantity < 1) {
            return { valid: false, message: 'Quantity must be at least 1' };
        }
        return { valid: true };
    }
    const qty = Number(quantity);
    if (qty !== expected) {
        return {
            valid: false,
            expected,
            message: `Unit "${unit}" requires quantity ${expected}. Received ${qty}.`
        };
    }
    return { valid: true, expected };
}
