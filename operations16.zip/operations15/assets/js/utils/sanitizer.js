export const Sanitizer = {
    sanitizeString(input) {
        if (typeof input !== 'string') return input;
        const map = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#x27;', "/": '&#x2F;' };
        return input.replace(/[&<>"'/]/g, s => map[s]);
    },
    sanitizeObject(obj) {
        if (typeof obj !== 'object' || obj === null) return obj;
        const sanitized = Array.isArray(obj) ? [] : {};
        for (let key in obj) {
            if (obj.hasOwnProperty(key)) {
                const value = obj[key];
                if (typeof value === 'string') sanitized[key] = this.sanitizeString(value);
                else if (typeof value === 'object') sanitized[key] = this.sanitizeObject(value);
                else sanitized[key] = value;
            }
        }
        return sanitized;
    }
};