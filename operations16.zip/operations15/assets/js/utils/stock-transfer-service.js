/**
 * Stock Transfer Service
 * Specialized service for stock transfer operations beyond generic CRUD
 */

export class StockTransferService {
    constructor() {
        this.baseUrl = 'api/stock-transfers.php';
    }

    async _handle(response) {
        let body;
        try {
            body = await response.json();
        } catch (e) {
            console.error('Failed to parse JSON response:', e);
            console.error('Response status:', response.status);
            console.error('Response URL:', response.url);
            throw new Error('Unexpected server response. Please check console for details.');
        }
        if (!response.ok || !body.success) {
            throw new Error(body.error || 'Request failed.');
        }
        return body;
    }

    // Get all transfers (filtered by user role)
    async getAllTransfers() {
        const res = await fetch(`${this.baseUrl}?action=transfers`);
        return this._handle(res);
    }

    // Get single transfer by ID
    async getTransfer(id) {
        const res = await fetch(`${this.baseUrl}?action=transfer&id=${encodeURIComponent(id)}`);
        return this._handle(res);
    }

    // Get all locations
    async getLocations() {
        const res = await fetch(`${this.baseUrl}?action=locations`);
        return this._handle(res);
    }

    // Get inventory for specific location
    async getInventoryByLocation(locationId) {
        const res = await fetch(`${this.baseUrl}?action=inventory&locationId=${encodeURIComponent(locationId)}`);
        return this._handle(res);
    }

    // Get pending approvals (admin/manager only)
    async getPendingApprovals() {
        const res = await fetch(`${this.baseUrl}?action=pending-approvals`);
        return this._handle(res);
    }

    // Get audit log for transfer
    async getAuditLog(transferId) {
        const res = await fetch(`${this.baseUrl}?action=audit-log&transferId=${encodeURIComponent(transferId)}`);
        return this._handle(res);
    }

    // Get QR token for transfer
    async getQRToken(transferId) {
        const res = await fetch(`${this.baseUrl}?action=qr-token&id=${encodeURIComponent(transferId)}`);
        return this._handle(res);
    }

    // Generate QR code for approved transfer
    async generateQRCode(transferId) {
        const res = await fetch(`${this.baseUrl}?action=generate-qr`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ transferId })
        });
        return this._handle(res);
    }

    // Create new transfer
    async createTransfer(transferData) {
        const res = await fetch(`${this.baseUrl}?action=create`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(transferData)
        });
        return this._handle(res);
    }

    // Approve transfer (admin/manager only)
    async approveTransfer(transferId, approvalRemarks = '') {
        const res = await fetch(`${this.baseUrl}?action=approve`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ 
                transferId, 
                approvalRemarks 
            })
        });
        return this._handle(res);
    }

    // Reject transfer (admin/manager only)
    async rejectTransfer(transferId, rejectionReason) {
        const res = await fetch(`${this.baseUrl}?action=reject`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ 
                transferId, 
                rejectionReason 
            })
        });
        return this._handle(res);
    }

    // Validate transfer before submission
    validateTransfer(transferData) {
        const errors = [];

        if (!transferData.sourceLocationId) {
            errors.push('Source location is required');
        }

        if (!transferData.destinationLocationId) {
            errors.push('Destination location is required');
        }

        if (transferData.sourceLocationId === transferData.destinationLocationId) {
            errors.push('Source and destination cannot be the same');
        }

        if (!transferData.items || transferData.items.length === 0) {
            errors.push('At least one item is required');
        } else {
            transferData.items.forEach((item, index) => {
                if (!item.productId) {
                    errors.push(`Item ${index + 1}: Product is required`);
                }
                if (!item.quantity || item.quantity <= 0) {
                    errors.push(`Item ${index + 1}: Quantity must be greater than 0`);
                }
                if (item.sourceStock !== undefined && item.quantity > item.sourceStock) {
                    errors.push(`Item ${index + 1}: Cannot transfer more than available stock (${item.sourceStock})`);
                }
            });

            // Check for duplicate products
            const productIds = transferData.items.map(item => item.productId).filter(id => id);
            const duplicates = productIds.filter((id, index) => productIds.indexOf(id) !== index);
            if (duplicates.length > 0) {
                errors.push('Duplicate products are not allowed in the same transfer');
            }
        }

        return {
            isValid: errors.length === 0,
            errors
        };
    }

    // Generate transfer number preview (client-side estimation)
    generateTransferNumberPreview() {
        const year = new Date().getFullYear();
        const randomNum = Math.floor(Math.random() * 9000) + 1000; // 4-digit random
        return `ST-${year}-${randomNum}`;
    }

    // Calculate transfer summary
    calculateTransferSummary(items) {
        if (!items || items.length === 0) {
            return {
                totalItems: 0,
                totalQuantity: 0,
                uniqueProducts: 0,
                estimatedValue: 0
            };
        }

        return {
            totalItems: items.length,
            totalQuantity: items.reduce((sum, item) => sum + (item.quantity || 0), 0),
            uniqueProducts: new Set(items.map(item => item.productId)).size,
            estimatedValue: items.reduce((sum, item) => {
                const price = item.price || 0;
                const quantity = item.quantity || 0;
                return sum + (price * quantity);
            }, 0)
        };
    }

    // Format transfer status for display
    getStatusDisplay(status) {
        const statusMap = {
            'Draft': { text: 'Draft', class: 'status-draft', color: '#6B7280' },
            'Pending Approval': { text: 'Pending', class: 'status-pending', color: '#F59E0B' },
            'Approved': { text: 'Approved', class: 'status-approved', color: '#10B981' },
            'Rejected': { text: 'Rejected', class: 'status-rejected', color: '#EF4444' },
            'Cancelled': { text: 'Cancelled', class: 'status-cancelled', color: '#6B7280' },
            'In Transit': { text: 'In Transit', class: 'status-transit', color: '#3B82F6' },
            'Completed': { text: 'Completed', class: 'status-completed', color: '#059669' },
            'Received': { text: 'Received', class: 'status-completed', color: '#059669' }
        };

        return statusMap[status] || statusMap['Draft'];
    }

    // Get available actions for transfer based on status and user role
    getAvailableActions(transfer, userRole) {
        const actions = [];
        const status = transfer.status;

        // View is always available
        actions.push({
            name: 'View',
            action: 'view',
            icon: '👁️',
            class: 'btn-secondary'
        });

        // Role-based actions
        if (userRole === 'admin' || userRole === 'manager') {
            if (status === 'Pending Approval') {
                actions.push({
                    name: 'Approve',
                    action: 'approve',
                    icon: '✅',
                    class: 'btn-success'
                });
                actions.push({
                    name: 'Reject',
                    action: 'reject',
                    icon: '❌',
                    class: 'btn-danger'
                });
            }
        }

        // Edit/Cancel only for own transfers in draft status
        if (status === 'Draft' || status === 'Rejected') {
            actions.push({
                name: 'Edit',
                action: 'edit',
                icon: '✏️',
                class: 'btn-primary'
            });
            actions.push({
                name: 'Cancel',
                action: 'cancel',
                icon: '🚫',
                class: 'btn-danger'
            });
        }

        return actions;
    }

    // Format date for display (always Philippines time – Asia/Manila, UTC+8)
    formatDate(dateString) {
        if (!dateString) return '—';
        
        try {
            const date = new Date(dateString);
            return date.toLocaleString('en-PH', {
                timeZone: 'Asia/Manila',
                year: 'numeric',
                month: 'short',
                day: 'numeric',
                hour: '2-digit',
                minute: '2-digit',
                hour12: true
            });
        } catch (error) {
            return dateString;
        }
    }

    // Get time elapsed since creation
    getTimeElapsed(dateString) {
        if (!dateString) return '';
        
        try {
            const date = new Date(dateString);
            const now = new Date();
            const diffMs = now - date;
            const diffHours = Math.floor(diffMs / (1000 * 60 * 60));
            const diffDays = Math.floor(diffHours / 24);
            
            if (diffDays > 0) {
                return `${diffDays} day${diffDays > 1 ? 's' : ''} ago`;
            } else if (diffHours > 0) {
                return `${diffHours} hour${diffHours > 1 ? 's' : ''} ago`;
            } else {
                const diffMinutes = Math.floor(diffMs / (1000 * 60));
                return diffMinutes > 0 ? `${diffMinutes} minute${diffMinutes > 1 ? 's' : ''} ago` : 'Just now';
            }
        } catch (error) {
            return '';
        }
    }

    // Get transfer urgency based on age and status
    getTransferUrgency(transfer) {
        if (transfer.status !== 'Pending Approval') {
            return 'normal';
        }

        const submittedDate = new Date(transfer.submittedAt || transfer.createdAt);
        const now = new Date();
        const diffHours = (now - submittedDate) / (1000 * 60 * 60);

        if (diffHours > 48) { // 2+ days
            return 'urgent';
        } else if (diffHours > 24) { // 1+ day
            return 'high';
        } else if (diffHours > 8) { // 8+ hours
            return 'medium';
        }
        
        return 'normal';
    }

    // Export transfer data for reports
    exportTransferData(transfers, format = 'json') {
        const exportData = transfers.map(transfer => ({
            transferNumber: transfer.transferNumber,
            date: transfer.transferDate,
            source: transfer.sourceLocationName,
            destination: transfer.destinationLocationName,
            status: transfer.status,
            requestedBy: transfer.requestedByName,
            itemCount: transfer.items ? transfer.items.length : 0,
            totalQuantity: transfer.totalItems || 0,
            remarks: transfer.remarks
        }));

        if (format === 'csv') {
            return this._convertToCSV(exportData);
        }
        
        return JSON.stringify(exportData, null, 2);
    }

    _convertToCSV(data) {
        if (data.length === 0) return '';
        
        const headers = Object.keys(data[0]);
        const csvHeaders = headers.join(',');
        const csvRows = data.map(row => 
            headers.map(header => `"${(row[header] || '').toString().replace(/"/g, '""')}"`).join(',')
        ).join('\n');
        
        return csvHeaders + '\n' + csvRows;
    }
}
