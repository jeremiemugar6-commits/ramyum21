// Shared number/currency formatting helpers
// Formats a number as "1,234.56" (comma thousands separator, 2 decimal places)
export function formatCurrency(value) {
    const num = parseFloat(value) || 0;
    return num.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

// Formats a whole number as "1,234" (comma thousands separator, no decimals)
export function formatNumber(value) {
    const num = parseFloat(value) || 0;
    return num.toLocaleString(undefined, { maximumFractionDigits: 0 });
}

// Formats a stock/quantity value as "1,234" or "1,234.5" — comma thousands
// separator, showing up to 2 decimal places only when the value isn't a whole number.
export function formatQuantity(value) {
    const num = parseFloat(value) || 0;
    return num.toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 2 });
}
