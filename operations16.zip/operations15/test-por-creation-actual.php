<?php
/**
 * Test Actual POR Creation with Full Error Details
 */

error_reporting(E_ALL);
ini_set('display_errors', 1);

// Simulate the actual API call
$_SERVER['REQUEST_METHOD'] = 'POST';
$_GET['action'] = '';
$_SESSION['user'] = [
    'id' => 'admin',
    'name' => 'System Admin',
    'email' => 'admin@example.com',
    'role' => 'admin'
];

// Capture JSON input
$GLOBALS['test_json_input'] = [
    'action' => 'create-from-receiving',
    'receiving_id' => 'demo_gr_001'
];

// Override get_json_input function for testing
function get_json_input() {
    return $GLOBALS['test_json_input'];
}

echo "TESTING ACTUAL POR CREATION\n";
echo str_repeat("=", 80) . "\n\n";

// Include the POR API (which will execute)
ob_start();
try {
    include 'api/por.php';
    $output = ob_get_clean();
    
    echo "API OUTPUT:\n";
    echo str_repeat("-", 80) . "\n";
    echo $output . "\n";
    echo str_repeat("-", 80) . "\n";
    
    // Try to decode JSON
    $result = json_decode($output, true);
    if ($result) {
        echo "\nPARSED RESPONSE:\n";
        print_r($result);
    } else {
        echo "\nCould not parse JSON response\n";
        echo "Raw output length: " . strlen($output) . " bytes\n";
    }
    
} catch (Exception $e) {
    ob_end_clean();
    echo "EXCEPTION CAUGHT:\n";
    echo "Message: " . $e->getMessage() . "\n";
    echo "Code: " . $e->getCode() . "\n";
    echo "File: " . $e->getFile() . ":" . $e->getLine() . "\n";
    echo "\nStack Trace:\n";
    echo $e->getTraceAsString() . "\n";
}

echo "\n" . str_repeat("=", 80) . "\n";
