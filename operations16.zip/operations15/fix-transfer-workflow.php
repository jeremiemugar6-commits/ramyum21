<?php
/**
 * FIX STOCK TRANSFER WORKFLOW
 * 1. Add missing location data to existing transfers
 * 2. Create Transfer Proof for completed transfer
 * 3. Create complete demo transfer with proof
 */

require_once 'config/database.php';
require_once 'includes/functions.php';

$db = getDB();

echo "═══════════════════════════════════════════════════════════════════════\n";
echo "FIX STOCK TRANSFER WORKFLOW\n";
echo "═══════════════════════════════════════════════════════════════════════\n\n";

try {
    $db->beginTransaction();
    
    // STEP 1: Fix location data for existing transfers
    echo "STEP 1: ADD LOCATION DATA TO EXISTING TRANSFERS\n";
    echo "───────────────────────────────────────────────────────────────────────\n";
    
    $transfers = $db->query("SELECT id, data FROM stock_transfers ORDER BY created_at")->fetchAll();
    
    // Define location assignments for demo transfers
    $locationAssignments = [
        'st_demo_001' => ['from' => 'WH', 'to' => 'MKT', 'type' => 'Warehouse to Branch'],
        'st_demo_002' => ['from' => 'WH', 'to' => 'QC', 'type' => 'Warehouse to Branch'],
        'st_demo_003' => ['from' => 'MKT', 'to' => 'QC', 'type' => 'Branch to Branch'],
        'st_demo_004' => ['from' => 'WH', 'to' => 'BGC', 'type' => 'Warehouse to Storage'],
        'st_1790945276076_be1712' => ['from' => 'WH', 'to' => 'MKT', 'type' => 'Warehouse to Branch'],
        'st_1790965441780_f14019' => ['from' => 'WH', 'to' => 'QC', 'type' => 'Warehouse to Branch']
    ];
    
    // Get location details
    $locations = [];
    $locStmt = $db->query("SELECT id, data FROM locations");
    foreach ($locStmt->fetchAll() as $loc) {
        $locData = json_decode($loc['data'], true);
        $locations[$locData['code']] = [
            'id' => $loc['id'],
            'code' => $locData['code'],
            'name' => $locData['name']
        ];
    }
    
    $updated = 0;
    
    foreach ($transfers as $transfer) {
        $data = json_decode($transfer['data'], true);
        
        if (!isset($locationAssignments[$transfer['id']])) {
            echo "  ⚠ {$transfer['id']}: No location assignment defined\n";
            continue;
        }
        
        $assignment = $locationAssignments[$transfer['id']];
        $from = $locations[$assignment['from']];
        $to = $locations[$assignment['to']];
        
        // Update transfer data
        $data['type'] = $assignment['type'];
        $data['fromLocation'] = $from['code'];
        $data['fromLocationName'] = $from['name'];
        $data['fromLocationId'] = $from['id'];
        $data['toLocation'] = $to['code'];
        $data['toLocationName'] = $to['name'];
        $data['toLocationId'] = $to['id'];
        $data['createdBy'] = 'admin';
        $data['createdByName'] = 'System Admin';
        
        // Update in database
        $updateStmt = $db->prepare("UPDATE stock_transfers SET data = ?, updated_at = NOW() WHERE id = ?");
        $updateStmt->execute([json_encode($data), $transfer['id']]);
        
        echo "  ✓ {$data['transferNumber']}: {$from['name']} → {$to['name']}\n";
        $updated++;
    }
    
    echo "\nTransfers updated: {$updated}\n\n";
    
    // STEP 2: Create Transfer Proof for completed transfer
    echo "STEP 2: CREATE TRANSFER PROOF FOR COMPLETED TRANSFER\n";
    echo "───────────────────────────────────────────────────────────────────────\n";
    
    // Find the completed transfer
    $completedTransfer = null;
    foreach ($transfers as $transfer) {
        $data = json_decode($transfer['data'], true);
        if ($data['status'] === 'Completed') {
            $completedTransfer = $transfer;
            break;
        }
    }
    
    if ($completedTransfer) {
        $transferData = json_decode($completedTransfer['data'], true);
        $assignment = $locationAssignments[$completedTransfer['id']];
        $from = $locations[$assignment['from']];
        $to = $locations[$assignment['to']];
        
        // Create proof ID and number
        $proofId = generate_id('tp');
        $proofNumber = 'TP-' . date('Y') . '-' . str_pad(1, 4, '0', STR_PAD_LEFT);
        
        // Create transfer proof record
        $proofStmt = $db->prepare("
            INSERT INTO transfer_proof (
                id, proof_number, transfer_id, transfer_number,
                source_location_id, source_location_name,
                destination_location_id, destination_location_name,
                transfer_date, delivered_by, delivered_by_name,
                received_by, received_by_name,
                delivery_date, completion_date,
                status, total_items, total_quantity,
                delivery_notes, receiving_notes,
                evidence_files,
                created_at, updated_at
            ) VALUES (
                ?, ?, ?, ?,
                ?, ?,
                ?, ?,
                ?, ?, ?,
                ?, ?,
                ?, ?,
                ?, ?, ?,
                ?, ?,
                ?,
                NOW(), NOW()
            )
        ");
        
        $totalQty = 0;
        foreach ($transferData['items'] as $item) {
            $totalQty += floatval($item['quantity']);
        }
        
        $evidenceFiles = json_encode([
            [
                'type' => 'photo',
                'filename' => 'delivery_photo_001.jpg',
                'description' => 'Products loaded for delivery',
                'timestamp' => date('Y-m-d H:i:s')
            ],
            [
                'type' => 'photo',
                'filename' => 'delivery_photo_002.jpg',
                'description' => 'Products received at destination',
                'timestamp' => date('Y-m-d H:i:s')
            ]
        ]);
        
        $proofStmt->execute([
            $proofId,
            $proofNumber,
            $completedTransfer['id'],
            $transferData['transferNumber'],
            $from['id'],
            $from['name'],
            $to['id'],
            $to['name'],
            date('Y-m-d H:i:s', strtotime('-2 days')),
            'admin',
            'System Admin',
            'manager',
            'Branch Manager',
            date('Y-m-d H:i:s', strtotime('-2 days')),
            date('Y-m-d H:i:s', strtotime('-2 days')),
            'Completed',
            count($transferData['items']),
            $totalQty,
            'All items packaged securely. Ready for delivery.',
            'All items received in good condition. Quantities verified.',
            $evidenceFiles
        ]);
        
        echo "✓ Created Transfer Proof: {$proofNumber}\n";
        echo "  Transfer: {$transferData['transferNumber']}\n";
        echo "  From: {$from['name']}\n";
        echo "  To: {$to['name']}\n";
        echo "  Items: " . count($transferData['items']) . "\n";
        echo "  Quantity: {$totalQty}\n";
        
        // Create proof items
        foreach ($transferData['items'] as $item) {
            $itemId = generate_id('tpi');
            
            $itemStmt = $db->prepare("
                INSERT INTO transfer_proof_items (
                    id, proof_id, product_id, product_name, sku, unit,
                    quantity_transferred, quantity_received,
                    condition_notes, created_at, updated_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())
            ");
            
            $itemStmt->execute([
                $itemId,
                $proofId,
                $item['productId'],
                $item['productName'],
                $item['sku'] ?? 'N/A',
                $item['unit'],
                floatval($item['quantity']),
                floatval($item['quantity']), // Assuming all received
                'Good condition'
            ]);
            
            echo "  ✓ Added proof item: {$item['productName']} ({$item['quantity']} {$item['unit']})\n";
        }
        
        echo "\n";
    } else {
        echo "⚠ No completed transfer found\n\n";
    }
    
    // STEP 3: Create new demo transfer with complete workflow
    echo "STEP 3: CREATE COMPLETE DEMO TRANSFER\n";
    echo "───────────────────────────────────────────────────────────────────────\n";
    
    $newTransferId = generate_id('st');
    $newTransferNumber = 'ST-2026-0007';
    
    // Get some products for the transfer
    $products = $db->query("
        SELECT id, data FROM products 
        WHERE id IN ('RAM001', 'RAM002', 'MEAT001')
    ")->fetchAll();
    
    $transferItems = [];
    foreach ($products as $prod) {
        $prodData = json_decode($prod['data'], true);
        $transferItems[] = [
            'productId' => $prod['id'],
            'productName' => $prodData['name'],
            'sku' => $prodData['sku'],
            'unit' => $prodData['unit'],
            'quantity' => 15,
            'currentStock' => $prodData['stock']
        ];
    }
    
    $newTransferData = [
        'transferNumber' => $newTransferNumber,
        'status' => 'Completed',
        'type' => 'Warehouse to Branch',
        'fromLocation' => 'WH',
        'fromLocationName' => 'Main Warehouse',
        'fromLocationId' => $locations['WH']['id'],
        'toLocation' => 'MKT',
        'toLocationName' => 'Branch 1 - Makati',
        'toLocationId' => $locations['MKT']['id'],
        'createdBy' => 'admin',
        'createdByName' => 'System Admin',
        'approvedBy' => 'admin',
        'approvedByName' => 'System Admin',
        'transferDate' => date('Y-m-d\TH:i:s.v\Z', strtotime('-1 day')),
        'completedDate' => date('Y-m-d\TH:i:s.v\Z'),
        'items' => $transferItems,
        'totalItems' => count($transferItems),
        'totalQuantity' => count($transferItems) * 15,
        'purpose' => 'Stock replenishment for Makati branch',
        'notes' => 'Monthly stock transfer - high demand products'
    ];
    
    // Insert transfer
    $insertStmt = $db->prepare("
        INSERT INTO stock_transfers (id, data, created_at, updated_at)
        VALUES (?, ?, NOW(), NOW())
    ");
    $insertStmt->execute([$newTransferId, json_encode($newTransferData)]);
    
    echo "✓ Created new transfer: {$newTransferNumber}\n";
    echo "  Type: {$newTransferData['type']}\n";
    echo "  From: {$newTransferData['fromLocationName']}\n";
    echo "  To: {$newTransferData['toLocationName']}\n";
    echo "  Items: " . count($transferItems) . "\n";
    
    // Create transfer proof for new transfer
    $newProofId = generate_id('tp');
    $newProofNumber = 'TP-2026-0002';
    
    $newProofStmt = $db->prepare("
        INSERT INTO transfer_proof (
            id, proof_number, transfer_id, transfer_number,
            source_location_id, source_location_name,
            destination_location_id, destination_location_name,
            transfer_date, delivered_by, delivered_by_name,
            received_by, received_by_name,
            delivery_date, completion_date,
            status, total_items, total_quantity,
            delivery_notes, receiving_notes,
            evidence_files, signature_delivered, signature_received,
            created_at, updated_at
        ) VALUES (
            ?, ?, ?, ?,
            ?, ?, ?, ?,
            ?, ?, ?, ?, ?,
            ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,
            NOW(), NOW()
        )
    ");
    
    $newEvidenceFiles = json_encode([
        [
            'type' => 'photo',
            'filename' => 'transfer_loading_001.jpg',
            'description' => 'Products being loaded at Main Warehouse',
            'timestamp' => date('Y-m-d H:i:s', strtotime('-1 day'))
        ],
        [
            'type' => 'photo',
            'filename' => 'transfer_transit_001.jpg',
            'description' => 'Items in transit - secured packaging',
            'timestamp' => date('Y-m-d H:i:s', strtotime('-1 day'))
        ],
        [
            'type' => 'photo',
            'filename' => 'transfer_delivery_001.jpg',
            'description' => 'Delivery at Makati branch',
            'timestamp' => date('Y-m-d H:i:s')
        ],
        [
            'type' => 'photo',
            'filename' => 'transfer_inspection_001.jpg',
            'description' => 'Branch manager inspecting received items',
            'timestamp' => date('Y-m-d H:i:s')
        ]
    ]);
    
    $newProofStmt->execute([
        $newProofId,
        $newProofNumber,
        $newTransferId,
        $newTransferNumber,
        $locations['WH']['id'],
        'Main Warehouse',
        $locations['MKT']['id'],
        'Branch 1 - Makati',
        date('Y-m-d H:i:s', strtotime('-1 day')),
        'admin',
        'System Admin',
        'manager',
        'Branch Manager - Makati',
        date('Y-m-d H:i:s', strtotime('-1 day 08:30:00')),
        date('Y-m-d H:i:s'),
        'Completed',
        count($transferItems),
        $newTransferData['totalQuantity'],
        'All items securely packaged. Temperature-controlled transport for perishables. Estimated delivery time: 2 hours.',
        'All items received and inspected. No damages. Quantities verified and match transfer document. Items placed in storage immediately.',
        $newEvidenceFiles,
        'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg==',  // Demo signature
        'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg=='   // Demo signature
    ]);
    
    echo "✓ Created Transfer Proof: {$newProofNumber}\n";
    
    // Create proof items
    foreach ($transferItems as $item) {
        $itemId = generate_id('tpi');
        
        $itemStmt = $db->prepare("
            INSERT INTO transfer_proof_items (
                id, proof_id, product_id, product_name, sku, unit,
                quantity_transferred, quantity_received,
                condition_notes, created_at, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())
        ");
        
        $itemStmt->execute([
            $itemId,
            $newProofId,
            $item['productId'],
            $item['productName'],
            $item['sku'],
            $item['unit'],
            $item['quantity'],
            $item['quantity'],
            'Excellent condition - no damage during transit'
        ]);
        
        echo "  ✓ Added proof item: {$item['productName']}\n";
    }
    
    // Create inventory movements for new transfer
    echo "\n  Creating inventory movements...\n";
    
    foreach ($transferItems as $item) {
        // Stock Out from warehouse
        $movOutId = generate_id('inv_mov');
        $movOutData = [
            'id' => $movOutId,
            'productId' => $item['productId'],
            'productName' => $item['productName'],
            'sku' => $item['sku'],
            'date' => date('Y-m-d\TH:i:s.v\Z'),
            'type' => 'Stock Out',
            'referenceType' => 'STOCK_TRANSFER',
            'referenceId' => $newTransferNumber,
            'quantity' => $item['quantity'],
            'previousBalance' => $item['currentStock'],
            'newBalance' => $item['currentStock'] - $item['quantity'],
            'change' => -$item['quantity'],
            'reason' => 'Stock Transfer - Out',
            'notes' => "Transfer {$newTransferNumber} from Main Warehouse to Makati Branch",
            'user' => 'System Admin',
            'location' => 'WH'
        ];
        
        $movOutStmt = $db->prepare("
            INSERT INTO inventory_movements (id, data, created_at, updated_at)
            VALUES (?, ?, NOW(), NOW())
        ");
        $movOutStmt->execute([$movOutId, json_encode($movOutData)]);
        
        echo "    - Stock Out: {$item['productName']} (-{$item['quantity']})\n";
    }
    
    echo "\n";
    
    $db->commit();
    
    echo "═══════════════════════════════════════════════════════════════════════\n";
    echo "VERIFICATION\n";
    echo "═══════════════════════════════════════════════════════════════════════\n";
    
    $totalTransfers = $db->query("SELECT COUNT(*) FROM stock_transfers")->fetchColumn();
    $totalProofs = $db->query("SELECT COUNT(*) FROM transfer_proof")->fetchColumn();
    $totalProofItems = $db->query("SELECT COUNT(*) FROM transfer_proof_items")->fetchColumn();
    
    $transfersWithLocations = $db->query("
        SELECT COUNT(*) FROM stock_transfers
        WHERE JSON_EXTRACT(data, '$.fromLocation') IS NOT NULL
    ")->fetchColumn();
    
    $transfersWithProof = $db->query("
        SELECT COUNT(*) FROM stock_transfers st
        INNER JOIN transfer_proof tp ON st.id = tp.transfer_id
    ")->fetchColumn();
    
    echo "Total Transfers: {$totalTransfers}\n";
    echo "Transfers with location data: {$transfersWithLocations}/{$totalTransfers}\n";
    echo "Transfer Proofs: {$totalProofs}\n";
    echo "Transfer Proof Items: {$totalProofItems}\n";
    echo "Transfers with proof: {$transfersWithProof}/{$totalTransfers}\n";
    
    echo "\n";
    
    if ($transfersWithLocations == $totalTransfers && $totalProofs > 0) {
        echo "✅ SUCCESS: Stock Transfer workflow fixed!\n";
        echo "✅ All transfers now have location data\n";
        echo "✅ Transfer Proof records created\n";
        echo "✅ Complete workflow demonstrated\n";
    } else {
        echo "⚠ PARTIAL: Some issues remain\n";
    }
    
    echo "\n";
    echo "═══════════════════════════════════════════════════════════════════════\n";
    echo "FIX COMPLETE\n";
    echo "═══════════════════════════════════════════════════════════════════════\n";
    
} catch (Exception $e) {
    $db->rollBack();
    echo "\n✗ ERROR: " . $e->getMessage() . "\n";
    echo $e->getTraceAsString() . "\n";
    exit(1);
}
