<?php
require_once __DIR__ . '/includes/auth.php';

// Real server-side auth guard — redirects to index.php if not logged in.
$currentUser = require_login_page();
log_security_event('PAGE_ACCESS', $currentUser['id'], $currentUser['username'], ['page' => 'dashboard']);

// The profile picture can be a large base64 data URL; keep it out of the
// inline JSON if huge is unnecessary here, but for simplicity we pass it through.
$userForJs = [
    'id' => $currentUser['id'],
    'name' => $currentUser['name'],
    'email' => $currentUser['email'],
    'username' => $currentUser['username'],
    'role' => $currentUser['role'],
    'profilePicture' => $currentUser['profile_picture'],
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - RAM-YUM Store</title>
    <link rel="stylesheet" href="assets/css/main.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
    <script type="module" src="assets/js/utils/badge-helper.js"></script>

    <style>
        #menuToggle {
            display: none; background: none; border: none; cursor: pointer;
            padding: 6px; color: var(--text-primary); border-radius: 8px; transition: background 0.18s;
        }
        #menuToggle:hover { background: var(--bg-gray); }

        @media (max-width: 768px) {
            #menuToggle { display: flex !important; align-items: center; justify-content: center; }
            .sidebar { transform: translateX(-100%); }
            .sidebar.open { transform: translateX(0); }
            .main-content { margin-left: 0; }
        }

        #appContent { animation: fadeIn 0.22s ease-out both; }

        #profileBtn {
            width: 42px; height: 42px; border-radius: 50%; overflow: hidden; cursor: pointer;
            border: 2px solid var(--border-color);
            background: linear-gradient(135deg, var(--primary-orange), var(--primary-red));
            display: flex; align-items: center; justify-content: center;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1); flex-shrink: 0; position: relative;
        }
        #profileBtn:hover { transform: scale(1.1) rotate(5deg); box-shadow: 0 4px 16px rgba(255, 122, 0, 0.4); }
        #profileInitial { color: #fff; font-weight: 700; font-size: 16px; line-height: 1; text-shadow: 0 2px 4px rgba(0, 0, 0, 0.2); }
        @keyframes spin { to { transform: rotate(360deg); } }
    </style>
</head>
<body>
    <div class="dashboard-wrapper">

        <!-- ===================== SIDEBAR ===================== -->
        <aside class="sidebar" id="sidebar">
            <div class="sidebar-brand">
                <img src="assets/images/logo.jpg" alt="RAM-YUM Logo">
                <div class="sidebar-brand-text">
                    <h3>RAM-YUM</h3>
                    <span>Korean &amp; Japanese Store</span>
                </div>
            </div>

            <nav class="sidebar-nav" id="sidebarNav">
                <a href="#" class="nav-item active" data-page="dashboard">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"/></svg>
                    Dashboard
                </a>
                <a href="#" class="nav-item" data-page="products">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4"/></svg>
                    Products
                </a>
                <a href="#" class="nav-item" data-page="inventory">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="7" width="20" height="14" rx="2" ry="2"/><path d="M16 21V5a2 2 0 00-2-2h-4a2 2 0 00-2 2v16"/></svg>
                    Inventory
                </a>
                <a href="#" class="nav-item" data-page="suppliers">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 16V8a2 2 0 00-1-1.73l-7-4a2 2 0 00-2 0l-7 4A2 2 0 003 8v8a2 2 0 001 1.73l7 4a2 2 0 002 0l7-4A2 2 0 0021 16z"/><path d="M3.3 7l8.7 5 8.7-5M12 22V12"/></svg>
                    Suppliers
                </a>
                <a href="#" class="nav-item" data-page="purchase-orders">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2"/><path d="M9 14l2 2 4-4"/></svg>
                    Purchase Orders
                </a>
                <a href="#" class="nav-item" data-page="receiving">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M5 13h14M5 13a2 2 0 01-2-2V5a2 2 0 012-2h14a2 2 0 012 2v6a2 2 0 01-2 2M5 13v4a2 2 0 002 2h10a2 2 0 002-2v-4"/><path d="M9 17h6"/></svg>
                    Receiving
                </a>
                <a href="#" class="nav-item" data-page="por">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-6 9l2 2 4-4"/></svg>
                    Proof of Receiving
                </a>
                <?php if ($currentUser['role'] === 'admin'): ?>
                <a href="#" class="nav-item" data-page="locations">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg>
                    Locations
                </a>
                <?php endif; ?>
                <a href="#" class="nav-item" data-page="stock-transfer">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 6h18M3 12h18M3 18h18"/><path d="M6 3v3M18 3v3M6 21v-3M18 21v-3"/></svg>
                    Stock Transfer
                </a>
                <a href="#" class="nav-item" data-page="reports">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"/></svg>
                    Reports
                </a>
                <a href="#" class="nav-item" data-page="recent-activity">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
                    Recent Activity
                </a>
                <?php if ($currentUser['role'] === 'admin' || $currentUser['role'] === 'manager'): ?>
                <a href="#" class="nav-item" data-page="ai-analytics">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 2a10 10 0 100 20 10 10 0 000-20z"/><path d="M12 8v4l3 3"/></svg>
                    AI Analytics
                </a>
                <?php endif; ?>
                <?php if ($currentUser['role'] === 'admin'): ?>
                <a href="#" class="nav-item" data-page="settings">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 00.33 1.82l.06.06a2 2 0 010 2.83 2 2 0 01-2.83 0l-.06-.06a1.65 1.65 0 00-1.82-.33 1.65 1.65 0 00-1 1.51V21a2 2 0 01-2 2 2 2 0 01-2-2v-.09A1.65 1.65 0 009 19.4a1.65 1.65 0 00-1.82.33l-.06.06a2 2 0 01-2.83 0 2 2 0 010-2.83l.06-.06a1.65 1.65 0 00.33-1.82 1.65 1.65 0 00-1.51-1H3a2 2 0 01-2-2 2 2 0 012-2h.09A1.65 1.65 0 004.6 9a1.65 1.65 0 00-.33-1.82l-.06-.06a2 2 0 010-2.83 2 2 0 012.83 0l.06.06a1.65 1.65 0 001.82.33H9a1.65 1.65 0 001-1.51V3a2 2 0 012-2 2 2 0 012 2v.09a1.65 1.65 0 001 1.51 1.65 1.65 0 001.82-.33l.06-.06a2 2 0 012.83 0 2 2 0 010 2.83l-.06.06a1.65 1.65 0 00-.33 1.82V9a1.65 1.65 0 001.51 1H21a2 2 0 012 2 2 2 0 01-2 2h-.09a1.65 1.65 0 00-1.51 1z"/></svg>
                    Settings
                </a>
                <?php endif; ?>
            </nav>

            <div class="sidebar-footer">
                <button id="logoutBtn" class="logout-btn">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 21H5a2 2 0 01-2-2V5a2 2 0 012-2h4M16 17l5-5-5-5M21 12H9"/></svg>
                    Logout
                </button>
            </div>
        </aside>

        <!-- ===================== MAIN CONTENT ===================== -->
        <main class="main-content">
            <header class="top-navbar">
                <div style="display:flex; align-items:center; gap:12px;">
                    <button id="menuToggle" aria-label="Toggle sidebar">
                        <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 6h16M4 12h16M4 18h16"/></svg>
                    </button>
                </div>

                <div class="navbar-actions">
                    <button class="nav-btn" id="themeToggle" title="Toggle theme" aria-label="Toggle theme">
                        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="5"/><path d="M12 1v2M12 21v2M4.22 4.22l1.42 1.42M18.36 18.36l1.42 1.42M1 12h2M21 12h2M4.22 19.78l1.42-1.42M18.36 5.64l1.42-1.42"/></svg>
                    </button>
                    <div id="profileBtn" title="Edit profile" aria-label="Edit profile">
                        <img id="profileAvatar" src="" alt="Profile" style="width:100%; height:100%; object-fit:cover; display:none;">
                        <span id="profileInitial">A</span>
                    </div>
                </div>
            </header>

            <div id="appContent" class="fade-in">
                <div style="display:flex; align-items:center; justify-content:center; padding:60px; color:var(--text-muted);">
                    <div class="loading-spinner" style="margin-right:16px;"></div>
                    <span style="font-weight:500;">Loading System...</span>
                </div>
            </div>
        </main>
    </div>

    <script type="module">
        import { store } from './assets/js/store.js';
        import { toast } from './assets/js/components/toast.js';
        import { modal } from './assets/js/components/modal.js';

        // --- SEED STATE FROM THE SERVER SESSION (real PHP auth, not client-trust) ---
        const currentUser = <?php echo json_encode($userForJs); ?>;
        store.dispatch({ isAuthenticated: true, user: currentUser, role: currentUser.role });

        // --- PROFILE LOADER ---
        function loadProfile() {
            const user = store.getState().user;
            if (!user) return;
            const avatarImg = document.getElementById('profileAvatar');
            const initialSpan = document.getElementById('profileInitial');
            if (user.profilePicture) {
                avatarImg.src = user.profilePicture;
                avatarImg.style.display = 'block';
                initialSpan.style.display = 'none';
            } else {
                avatarImg.style.display = 'none';
                initialSpan.style.display = 'flex';
                initialSpan.textContent = user.name ? user.name.charAt(0).toUpperCase() : 'A';
            }
        }

        // --- PROFILE MODAL ---
        function openProfileModal() {
            const user = store.getState().user;
            if (!user) return;
            const formHTML = `
                <form id="profileForm" style="display:grid; gap:16px;">
                    <div style="text-align:center; padding:10px;">
                        <div style="width:90px; height:90px; border-radius:50%; overflow:hidden; margin:0 auto 10px; border:2px solid var(--border-color); background:var(--bg-gray); display:flex; align-items:center; justify-content:center;">
                            <img id="modalProfilePreview" src="${user.profilePicture || ''}" style="width:100%; height:100%; object-fit:cover; ${user.profilePicture ? '' : 'display:none;'}">
                            <span id="modalProfilePlaceholder" style="font-size:24px; color:var(--text-muted); ${user.profilePicture ? 'display:none;' : ''}">👤</span>
                        </div>
                        <input type="file" id="profileImageInput" accept="image/*" style="display:block; margin:0 auto; font-size:0.8rem; color:var(--text-secondary);">
                    </div>
                    <div>
                        <label style="display:block; font-weight:600; margin-bottom:6px; color:var(--text-primary); font-size:0.875rem;">Display Name *</label>
                        <input type="text" id="profileNameInput" value="${user.name || ''}" class="form-input" required>
                    </div>
                </form>
            `;
            modal.open('Edit Profile', formHTML, {
                confirmText: 'Save Changes',
                onConfirm: async () => {
                    const newName = document.getElementById('profileNameInput').value.trim();
                    const fileInput = document.getElementById('profileImageInput');
                    let newImage = null;
                    if (fileInput.files && fileInput.files[0]) {
                        const file = fileInput.files[0];
                        newImage = await new Promise((resolve) => {
                            const reader = new FileReader();
                            reader.onload = (e) => resolve(e.target.result);
                            reader.readAsDataURL(file);
                        });
                    }
                    if (!newName) { toast.show('Name cannot be empty.', 'error'); return; }

                    try {
                        const res = await fetch('api/profile.php', {
                            method: 'POST',
                            headers: { 'Content-Type': 'application/json' },
                            body: JSON.stringify({ name: newName, profilePicture: newImage })
                        });
                        const result = await res.json();
                        if (!result.success) throw new Error(result.error || 'Update failed.');

                        store.dispatch({ user: { ...user, name: newName, ...(newImage ? { profilePicture: newImage } : {}) } });
                        toast.show('Profile updated successfully!', 'success');
                        modal.close();
                        loadProfile();
                    } catch (error) {
                        toast.show(error.message || 'Failed to update profile.', 'error');
                    }
                }
            });
            document.getElementById('profileImageInput').addEventListener('change', (e) => {
                const file = e.target.files[0];
                if (file) {
                    const reader = new FileReader();
                    reader.onload = (ev) => {
                        document.getElementById('modalProfilePreview').src = ev.target.result;
                        document.getElementById('modalProfilePreview').style.display = 'block';
                        document.getElementById('modalProfilePlaceholder').style.display = 'none';
                    };
                    reader.readAsDataURL(file);
                }
            });
        }

        // --- SIDEBAR TOGGLE ---
        const menuToggle = document.getElementById('menuToggle');
        const sidebar = document.getElementById('sidebar');
        menuToggle.addEventListener('click', (e) => { e.stopPropagation(); sidebar.classList.toggle('open'); });
        document.addEventListener('click', (e) => {
            if (window.innerWidth <= 768 && !sidebar.contains(e.target) && !menuToggle.contains(e.target) && sidebar.classList.contains('open')) {
                sidebar.classList.remove('open');
            }
        });
        window.addEventListener('resize', () => { if (window.innerWidth > 768) sidebar.classList.remove('open'); });

        // --- ROUTING ---
        const appContent = document.getElementById('appContent');
        const navLinks = document.querySelectorAll('.nav-item');
        const routeModules = {
            dashboard:        () => import('./modules/dashboard/dashboard.js').then(m => m.renderDashboard()),
            products:         () => import('./modules/products/catalog.js').then(m => m.renderProductCatalog()),
            inventory:        () => import('./modules/inventory/inventory.js').then(m => m.renderInventory()),
            suppliers:        () => import('./modules/suppliers/suppliers.js').then(m => m.renderSuppliers()),
            'purchase-orders':() => import('./modules/purchase-orders/purchase-orders.js').then(m => m.renderPurchaseOrders()),
            receiving:        () => import('./modules/receiving/receiving.js').then(m => m.renderReceiving()),
            por:              () => import('./modules/por/index.js').then(m => m.renderPOR()),
            'stock-transfer': () => import('./modules/stock-transfer/stock-transfer.js').then(m => m.renderStockTransfer()),
            locations:        () => import('./modules/locations/locations.js').then(m => m.renderLocations()),
            reports:          () => import('./modules/reports/reports.js').then(m => m.renderReports()),
            'recent-activity':() => import('./modules/activity/activity.js').then(m => m.renderRecentActivity()),
            'ai-analytics':   () => import('./modules/ai-analytics/ai-analytics.js').then(m => m.renderAIAnalytics()),
            settings:         () => import('./modules/settings/settings.js').then(m => m.renderSettings())
        };

        const navigateTo = async (page) => {
            navLinks.forEach(l => l.classList.remove('active'));
            const activeLink = Array.from(navLinks).find(l => l.dataset.page === page);
            if (activeLink) activeLink.classList.add('active');
            appContent.innerHTML = `<div style="display:flex;align-items:center;justify-content:center;padding:60px;color:var(--text-muted);"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="animation:spin 1s linear infinite;margin-right:10px;"><path d="M21 12a9 9 0 11-18 0 9 9 0 0118 0z" opacity=".3"/><path d="M21 12a9 9 0 00-9-9"/></svg>Loading...</div>`;
            if (routeModules[page]) {
                try { await routeModules[page](); }
                catch (error) {
                    console.error(`Failed to load module ${page}:`, error);
                    appContent.innerHTML = `<div class="card" style="padding:40px; text-align:center;"><h2 style="color:var(--text-primary); margin-bottom:12px;">Module Unavailable</h2><p style="color:var(--text-secondary);">This module has not been implemented yet.</p></div>`;
                }
            } else {
                appContent.innerHTML = `<div class="card" style="padding:40px; text-align:center;"><h2 style="color:var(--text-primary);">404 — Page Not Found</h2></div>`;
            }
        };

        navLinks.forEach(link => {
            link.addEventListener('click', (e) => { e.preventDefault(); navigateTo(link.dataset.page); });
        });

        navigateTo('dashboard');

        // --- THEME TOGGLE ---
        const themeToggle = document.getElementById('themeToggle');
        const currentTheme = localStorage.getItem('theme') || 'light';
        document.documentElement.setAttribute('data-theme', currentTheme);
        themeToggle.addEventListener('click', () => {
            const next = document.documentElement.getAttribute('data-theme') === 'light' ? 'dark' : 'light';
            document.documentElement.setAttribute('data-theme', next);
            localStorage.setItem('theme', next);
        });

        // --- PROFILE ---
        document.getElementById('profileBtn').addEventListener('click', openProfileModal);

        // --- LOGOUT ---
        document.getElementById('logoutBtn').addEventListener('click', async () => {
            await fetch('api/logout.php');
            store.dispatch({ isAuthenticated: false, user: null, role: null });
            toast.show('Logged out successfully.', 'info');
            setTimeout(() => window.location.href = 'index.php', 500);
        });

        loadProfile();
        store.subscribe((state) => { if (state.user) loadProfile(); });
    </script>
</body>
</html>
