-- =====================================================================
-- STEP 4: Add Demo Stock Transfer Data
-- Run this fourth in phpMyAdmin
-- =====================================================================

USE ramyum_db;

-- Add demo stock transfer records
INSERT INTO stock_transfers (id, data) VALUES
('st_demo_001', JSON_OBJECT(
    'id', 'st_demo_001',
    'transferNumber', 'ST-2026-0101',
    'transferDate', DATE_FORMAT(NOW(), '%Y-%m-%d'),
    'sourceLocationId', 'loc1',
    'sourceLocationName', 'Main Warehouse',
    'destinationLocationId', 'loc2',
    'destinationLocationName', 'Branch 1 - Makati',
    'requestedBy', 'u2',
    'requestedByName', 'Staff User',
    'status', 'Pending Approval',
    'priority', 'High',
    'remarks', 'URGENT: Branch 1 nearly out of stock on bestsellers. Weekend rush expected.',
    'items', JSON_ARRAY(
        JSON_OBJECT(
            'productId', 'p1',
            'productName', 'Samyang Buldak Original',
            'sku', 'SB-001',
            'quantity', 50,
            'unit', 'pcs',
            'sourceStock', 150,
            'destinationStock', 30
        ),
        JSON_OBJECT(
            'productId', 'p2',
            'productName', 'Shin Ramyun',
            'sku', 'SR-002',
            'quantity', 40,
            'unit', 'pcs',
            'sourceStock', 200,
            'destinationStock', 25
        )
    ),
    'totalItems', 90,
    'estimatedValue', 2250.00,
    'createdAt', DATE_FORMAT(DATE_SUB(NOW(), INTERVAL 2 HOUR), '%Y-%m-%dT%H:%i:%s.000Z'),
    'submittedAt', DATE_FORMAT(DATE_SUB(NOW(), INTERVAL 2 HOUR), '%Y-%m-%dT%H:%i:%s.000Z')
)),

('st_demo_002', JSON_OBJECT(
    'id', 'st_demo_002',
    'transferNumber', 'ST-2026-0103',
    'transferDate', DATE_FORMAT(DATE_SUB(NOW(), INTERVAL 1 DAY), '%Y-%m-%d'),
    'sourceLocationId', 'loc1',
    'sourceLocationName', 'Main Warehouse',
    'destinationLocationId', 'loc4',
    'destinationLocationName', 'Storage Area - BGC',
    'requestedBy', 'u2',
    'requestedByName', 'Staff User',
    'status', 'Approved',
    'priority', 'Medium',
    'remarks', 'Seasonal inventory redistribution. Moving overflow inventory to BGC storage facility.',
    'items', JSON_ARRAY(
        JSON_OBJECT(
            'productId', 'p3',
            'productName', 'Ottogi Jin Ramen',
            'sku', 'OJ-003',
            'quantity', 50,
            'unit', 'pcs',
            'sourceStock', 100,
            'destinationStock', 0,
            'transferredQuantity', 50
        )
    ),
    'totalItems', 50,
    'estimatedValue', 1000.00,
    'approvedBy', 'u1',
    'approvedByName', 'Admin User',
    'approvedAt', DATE_FORMAT(DATE_SUB(NOW(), INTERVAL 6 HOUR), '%Y-%m-%dT%H:%i:%s.000Z'),
    'approvalRemarks', 'Approved for inventory optimization. BGC facility has adequate space.',
    'createdAt', DATE_FORMAT(DATE_SUB(NOW(), INTERVAL 1 DAY), '%Y-%m-%dT%H:%i:%s.000Z'),
    'submittedAt', DATE_FORMAT(DATE_SUB(NOW(), INTERVAL 22 HOUR), '%Y-%m-%dT%H:%i:%s.000Z')
)),

('st_demo_003', JSON_OBJECT(
    'id', 'st_demo_003',
    'transferNumber', 'ST-2026-0104',
    'transferDate', DATE_FORMAT(DATE_SUB(NOW(), INTERVAL 2 DAY), '%Y-%m-%d'),
    'sourceLocationId', 'loc2',
    'sourceLocationName', 'Branch 1 - Makati',
    'destinationLocationId', 'loc3',
    'destinationLocationName', 'Branch 2 - Quezon City',
    'requestedBy', 'u2',
    'requestedByName', 'Staff User',
    'status', 'Rejected',
    'priority', 'Medium',
    'remarks', 'Inter-branch transfer for customer special order.',
    'items', JSON_ARRAY(
        JSON_OBJECT(
            'productId', 'p1',
            'productName', 'Samyang Buldak Original',
            'sku', 'SB-001',
            'quantity', 35,
            'unit', 'pcs',
            'sourceStock', 30,
            'destinationStock', 20
        )
    ),
    'totalItems', 35,
    'estimatedValue', 875.00,
    'rejectedBy', 'u3',
    'rejectedByName', 'Manager User',
    'rejectedAt', DATE_FORMAT(DATE_SUB(NOW(), INTERVAL 1 DAY), '%Y-%m-%dT%H:%i:%s.000Z'),
    'rejectionReason', 'Insufficient stock at source location. Branch 1 has only 30 units but 35 requested. Would leave branch understocked.',
    'alternativeAction', 'Transfer from Main Warehouse (150 units available) or reduce order quantity to 10 units.',
    'createdAt', DATE_FORMAT(DATE_SUB(NOW(), INTERVAL 2 DAY), '%Y-%m-%dT%H:%i:%s.000Z'),
    'submittedAt', DATE_FORMAT(DATE_SUB(NOW(), INTERVAL 46 HOUR), '%Y-%m-%dT%H:%i:%s.000Z')
))
ON DUPLICATE KEY UPDATE id = id;

-- Verify demo transfers were added
SELECT 'Step 4 Complete: Demo Transfers Added' as status;
SELECT COUNT(*) as transfer_count FROM stock_transfers WHERE id LIKE 'st_demo_%';
SELECT 
    JSON_UNQUOTE(JSON_EXTRACT(data, '$.transferNumber')) as transfer_number,
    JSON_UNQUOTE(JSON_EXTRACT(data, '$.status')) as status
FROM stock_transfers WHERE id LIKE 'st_demo_%';