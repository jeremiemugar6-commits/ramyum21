-- =====================================================================
-- DATA MIGRATION SCRIPT: ramyum_db → ram_yum_inventory
-- Consolidates existing database into centralized structure
-- IMPORTANT: Run this script with FULL DATABASE BACKUP first!
-- =====================================================================

-- Create backup of original database first
-- mysqldump -u root -p ramyum_db > ramyum_db_backup.sql

-- =====================================================================
-- STEP 1: CREATE NEW CENTRALIZED DATABASE
-- =====================================================================

CREATE DATABASE IF NOT EXISTS ram_yum_inventory CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE ram_yum_inventory;

-- =====================================================================
-- STEP 2: CREATE ALL TABLES WITH CORRECT STRUCTURE
-- =====================================================================

-- Authentication & Security Tables
CREATE TABLE IF NOT EXISTS users (
    id              VARCHAR(40)  PRIMARY KEY,
    name            VARCHAR(150) NOT NULL,
    email           VARCHAR(150) NOT NULL UNIQUE,
    username        VARCHAR(100) NOT NULL UNIQUE,
    password_hash   VARCHAR(255) NOT NULL,
    role            ENUM('admin','manager','staff') NOT NULL DEFAULT 'staff',
    verified        TINYINT(1)   NOT NULL DEFAULT 1,
    profile_picture LONGTEXT     NULL,
    created_at      DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at      DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    INDEX idx_email (email),
    INDEX idx_username (username),
    INDEX idx_role (role)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS login_attempts (
    identifier    VARCHAR(150) PRIMARY KEY,
    attempt_count INT          NOT NULL DEFAULT 0,
    last_attempt  DATETIME     NOT NULL,
    
    INDEX idx_last_attempt (last_attempt)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS otp_codes (
    id          VARCHAR(40)  PRIMARY KEY,
    user_id     VARCHAR(40)  NOT NULL,
    code_hash   VARCHAR(255) NOT NULL,
    purpose     VARCHAR(30)  NOT NULL DEFAULT 'login',
    attempts    INT          NOT NULL DEFAULT 0,
    expires_at  DATETIME     NOT NULL,
    consumed_at DATETIME     NULL,
    created_at  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    
    INDEX idx_user_id (user_id),
    INDEX idx_expires_at (expires_at),
    CONSTRAINT fk_otp_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS security_logs (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    event_type  VARCHAR(100) NOT NULL,
    user_id     VARCHAR(40)  NULL,
    username    VARCHAR(100) NULL,
    details     JSON         NULL,
    ip_address  VARCHAR(64)  NULL,
    created_at  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    
    INDEX idx_event_type (event_type),
    INDEX idx_user_id (user_id),
    INDEX idx_created_at (created_at)
) ENGINE=InnoDB;

-- Master Data Tables (JSON Document Storage)
CREATE TABLE IF NOT EXISTS categories (
    id         VARCHAR(40) PRIMARY KEY,
    data       JSON        NOT NULL,
    created_at DATETIME    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME    NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    INDEX idx_created_at (created_at)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS suppliers (
    id         VARCHAR(40) PRIMARY KEY,
    data       JSON        NOT NULL,
    created_at DATETIME    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME    NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    INDEX idx_created_at (created_at)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS products (
    id         VARCHAR(40) PRIMARY KEY,
    data       JSON        NOT NULL,
    created_at DATETIME    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME    NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    INDEX idx_created_at (created_at)
) ENGINE=InnoDB;

-- Location & Inventory Tables
CREATE TABLE IF NOT EXISTS locations (
    id         VARCHAR(40) PRIMARY KEY,
    data       JSON        NOT NULL,
    created_at DATETIME    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME    NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    INDEX idx_created_at (created_at)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS inventory_locations (
    id         VARCHAR(40) PRIMARY KEY,
    data       JSON        NOT NULL,
    created_at DATETIME    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME    NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    INDEX idx_created_at (created_at)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS inventory_movements (
    id         VARCHAR(40) PRIMARY KEY,
    data       JSON        NOT NULL,
    created_at DATETIME    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME    NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    INDEX idx_created_at (created_at)
) ENGINE=InnoDB;

-- Transaction Tables
CREATE TABLE IF NOT EXISTS purchase_orders (
    id         VARCHAR(40) PRIMARY KEY,
    data       JSON        NOT NULL,
    created_at DATETIME    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME    NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    INDEX idx_created_at (created_at)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS receivings (
    id         VARCHAR(40) PRIMARY KEY,
    data       JSON        NOT NULL,
    created_at DATETIME    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME    NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    INDEX idx_created_at (created_at)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS stock_transfers (
    id         VARCHAR(40) PRIMARY KEY,
    data       JSON        NOT NULL,
    created_at DATETIME    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME    NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    INDEX idx_created_at (created_at)
) ENGINE=InnoDB;

-- FIXED: Stock Transfer Audit Table with correct structure
CREATE TABLE IF NOT EXISTS stock_transfer_audit (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    transfer_id VARCHAR(100) NOT NULL,
    action_type VARCHAR(50)  NOT NULL,
    user_id     VARCHAR(40)  NOT NULL,
    user_name   VARCHAR(150) NOT NULL,
    details     JSON         NULL,
    ip_address  VARCHAR(64)  NULL,
    created_at  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    
    INDEX idx_transfer_id (transfer_id),
    INDEX idx_action_type (action_type),
    INDEX idx_user_id (user_id),
    INDEX idx_created_at (created_at)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS stock_adjustments (
    id         VARCHAR(40) PRIMARY KEY,
    data       JSON        NOT NULL,
    created_at DATETIME    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME    NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    INDEX idx_created_at (created_at)
) ENGINE=InnoDB;

-- Analytics Table
CREATE TABLE IF NOT EXISTS inventory_predictions (
    prediction_id        VARCHAR(40)    PRIMARY KEY,
    product_id           VARCHAR(40)    NOT NULL,
    prediction_date      DATE           NOT NULL,
    historical_quantity  DECIMAL(12,2)  NOT NULL DEFAULT 0,
    predicted_quantity   DECIMAL(12,2)  NOT NULL DEFAULT 0,
    demand_status        VARCHAR(20)    NOT NULL DEFAULT 'Stable',
    recommended_stock    DECIMAL(12,2)  NOT NULL DEFAULT 0,
    accuracy_score       DECIMAL(5,2)   NOT NULL DEFAULT 0,
    created_at          DATETIME       NOT NULL DEFAULT CURRENT_TIMESTAMP,
    
    UNIQUE KEY uniq_product (product_id),
    INDEX idx_prediction_date (prediction_date),
    INDEX idx_demand_status (demand_status)
) ENGINE=InnoDB;

-- =====================================================================
-- STEP 3: MIGRATE DATA FROM OLD DATABASE (IF EXISTS)
-- =====================================================================

-- Check if source database exists
SET @source_db_exists = (SELECT COUNT(*) FROM information_schema.SCHEMATA WHERE SCHEMA_NAME = 'ramyum_db');

-- Migrate data only if source database exists
-- Authentication & Security Data
INSERT IGNORE INTO users 
SELECT * FROM ramyum_db.users WHERE @source_db_exists > 0;

INSERT IGNORE INTO login_attempts 
SELECT * FROM ramyum_db.login_attempts WHERE @source_db_exists > 0;

INSERT IGNORE INTO otp_codes 
SELECT * FROM ramyum_db.otp_codes WHERE @source_db_exists > 0;

INSERT IGNORE INTO security_logs 
SELECT * FROM ramyum_db.security_logs WHERE @source_db_exists > 0;

-- Master Data Migration
INSERT IGNORE INTO categories 
SELECT * FROM ramyum_db.categories WHERE @source_db_exists > 0;

INSERT IGNORE INTO suppliers 
SELECT * FROM ramyum_db.suppliers WHERE @source_db_exists > 0;

INSERT IGNORE INTO products 
SELECT * FROM ramyum_db.products WHERE @source_db_exists > 0;

-- Location & Inventory Data
INSERT IGNORE INTO locations 
SELECT * FROM ramyum_db.locations WHERE @source_db_exists > 0;

INSERT IGNORE INTO inventory_locations 
SELECT * FROM ramyum_db.inventory_locations WHERE @source_db_exists > 0;

INSERT IGNORE INTO inventory_movements 
SELECT * FROM ramyum_db.inventory_movements WHERE @source_db_exists > 0;

-- Transaction Data
INSERT IGNORE INTO purchase_orders 
SELECT * FROM ramyum_db.purchase_orders WHERE @source_db_exists > 0;

INSERT IGNORE INTO receivings 
SELECT * FROM ramyum_db.receivings WHERE @source_db_exists > 0;

INSERT IGNORE INTO stock_transfers 
SELECT * FROM ramyum_db.stock_transfers WHERE @source_db_exists > 0;

INSERT IGNORE INTO stock_adjustments 
SELECT * FROM ramyum_db.stock_adjustments WHERE @source_db_exists > 0;

INSERT IGNORE INTO inventory_predictions 
SELECT * FROM ramyum_db.inventory_predictions WHERE @source_db_exists > 0;

-- =====================================================================
-- STEP 4: MIGRATE STOCK TRANSFER AUDIT DATA (CONVERT STRUCTURE)
-- =====================================================================

-- Check if old audit table exists and what structure it has
SET @old_audit_exists = (SELECT COUNT(*) FROM information_schema.TABLES 
    WHERE TABLE_SCHEMA = 'ramyum_db' AND TABLE_NAME = 'stock_transfer_audit');

SET @old_structure = (SELECT COUNT(*) FROM information_schema.COLUMNS 
    WHERE TABLE_SCHEMA = 'ramyum_db' AND TABLE_NAME = 'stock_transfer_audit' AND COLUMN_NAME = 'action');

-- Migrate audit data with structure conversion if needed
INSERT INTO stock_transfer_audit (transfer_id, action_type, user_id, user_name, details, created_at)
SELECT 
    COALESCE(
        (SELECT st.id FROM stock_transfers st 
         WHERE JSON_UNQUOTE(JSON_EXTRACT(st.data, '$.transferNumber')) = old.transfer_id 
         LIMIT 1),
        old.transfer_id
    ) as transfer_id,
    CASE 
        WHEN UPPER(old.action) LIKE 'TRANSFER_%' THEN UPPER(old.action)
        ELSE CONCAT('TRANSFER_', UPPER(old.action))
    END as action_type,
    old.performed_by as user_id,
    old.performed_by_name as user_name,
    CASE 
        WHEN old.details IS NULL OR old.details = '' THEN NULL
        WHEN JSON_VALID(old.details) THEN CAST(old.details AS JSON)
        ELSE JSON_OBJECT('message', old.details)
    END as details,
    old.created_at
FROM ramyum_db.stock_transfer_audit old
WHERE @old_audit_exists > 0 AND @old_structure > 0
ORDER BY old.created_at, FIELD(UPPER(old.action), 'CREATED', 'SUBMITTED', 'APPROVED', 'REJECTED', 'COMPLETED');

-- =====================================================================
-- STEP 5: INSERT DEFAULT DATA IF NO EXISTING DATA
-- =====================================================================

-- Add default users if none exist
INSERT IGNORE INTO users (id, name, email, username, password_hash, role, verified) VALUES
('u1', 'Admin User', 'admin@ramyum.com', 'admin', '$2b$10$jORdZ.f9BV.WT2nFKNek5ekLliBntqCv0DaSh1RXLPoD2bffa3Hb.', 'admin', 1),
('u2', 'Staff User', 'staff@ramyum.com', 'staff', '$2b$10$U//kJkgHuyUwK24TLR9SWuhfowJHAJaq9SouO3yZWV8GekND2XbsS', 'staff', 1),
('u3', 'Manager User', 'manager@ramyum.com', 'manager', '$2b$10$U//kJkgHuyUwK24TLR9SWuhfowJHAJaq9SouO3yZWV8GekND2XbsS', 'manager', 1);

-- Add default suppliers if none exist
INSERT IGNORE INTO suppliers (id, data) VALUES
('s1', JSON_OBJECT(
    'id', 's1', 'company', 'Seoul Food Distribution', 'contactPerson', 'Minji Kim',
    'email', 'minji@seoulfood.co.kr', 'phone', '+82 10 1234 5678',
    'address', '456 Hongdae-ro, Mapo-gu, Seoul, South Korea', 'taxId', 'KR-123-45-67890',
    'paymentTerms', 'Net 30', 'notes', 'Primary supplier for Korean instant noodles and snacks.',
    'productCount', 8, 'status', 'Active', 'rating', 4.8, 'deliveryDays', 7, 'minimumOrder', 25000
)),
('s2', JSON_OBJECT(
    'id', 's2', 'company', 'K-Food Wholesale Trading', 'contactPerson', 'Park Jin-woo',
    'email', 'jinwoo@kfoodtrading.kr', 'phone', '+82 2 9876 5432',
    'address', '789 Gangnam-daero, Gangnam-gu, Seoul, South Korea', 'taxId', 'KR-987-65-43210',
    'paymentTerms', 'Net 15', 'notes', 'Premium Korean food products distributor.',
    'productCount', 12, 'status', 'Active', 'rating', 4.9, 'deliveryDays', 5, 'minimumOrder', 50000
));

-- Add default locations if none exist
INSERT IGNORE INTO locations (id, data) VALUES
('loc1', JSON_OBJECT(
    'id', 'loc1', 'name', 'Main Warehouse', 'code', 'WH', 'type', 'Warehouse',
    'address', '123 Industrial Avenue, Manila', 'manager', 'Juan dela Cruz',
    'phone', '+63 2 8555 0001', 'email', 'warehouse@ramyum.com', 'status', 'Active',
    'capacity', 2000, 'description', 'Primary storage and distribution center'
)),
('loc2', JSON_OBJECT(
    'id', 'loc2', 'name', 'Branch 1 - Makati', 'code', 'MKT', 'type', 'Branch',
    'address', '456 Ayala Avenue, Makati City', 'manager', 'Maria Santos',
    'phone', '+63 2 8555 0002', 'email', 'makati@ramyum.com', 'status', 'Active',
    'capacity', 500, 'description', 'Makati retail branch with premium location'
)),
('loc3', JSON_OBJECT(
    'id', 'loc3', 'name', 'Branch 2 - Quezon City', 'code', 'QC', 'type', 'Branch',
    'address', '789 Commonwealth Avenue, Quezon City', 'manager', 'Ana Rodriguez',
    'phone', '+63 2 8555 0003', 'email', 'qc@ramyum.com', 'status', 'Active',
    'capacity', 400, 'description', 'Quezon City retail branch with cold storage'
)),
('loc4', JSON_OBJECT(
    'id', 'loc4', 'name', 'Storage Area - BGC', 'code', 'BGC', 'type', 'Storage',
    'address', '321 Bonifacio Global City, Taguig', 'manager', 'Roberto Kim',
    'phone', '+63 2 8555 0004', 'email', 'bgc@ramyum.com', 'status', 'Active',
    'capacity', 1500, 'description', 'Secondary storage facility for overflow inventory'
));

-- =====================================================================
-- STEP 6: VALIDATE MIGRATION
-- =====================================================================

SELECT '==================== MIGRATION COMPLETE ====================' as status;

-- Show record counts from new database
SELECT 'users' as table_name, COUNT(*) as record_count FROM users
UNION ALL
SELECT 'suppliers', COUNT(*) FROM suppliers
UNION ALL
SELECT 'products', COUNT(*) FROM products
UNION ALL
SELECT 'locations', COUNT(*) FROM locations
UNION ALL
SELECT 'inventory_locations', COUNT(*) FROM inventory_locations
UNION ALL
SELECT 'purchase_orders', COUNT(*) FROM purchase_orders
UNION ALL
SELECT 'receivings', COUNT(*) FROM receivings
UNION ALL
SELECT 'stock_transfers', COUNT(*) FROM stock_transfers
UNION ALL
SELECT 'stock_transfer_audit', COUNT(*) FROM stock_transfer_audit
UNION ALL
SELECT 'inventory_movements', COUNT(*) FROM inventory_movements
UNION ALL
SELECT 'stock_adjustments', COUNT(*) FROM stock_adjustments
UNION ALL
SELECT 'inventory_predictions', COUNT(*) FROM inventory_predictions;

-- Verify audit table structure is correct
SHOW COLUMNS FROM stock_transfer_audit;

-- Check for any data integrity issues
SELECT 'Checking foreign key integrity...' as check_status;
SELECT 'Users with OTP codes:' as info, COUNT(DISTINCT user_id) as count FROM otp_codes;
SELECT 'Valid user references in OTP:' as info, COUNT(*) as count 
FROM otp_codes o JOIN users u ON o.user_id = u.id;

-- Show sample data to verify migration
SELECT 'Sample Users:' as data_type;
SELECT id, name, email, role FROM users LIMIT 3;

SELECT 'Sample Products:' as data_type;
SELECT id, JSON_UNQUOTE(JSON_EXTRACT(data, '$.name')) as name,
       JSON_UNQUOTE(JSON_EXTRACT(data, '$.category')) as category
FROM products LIMIT 5;

SELECT 'Sample Stock Transfer Audit:' as data_type;
SELECT transfer_id, action_type, user_name, created_at 
FROM stock_transfer_audit ORDER BY created_at DESC LIMIT 5;

SELECT '==================== MIGRATION SUMMARY ====================' as summary;
SELECT 'New centralized database: ram_yum_inventory' as info;
SELECT 'Total tables created: 14' as info;
SELECT 'Data migrated from: ramyum_db (if existed)' as info;
SELECT 'Fixed stock_transfer_audit structure' as info;
SELECT 'Ready for application configuration update' as info;