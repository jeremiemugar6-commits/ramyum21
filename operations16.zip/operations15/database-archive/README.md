# Database Archive

## Purpose
This directory contains **archived and obsolete** database files that are no longer used by the RAM-YUM system. These files are preserved for historical reference only.

## ⚠️ Important Notice
**The application does NOT load, include, import, or connect to any files in this directory.**

All files here are:
- Old migration scripts from multi-database architecture
- Legacy schema definitions
- Obsolete demo data files
- Historical SQL snapshots

## Current System Architecture
The live system uses **ONE centralized database**: `u479471141_ramyum_db2`

See `database/README.md` for active database documentation.

## Archive Contents

### Legacy Schema Files
- `schema.sql` - Old base schema
- `stock-transfer-schema.sql` - Old separate stock transfer schema
- `FIX-DATABASE.sql` - Legacy fixes (now incorporated)

### Old Migration Scripts
- `migrate-to-centralized.sql` - Migration from multi-DB to single DB (completed)
- `migrate-to-centralized-db.php` - Migration tool (obsolete)
- `panel-revisions-migration.sql` - Old UI changes
- `pod-workflow-migration.sql` - Old POD migration

### Demo & Test Data
- `capstone-demo-scenario.sql` - Old demo data
- `seed-demo-data.sql` - Legacy seed data
- `stock-transfer-demo-data.sql` - Old transfer demos
- Various other demo/test SQL files

### Complete Dumps
- `COMPLETE-STOCK-TRANSFER-DATABASE.sql` - Old full database
- `SIMPLE-STOCK-TRANSFER-DATABASE.sql` - Old simplified version

## Do Not Use
❌ Do not import these files into the production database  
❌ Do not reference these files in application code  
❌ Do not restore from these files (use `database/u479471141_ramyum_db2.sql` instead)

## Retention
These files are retained for:
- Historical reference
- Academic documentation
- Development history
- Compliance requirements

---

**Archive Created:** 2026-10-03  
**Reason:** Database consolidation to single centralized architecture
