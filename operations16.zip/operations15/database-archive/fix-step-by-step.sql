-- ==========================================
-- STEP-BY-STEP CRITICAL FIXES
-- Copy and paste each section one at a time
-- ==========================================

-- ==========================================
-- STEP 1: Check for duplicate SKUs (should return 0 rows)
-- ==========================================
SELECT 
    JSON_UNQUOTE(JSON_EXTRACT(data, '$.sku')) as sku,
    COUNT(*) as count
FROM products
WHERE JSON_UNQUOTE(JSON_EXTRACT(data, '$.sku')) IS NOT NULL
GROUP BY JSON_UNQUOTE(JSON_EXTRACT(data, '$.sku'))
HAVING COUNT(*) > 1;

-- ==========================================
-- STEP 2: Add SKU normalized column to products
-- ==========================================
ALTER TABLE products 
ADD COLUMN sku_normalized VARCHAR(100) 
GENERATED ALWAYS AS (JSON_UNQUOTE(JSON_EXTRACT(data, '$.sku'))) STORED;

-- ==========================================
-- STEP 3: Add unique constraint on SKU
-- ==========================================
ALTER TABLE products 
ADD UNIQUE KEY unique_sku (sku_normalized);

-- ==========================================
-- STEP 4: Add SKU index for performance
-- ==========================================
CREATE INDEX idx_product_sku ON products(sku_normalized);

-- ==========================================
-- STEP 5: Add quantity columns to inventory_locations
-- ==========================================
ALTER TABLE inventory_locations
ADD COLUMN quantity_value DECIMAL(10,2)
GENERATED ALWAYS AS (CAST(JSON_UNQUOTE(JSON_EXTRACT(data, '$.quantity')) AS DECIMAL(10,2))) STORED;

ALTER TABLE inventory_locations
ADD COLUMN available_quantity_value DECIMAL(10,2)
GENERATED ALWAYS AS (CAST(JSON_UNQUOTE(JSON_EXTRACT(data, '$.availableQuantity')) AS DECIMAL(10,2))) STORED;

-- ==========================================
-- STEP 6: Add CHECK constraints for positive quantities
-- ==========================================
ALTER TABLE inventory_locations
ADD CONSTRAINT chk_positive_quantity CHECK (quantity_value >= 0);

ALTER TABLE inventory_locations
ADD CONSTRAINT chk_positive_available_quantity CHECK (available_quantity_value >= 0);

-- ==========================================
-- VERIFICATION: Check if everything is applied
-- ==========================================

-- Verify SKU column exists
SHOW COLUMNS FROM products LIKE 'sku_normalized';

-- Verify unique constraint exists
SHOW INDEX FROM products WHERE Key_name = 'unique_sku';

-- Verify inventory constraints exist  
SHOW COLUMNS FROM inventory_locations LIKE '%quantity_value%';

-- Show sample data
SELECT 
    id,
    sku_normalized,
    JSON_UNQUOTE(JSON_EXTRACT(data, '$.name')) as name
FROM products
LIMIT 5;

-- ==========================================
-- DONE! All fixes applied successfully
-- ==========================================
