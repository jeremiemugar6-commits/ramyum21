-- =====================================================================
-- Comprehensive Stock Transfer Demo Data for System Demonstration
-- Creates realistic scenarios for workflow demonstration
-- =====================================================================

USE ramyum_db;

-- Clean up existing demo data
DELETE FROM stock_transfer_audit WHERE transfer_id LIKE 'ST-2026-00%';
DELETE FROM stock_transfers WHERE id LIKE 'st_demo_%' OR id LIKE 'st_comp_%';
DELETE FROM inventory_movements WHERE id LIKE 'mov_st_demo_%' OR id LIKE 'mov_st_comp_%';

-- =====================================================================
-- SCENARIO 1: Urgent Restock (Pending Approval)
-- High-priority transfer from main warehouse to busy branch
-- =====================================================================
INSERT INTO stock_transfers (id, data) VALUES
('st_comp_urgent_001', JSON_OBJECT(
    'id', 'st_comp_urgent_001',
    'transferNumber', 'ST-2026-0101',
    'transferDate', DATE_FORMAT(NOW(), '%Y-%m-%d'),
    'sourceLocationId', 'loc1',
    'sourceLocationName', 'Main Warehouse',
    'destinationLocationId', 'loc2',
    'destinationLocationName', 'Branch 1 - Makati',
    'requestedBy', 'u2',
    'requestedByName', 'Staff User',
    'status', 'Pending Approval',
    'priority', 'High',
    'remarks', 'URGENT: Branch 1 nearly out of stock on bestsellers. Weekend rush expected. Need immediate approval and transfer.',
    'items', JSON_ARRAY(
        JSON_OBJECT(
            'productId', 'p1',
            'productName', 'Samyang Buldak Original',
            'sku', 'SB-001',
            'quantity', 50,
            'unit', 'pcs',
            'sourceStock', 150,
            'destinationStock', 8,
            'minStock', 20,
            'notes', 'Critical - Only 8 units left at branch'
        ),
        JSON_OBJECT(
            'productId', 'p2',
            'productName', 'Shin Ramyun',
            'sku', 'SR-002',
            'quantity', 40,
            'unit', 'pcs',
            'sourceStock', 200,
            'destinationStock', 12,
            'minStock', 25,
            'notes', 'Below minimum stock level'
        ),
        JSON_OBJECT(
            'productId', 'p5',
            'productName', 'Chapagetti',
            'sku', 'CP-005',
            'quantity', 25,
            'unit', 'pcs',
            'sourceStock', 100,
            'destinationStock', 5,
            'minStock', 15,
            'notes', 'Popular item - high demand'
        )
    ),
    'totalItems', 115,
    'estimatedValue', 2875.00,
    'createdAt', DATE_FORMAT(DATE_SUB(NOW(), INTERVAL 2 HOUR), '%Y-%m-%dT%H:%i:%s.000Z'),
    'submittedAt', DATE_FORMAT(DATE_SUB(NOW(), INTERVAL 2 HOUR), '%Y-%m-%dT%H:%i:%s.000Z')
));

-- =====================================================================
-- SCENARIO 2: New Product Launch Distribution (Pending)
-- Distribute new products from warehouse to all branches
-- =====================================================================
INSERT INTO stock_transfers (id, data) VALUES
('st_comp_launch_001', JSON_OBJECT(
    'id', 'st_comp_launch_001',
    'transferNumber', 'ST-2026-0102',
    'transferDate', DATE_FORMAT(NOW(), '%Y-%m-%d'),
    'sourceLocationId', 'loc1',
    'sourceLocationName', 'Main Warehouse',
    'destinationLocationId', 'loc3',
    'destinationLocationName', 'Branch 2 - Quezon City',
    'requestedBy', 'u3',
    'requestedByName', 'Manager User',
    'status', 'Pending Approval',
    'priority', 'Medium',
    'remarks', 'New product launch - Korean Fried Chicken Ramen. Initial distribution to QC branch for market testing.',
    'items', JSON_ARRAY(
        JSON_OBJECT(
            'productId', 'p15',
            'productName', 'Korean Fried Chicken Ramen',
            'sku', 'KFC-015',
            'quantity', 30,
            'unit', 'pcs',
            'sourceStock', 200,
            'destinationStock', 0,
            'minStock', 10,
            'notes', 'New product - market test'
        ),
        JSON_OBJECT(
            'productId', 'p16',
            'productName', 'Cheese Tteokbokki Ramen',
            'sku', 'CTR-016',
            'quantity', 20,
            'unit', 'pcs',
            'sourceStock', 150,
            'destinationStock', 0,
            'minStock', 10,
            'notes', 'Companion product launch'
        )
    ),
    'totalItems', 50,
    'estimatedValue', 1500.00,
    'createdAt', DATE_FORMAT(DATE_SUB(NOW(), INTERVAL 4 HOUR), '%Y-%m-%dT%H:%i:%s.000Z'),
    'submittedAt', DATE_FORMAT(DATE_SUB(NOW(), INTERVAL 4 HOUR), '%Y-%m-%dT%H:%i:%s.000Z')
));

-- =====================================================================
-- SCENARIO 3: Approved and Completed Transfer
-- Successfully completed transfer with full audit trail
-- =====================================================================
INSERT INTO stock_transfers (id, data) VALUES
('st_comp_completed_001', JSON_OBJECT(
    'id', 'st_comp_completed_001',
    'transferNumber', 'ST-2026-0103',
    'transferDate', DATE_FORMAT(DATE_SUB(NOW(), INTERVAL 1 DAY), '%Y-%m-%d'),
    'sourceLocationId', 'loc1',
    'sourceLocationName', 'Main Warehouse',
    'destinationLocationId', 'loc4',
    'destinationLocationName', 'Storage Area - BGC',
    'requestedBy', 'u2',
    'requestedByName', 'Staff User',
    'status', 'Approved',
    'priority', 'Low',
    'remarks', 'Seasonal inventory redistribution. Moving winter stock to climate-controlled storage.',
    'items', JSON_ARRAY(
        JSON_OBJECT(
            'productId', 'p3',
            'productName', 'Ottogi Jin Ramen',
            'sku', 'OJ-003',
            'quantity', 100,
            'unit', 'pcs',
            'sourceStock', 250,
            'destinationStock', 50,
            'transferredQuantity', 100,
            'notes', 'Bulk transfer completed'
        ),
        JSON_OBJECT(
            'productId', 'p4',
            'productName', 'Nong Shim Cup Noodles',
            'sku', 'NS-004', 
            'quantity', 75,
            'unit', 'pcs',
            'sourceStock', 180,
            'destinationStock', 25,
            'transferredQuantity', 75,
            'notes', 'Storage optimization'
        )
    ),
    'totalItems', 175,
    'estimatedValue', 3500.00,
    'approvedBy', 'u1',
    'approvedByName', 'Admin User',
    'approvedAt', DATE_FORMAT(DATE_SUB(NOW(), INTERVAL 6 HOUR), '%Y-%m-%dT%H:%i:%s.000Z'),
    'approvalRemarks', 'Approved for inventory optimization. BGC facility has adequate climate control.',
    'completedAt', DATE_FORMAT(DATE_SUB(NOW(), INTERVAL 4 HOUR), '%Y-%m-%dT%H:%i:%s.000Z'),
    'completedBy', 'u2',
    'completedByName', 'Staff User',
    'createdAt', DATE_FORMAT(DATE_SUB(NOW(), INTERVAL 1 DAY), '%Y-%m-%dT%H:%i:%s.000Z'),
    'submittedAt', DATE_FORMAT(DATE_SUB(NOW(), INTERVAL 22 HOUR), '%Y-%m-%dT%H:%i:%s.000Z')
));

-- =====================================================================
-- SCENARIO 4: Rejected Transfer with Detailed Reason
-- Transfer rejected due to business logic constraints
-- =====================================================================
INSERT INTO stock_transfers (id, data) VALUES
('st_comp_rejected_001', JSON_OBJECT(
    'id', 'st_comp_rejected_001',
    'transferNumber', 'ST-2026-0104',
    'transferDate', DATE_FORMAT(DATE_SUB(NOW(), INTERVAL 2 DAY), '%Y-%m-%d'),
    'sourceLocationId', 'loc2',
    'sourceLocationName', 'Branch 1 - Makati',
    'destinationLocationId', 'loc3',
    'destinationLocationName', 'Branch 2 - Quezon City',
    'requestedBy', 'u2',
    'requestedByName', 'Staff User',
    'status', 'Rejected',
    'priority', 'Medium',
    'remarks', 'Customer special order requires 60 units of premium ramen. Requesting transfer from Makati branch.',
    'items', JSON_ARRAY(
        JSON_OBJECT(
            'productId', 'p1',
            'productName', 'Samyang Buldak Original',
            'sku', 'SB-001',
            'quantity', 60,
            'unit', 'pcs',
            'sourceStock', 45,
            'destinationStock', 30,
            'notes', 'Special customer order - bulk purchase'
        )
    ),
    'totalItems', 60,
    'estimatedValue', 1800.00,
    'rejectedBy', 'u3',
    'rejectedByName', 'Manager User',
    'rejectedAt', DATE_FORMAT(DATE_SUB(NOW(), INTERVAL 1 DAY), '%Y-%m-%dT%H:%i:%s.000Z'),
    'rejectionReason', 'Insufficient inventory at source. Branch 1 has only 45 units but requires minimum 20 units for daily operations. Recommend ordering from Main Warehouse instead.',
    'alternativeAction', 'Transfer from Main Warehouse (150 units available) or reduce order quantity to 25 units.',
    'createdAt', DATE_FORMAT(DATE_SUB(NOW(), INTERVAL 2 DAY), '%Y-%m-%dT%H:%i:%s.000Z'),
    'submittedAt', DATE_FORMAT(DATE_SUB(NOW(), INTERVAL 46 HOUR), '%Y-%m-%dT%H:%i:%s.000Z')
));

-- =====================================================================
-- SCENARIO 5: Emergency Transfer (Approved quickly)
-- Fast-tracked approval for emergency situation
-- =====================================================================
INSERT INTO stock_transfers (id, data) VALUES
('st_comp_emergency_001', JSON_OBJECT(
    'id', 'st_comp_emergency_001',
    'transferNumber', 'ST-2026-0105',
    'transferDate', DATE_FORMAT(DATE_SUB(NOW(), INTERVAL 3 HOUR), '%Y-%m-%d'),
    'sourceLocationId', 'loc4',
    'sourceLocationName', 'Storage Area - BGC',
    'destinationLocationId', 'loc2',
    'destinationLocationName', 'Branch 1 - Makati',
    'requestedBy', 'u3',
    'requestedByName', 'Manager User',
    'status', 'Approved',
    'priority', 'Critical',
    'remarks', 'EMERGENCY: Main supplier delivery delayed. Branch 1 experiencing stockout during peak hours. Emergency transfer from BGC storage.',
    'items', JSON_ARRAY(
        JSON_OBJECT(
            'productId', 'p3',
            'productName', 'Ottogi Jin Ramen',
            'sku', 'OJ-003',
            'quantity', 40,
            'unit', 'pcs',
            'sourceStock', 150,
            'destinationStock', 0,
            'notes', 'Emergency stockout coverage'
        ),
        JSON_OBJECT(
            'productId', 'p4',
            'productName', 'Nong Shim Cup Noodles',
            'sku', 'NS-004',
            'quantity', 30,
            'unit', 'pcs',
            'sourceStock', 100,
            'destinationStock', 0,
            'notes', 'Backup inventory activation'
        )
    ),
    'totalItems', 70,
    'estimatedValue', 1400.00,
    'approvedBy', 'u1',
    'approvedByName', 'Admin User',
    'approvedAt', DATE_FORMAT(DATE_SUB(NOW(), INTERVAL 2 HOUR), '%Y-%m-%dT%H:%i:%s.000Z'),
    'approvalRemarks', 'EMERGENCY APPROVED: Immediate transfer authorized. Courier dispatch arranged.',
    'fastTrack', true,
    'createdAt', DATE_FORMAT(DATE_SUB(NOW(), INTERVAL 3 HOUR), '%Y-%m-%dT%H:%i:%s.000Z'),
    'submittedAt', DATE_FORMAT(DATE_SUB(NOW(), INTERVAL 3 HOUR), '%Y-%m-%dT%H:%i:%s.000Z')
));

-- =====================================================================
-- Add corresponding inventory movements for completed transfers
-- =====================================================================

-- Movements for completed transfer (st_comp_completed_001)
INSERT INTO inventory_movements (id, data) VALUES
('mov_st_comp_completed_001_out_p3', JSON_OBJECT(
    'id', 'mov_st_comp_completed_001_out_p3',
    'productId', 'p3',
    'productName', 'Ottogi Jin Ramen',
    'locationId', 'loc1',
    'locationName', 'Main Warehouse',
    'movementType', 'Stock Out',
    'quantity', -100,
    'previousStock', 250,
    'newStock', 150,
    'referenceType', 'STOCK_TRANSFER',
    'referenceId', 'ST-2026-0103',
    'performedBy', 'u1',
    'performedByName', 'Admin User',
    'reason', 'Stock Transfer - Out',
    'notes', 'Bulk transfer to BGC storage facility',
    'createdAt', DATE_FORMAT(DATE_SUB(NOW(), INTERVAL 4 HOUR), '%Y-%m-%dT%H:%i:%s.000Z')
)),
('mov_st_comp_completed_001_in_p3', JSON_OBJECT(
    'id', 'mov_st_comp_completed_001_in_p3',
    'productId', 'p3',
    'productName', 'Ottogi Jin Ramen',
    'locationId', 'loc4',
    'locationName', 'Storage Area - BGC',
    'movementType', 'Stock In',
    'quantity', 100,
    'previousStock', 50,
    'newStock', 150,
    'referenceType', 'STOCK_TRANSFER',
    'referenceId', 'ST-2026-0103',
    'performedBy', 'u1',
    'performedByName', 'Admin User',
    'reason', 'Stock Transfer - In',
    'notes', 'Received from Main Warehouse',
    'createdAt', DATE_FORMAT(DATE_SUB(NOW(), INTERVAL 4 HOUR), '%Y-%m-%dT%H:%i:%s.000Z')
)),
('mov_st_comp_completed_001_out_p4', JSON_OBJECT(
    'id', 'mov_st_comp_completed_001_out_p4',
    'productId', 'p4',
    'productName', 'Nong Shim Cup Noodles',
    'locationId', 'loc1',
    'locationName', 'Main Warehouse',
    'movementType', 'Stock Out',
    'quantity', -75,
    'previousStock', 180,
    'newStock', 105,
    'referenceType', 'STOCK_TRANSFER',
    'referenceId', 'ST-2026-0103',
    'performedBy', 'u1',
    'performedByName', 'Admin User',
    'reason', 'Stock Transfer - Out',
    'notes', 'Storage optimization transfer',
    'createdAt', DATE_FORMAT(DATE_SUB(NOW(), INTERVAL 4 HOUR), '%Y-%m-%dT%H:%i:%s.000Z')
)),
('mov_st_comp_completed_001_in_p4', JSON_OBJECT(
    'id', 'mov_st_comp_completed_001_in_p4',
    'productId', 'p4',
    'productName', 'Nong Shim Cup Noodles',
    'locationId', 'loc4',
    'locationName', 'Storage Area - BGC',
    'movementType', 'Stock In',
    'quantity', 75,
    'previousStock', 25,
    'newStock', 100,
    'referenceType', 'STOCK_TRANSFER',
    'referenceId', 'ST-2026-0103',
    'performedBy', 'u1',
    'performedByName', 'Admin User',
    'reason', 'Stock Transfer - In',
    'notes', 'Received from Main Warehouse',
    'createdAt', DATE_FORMAT(DATE_SUB(NOW(), INTERVAL 4 HOUR), '%Y-%m-%dT%H:%i:%s.000Z')
));

-- =====================================================================
-- Add audit trail entries for all transfers
-- =====================================================================
INSERT INTO stock_transfer_audit (id, transfer_id, action, performed_by, performed_by_name, details, created_at) VALUES
-- Urgent restock audit
('audit_001', 'ST-2026-0101', 'CREATED', 'u2', 'Staff User', 'Transfer created for urgent Branch 1 restock', DATE_FORMAT(DATE_SUB(NOW(), INTERVAL 2 HOUR), '%Y-%m-%dT%H:%i:%s.000Z')),
('audit_002', 'ST-2026-0101', 'SUBMITTED', 'u2', 'Staff User', 'Transfer submitted for manager approval', DATE_FORMAT(DATE_SUB(NOW(), INTERVAL 2 HOUR), '%Y-%m-%dT%H:%i:%s.000Z')),

-- New product launch audit
('audit_003', 'ST-2026-0102', 'CREATED', 'u3', 'Manager User', 'Transfer created for new product distribution', DATE_FORMAT(DATE_SUB(NOW(), INTERVAL 4 HOUR), '%Y-%m-%dT%H:%i:%s.000Z')),
('audit_004', 'ST-2026-0102', 'SUBMITTED', 'u3', 'Manager User', 'Transfer submitted for admin approval', DATE_FORMAT(DATE_SUB(NOW(), INTERVAL 4 HOUR), '%Y-%m-%dT%H:%i:%s.000Z')),

-- Completed transfer audit
('audit_005', 'ST-2026-0103', 'CREATED', 'u2', 'Staff User', 'Transfer created for inventory optimization', DATE_FORMAT(DATE_SUB(NOW(), INTERVAL 1 DAY), '%Y-%m-%dT%H:%i:%s.000Z')),
('audit_006', 'ST-2026-0103', 'SUBMITTED', 'u2', 'Staff User', 'Transfer submitted for approval', DATE_FORMAT(DATE_SUB(NOW(), INTERVAL 22 HOUR), '%Y-%m-%dT%H:%i:%s.000Z')),
('audit_007', 'ST-2026-0103', 'APPROVED', 'u1', 'Admin User', 'Transfer approved for execution', DATE_FORMAT(DATE_SUB(NOW(), INTERVAL 6 HOUR), '%Y-%m-%dT%H:%i:%s.000Z')),
('audit_008', 'ST-2026-0103', 'COMPLETED', 'u2', 'Staff User', 'Inventory transfer completed successfully', DATE_FORMAT(DATE_SUB(NOW(), INTERVAL 4 HOUR), '%Y-%m-%dT%H:%i:%s.000Z')),

-- Rejected transfer audit
('audit_009', 'ST-2026-0104', 'CREATED', 'u2', 'Staff User', 'Transfer created for special customer order', DATE_FORMAT(DATE_SUB(NOW(), INTERVAL 2 DAY), '%Y-%m-%dT%H:%i:%s.000Z')),
('audit_010', 'ST-2026-0104', 'SUBMITTED', 'u2', 'Staff User', 'Transfer submitted for manager review', DATE_FORMAT(DATE_SUB(NOW(), INTERVAL 46 HOUR), '%Y-%m-%dT%H:%i:%s.000Z')),
('audit_011', 'ST-2026-0104', 'REJECTED', 'u3', 'Manager User', 'Transfer rejected due to insufficient source inventory', DATE_FORMAT(DATE_SUB(NOW(), INTERVAL 1 DAY), '%Y-%m-%dT%H:%i:%s.000Z')),

-- Emergency transfer audit
('audit_012', 'ST-2026-0105', 'CREATED', 'u3', 'Manager User', 'Emergency transfer created for stockout situation', DATE_FORMAT(DATE_SUB(NOW(), INTERVAL 3 HOUR), '%Y-%m-%dT%H:%i:%s.000Z')),
('audit_013', 'ST-2026-0105', 'SUBMITTED', 'u3', 'Manager User', 'Emergency transfer submitted for immediate approval', DATE_FORMAT(DATE_SUB(NOW(), INTERVAL 3 HOUR), '%Y-%m-%dT%H:%i:%s.000Z')),
('audit_014', 'ST-2026-0105', 'APPROVED', 'u1', 'Admin User', 'Emergency transfer approved with fast-track priority', DATE_FORMAT(DATE_SUB(NOW(), INTERVAL 2 HOUR), '%Y-%m-%dT%H:%i:%s.000Z'));

-- =====================================================================
-- Verification and Summary Queries
-- =====================================================================

-- Summary of created demo transfers
SELECT '=== COMPREHENSIVE DEMO DATA SUMMARY ===' as info;

SELECT 
    'Total Transfers Created:' as metric,
    COUNT(*) as count 
FROM stock_transfers 
WHERE id LIKE 'st_comp_%';

SELECT 
    'Transfer Status Distribution:' as metric,
    JSON_UNQUOTE(JSON_EXTRACT(data, '$.status')) as status,
    COUNT(*) as count
FROM stock_transfers 
WHERE id LIKE 'st_comp_%'
GROUP BY JSON_UNQUOTE(JSON_EXTRACT(data, '$.status'));

SELECT 
    'Priority Distribution:' as metric,
    COALESCE(JSON_UNQUOTE(JSON_EXTRACT(data, '$.priority')), 'Not Set') as priority,
    COUNT(*) as count
FROM stock_transfers 
WHERE id LIKE 'st_comp_%'
GROUP BY COALESCE(JSON_UNQUOTE(JSON_EXTRACT(data, '$.priority')), 'Not Set');

SELECT 
    'Location Activity:' as metric,
    CONCAT(
        JSON_UNQUOTE(JSON_EXTRACT(data, '$.sourceLocationName')), 
        ' → ', 
        JSON_UNQUOTE(JSON_EXTRACT(data, '$.destinationLocationName'))
    ) as route,
    COUNT(*) as transfers
FROM stock_transfers 
WHERE id LIKE 'st_comp_%'
GROUP BY route;

SELECT 
    'Inventory Movements Created:' as metric,
    COUNT(*) as count 
FROM inventory_movements 
WHERE id LIKE 'mov_st_comp_%';

SELECT 
    'Audit Trail Entries:' as metric,
    COUNT(*) as count 
FROM stock_transfer_audit 
WHERE transfer_id LIKE 'ST-2026-01%';

SELECT '=== DEMO DATA READY FOR TESTING ===' as status;