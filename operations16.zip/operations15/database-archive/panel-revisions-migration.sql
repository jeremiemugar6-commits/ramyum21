-- ============================================================
-- RAM-YUM PANEL REVISIONS MIGRATION
-- ============================================================
-- This migration adds the required fields for the 12 panel revisions:
-- 1. Product unit field
-- 2. Costing price and SRP (replacing generic 'price')
-- 3. Minimum and maximum stock levels
-- 4. Damage evidence table for receiving
-- 5. POD (Proof of Delivery) fields for stock transfers
-- ============================================================

-- ============================================================
-- TABLE: damage_evidence
-- ============================================================
-- Stores picture evidence of damaged products found during receiving
-- Linked to purchase orders and receiving records
-- ============================================================

CREATE TABLE IF NOT EXISTS `damage_evidence` (
  `id` varchar(40) NOT NULL PRIMARY KEY,
  `receiving_id` varchar(40) NOT NULL,
  `po_id` varchar(40) NOT NULL,
  `po_number` varchar(50) NOT NULL,
  `product_id` varchar(40) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `ordered_quantity` decimal(12,2) NOT NULL DEFAULT 0,
  `received_quantity` decimal(12,2) NOT NULL DEFAULT 0,
  `damaged_quantity` decimal(12,2) NOT NULL DEFAULT 0,
  `damage_description` text DEFAULT NULL,
  `evidence_image_path` varchar(500) DEFAULT NULL,
  `recorded_by` varchar(100) NOT NULL,
  `recorded_at` datetime NOT NULL DEFAULT current_timestamp(),
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  KEY `idx_receiving_id` (`receiving_id`),
  KEY `idx_po_id` (`po_id`),
  KEY `idx_product_id` (`product_id`),
  KEY `idx_recorded_at` (`recorded_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- TABLE: proof_of_delivery
-- ============================================================
-- Stores proof of delivery records for stock transfers
-- Links QR code scans to transfer confirmations
-- ============================================================

CREATE TABLE IF NOT EXISTS `proof_of_delivery` (
  `id` varchar(40) NOT NULL PRIMARY KEY,
  `transfer_id` varchar(40) NOT NULL,
  `transfer_number` varchar(50) NOT NULL,
  `qr_token` varchar(100) NOT NULL UNIQUE,
  `scanned_at` datetime DEFAULT NULL,
  `scanned_by` varchar(100) DEFAULT NULL,
  `received_by` varchar(100) DEFAULT NULL,
  `received_at` datetime DEFAULT NULL,
  `confirmation_notes` text DEFAULT NULL,
  `signature_data` text DEFAULT NULL,
  `status` varchar(30) NOT NULL DEFAULT 'Pending',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  KEY `idx_transfer_id` (`transfer_id`),
  KEY `idx_qr_token` (`qr_token`),
  KEY `idx_status` (`status`),
  KEY `idx_scanned_at` (`scanned_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- NOTE: Products table uses JSON storage
-- ============================================================
-- The products table stores data in a JSON column.
-- We cannot use ALTER TABLE to add JSON fields.
-- Instead, we need to update the JSON data in each product record.
-- This will be handled by a PHP migration script.
-- 
-- New fields to add to product JSON:
-- - unit: Product unit (Piece, Pack, Bundle, Box)
-- - costingPrice: Cost to acquire the product
-- - srp: Suggested Retail Price
-- - minimumStock: Minimum inventory level
-- - maximumStock: Maximum inventory level
-- 
-- The existing 'price' field will be migrated to 'costingPrice'
-- ============================================================

-- ============================================================
-- Create uploads directory structure (for reference only)
-- ============================================================
-- Directory structure to be created via PHP/filesystem:
-- /uploads/
--   /damage-evidence/
--   /product-images/
-- ============================================================

-- ============================================================
-- VERIFICATION QUERIES
-- ============================================================

-- Check if damage_evidence table exists
-- SELECT COUNT(*) as damage_evidence_exists FROM information_schema.tables 
-- WHERE table_schema = DATABASE() AND table_name = 'damage_evidence';

-- Check if proof_of_delivery table exists
-- SELECT COUNT(*) as pod_exists FROM information_schema.tables 
-- WHERE table_schema = DATABASE() AND table_name = 'proof_of_delivery';

-- ============================================================
-- MIGRATION COMPLETE
-- ============================================================
