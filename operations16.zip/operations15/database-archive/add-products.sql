-- =====================================================================
-- Add New Products to RAMYUM Database
-- This script adds 33 new Korean/Asian products to the inventory
-- =====================================================================

USE ramyum_db;

-- Insert all new products with appropriate categories and expiration dates
INSERT INTO products (id, data) VALUES

-- INSTANT NOODLES (RAM001-RAM012) - 12 months expiration
('RAM001', JSON_OBJECT(
    'id', 'RAM001', 'name', 'Samyang Buldak Cheese', 'sku', 'RAM001', 'category', 'Instant Noodles',
    'price', 55.00, 'stock', 50, 'reorderLevel', 15, 'status', 'In Stock',
    'description', 'Spicy Korean fire noodles with cheese flavor', 'image', '',
    'lastUpdated', DATE_FORMAT(NOW(), '%Y-%m-%dT%H:%i:%s.000Z'), 'supplierId', 's1',
    'expirationDate', DATE_FORMAT(DATE_ADD(NOW(), INTERVAL 12 MONTH), '%Y-%m-%d'),
    'batchNumber', 'BT202608001', 'archived', false
)),

('RAM002', JSON_OBJECT(
    'id', 'RAM002', 'name', 'Samyang Buldak Quattro Cheese', 'sku', 'RAM002', 'category', 'Instant Noodles',
    'price', 75.00, 'stock', 40, 'reorderLevel', 15, 'status', 'In Stock',
    'description', 'Premium spicy Korean noodles with four cheese blend', 'image', '',
    'lastUpdated', DATE_FORMAT(NOW(), '%Y-%m-%dT%H:%i:%s.000Z'), 'supplierId', 's1',
    'expirationDate', DATE_FORMAT(DATE_ADD(NOW(), INTERVAL 12 MONTH), '%Y-%m-%d'),
    'batchNumber', 'BT202608002', 'archived', false
)),

('RAM003', JSON_OBJECT(
    'id', 'RAM003', 'name', 'Samyang Buldak Carbo', 'sku', 'RAM003', 'category', 'Instant Noodles',
    'price', 60.00, 'stock', 45, 'reorderLevel', 15, 'status', 'In Stock',
    'description', 'Spicy Korean noodles with carbonara flavor', 'image', '',
    'lastUpdated', DATE_FORMAT(NOW(), '%Y-%m-%dT%H:%i:%s.000Z'), 'supplierId', 's1',
    'expirationDate', DATE_FORMAT(DATE_ADD(NOW(), INTERVAL 12 MONTH), '%Y-%m-%d'),
    'batchNumber', 'BT202608003', 'archived', false
)),

('RAM004', JSON_OBJECT(
    'id', 'RAM004', 'name', 'Samyang Buldak Cream Carbo', 'sku', 'RAM004', 'category', 'Instant Noodles',
    'price', 65.00, 'stock', 35, 'reorderLevel', 15, 'status', 'In Stock',
    'description', 'Premium spicy noodles with creamy carbonara sauce', 'image', '',
    'lastUpdated', DATE_FORMAT(NOW(), '%Y-%m-%dT%H:%i:%s.000Z'), 'supplierId', 's1',
    'expirationDate', DATE_FORMAT(DATE_ADD(NOW(), INTERVAL 12 MONTH), '%Y-%m-%d'),
    'batchNumber', 'BT202608004', 'archived', false
)),

('RAM005', JSON_OBJECT(
    'id', 'RAM005', 'name', 'Samyang Buldak Rose', 'sku', 'RAM005', 'category', 'Instant Noodles',
    'price', 75.00, 'stock', 30, 'reorderLevel', 15, 'status', 'Low Stock',
    'description', 'Spicy Korean noodles with rose tteokbokki flavor', 'image', '',
    'lastUpdated', DATE_FORMAT(NOW(), '%Y-%m-%dT%H:%i:%s.000Z'), 'supplierId', 's1',
    'expirationDate', DATE_FORMAT(DATE_ADD(NOW(), INTERVAL 12 MONTH), '%Y-%m-%d'),
    'batchNumber', 'BT202608005', 'archived', false
)),

('RAM006', JSON_OBJECT(
    'id', 'RAM006', 'name', 'Samyang Buldak Black Original', 'sku', 'RAM006', 'category', 'Instant Noodles',
    'price', 55.00, 'stock', 55, 'reorderLevel', 15, 'status', 'In Stock',
    'description', 'Original extremely spicy Korean fire noodles', 'image', '',
    'lastUpdated', DATE_FORMAT(NOW(), '%Y-%m-%dT%H:%i:%s.000Z'), 'supplierId', 's1',
    'expirationDate', DATE_FORMAT(DATE_ADD(NOW(), INTERVAL 12 MONTH), '%Y-%m-%d'),
    'batchNumber', 'BT202608006', 'archived', false
)),

('RAM007', JSON_OBJECT(
    'id', 'RAM007', 'name', 'Ottogi Cheese Ramen', 'sku', 'RAM007', 'category', 'Instant Noodles',
    'price', 55.00, 'stock', 40, 'reorderLevel', 15, 'status', 'In Stock',
    'description', 'Korean cheese flavored instant ramen', 'image', '',
    'lastUpdated', DATE_FORMAT(NOW(), '%Y-%m-%dT%H:%i:%s.000Z'), 'supplierId', 's1',
    'expirationDate', DATE_FORMAT(DATE_ADD(NOW(), INTERVAL 12 MONTH), '%Y-%m-%d'),
    'batchNumber', 'BT202608007', 'archived', false
)),

('RAM008', JSON_OBJECT(
    'id', 'RAM008', 'name', 'Ottogi Cheese Stir Fry', 'sku', 'RAM008', 'category', 'Instant Noodles',
    'price', 65.00, 'stock', 30, 'reorderLevel', 15, 'status', 'Low Stock',
    'description', 'Korean cheese stir-fried noodles', 'image', '',
    'lastUpdated', DATE_FORMAT(NOW(), '%Y-%m-%dT%H:%i:%s.000Z'), 'supplierId', 's1',
    'expirationDate', DATE_FORMAT(DATE_ADD(NOW(), INTERVAL 12 MONTH), '%Y-%m-%d'),
    'batchNumber', 'BT202608008', 'archived', false
)),

('RAM009', JSON_OBJECT(
    'id', 'RAM009', 'name', 'Jin Ramen Spicy', 'sku', 'RAM009', 'category', 'Instant Noodles',
    'price', 45.00, 'stock', 60, 'reorderLevel', 20, 'status', 'In Stock',
    'description', 'Classic Korean spicy instant ramen', 'image', '',
    'lastUpdated', DATE_FORMAT(NOW(), '%Y-%m-%dT%H:%i:%s.000Z'), 'supplierId', 's1',
    'expirationDate', DATE_FORMAT(DATE_ADD(NOW(), INTERVAL 12 MONTH), '%Y-%m-%d'),
    'batchNumber', 'BT202608009', 'archived', false
)),

('RAM010', JSON_OBJECT(
    'id', 'RAM010', 'name', 'Jin Ramen Mild', 'sku', 'RAM010', 'category', 'Instant Noodles',
    'price', 45.00, 'stock', 50, 'reorderLevel', 20, 'status', 'In Stock',
    'description', 'Classic Korean mild instant ramen', 'image', '',
    'lastUpdated', DATE_FORMAT(NOW(), '%Y-%m-%dT%H:%i:%s.000Z'), 'supplierId', 's1',
    'expirationDate', DATE_FORMAT(DATE_ADD(NOW(), INTERVAL 12 MONTH), '%Y-%m-%d'),
    'batchNumber', 'BT202608010', 'archived', false
)),

('RAM011', JSON_OBJECT(
    'id', 'RAM011', 'name', 'Shin Ramyun', 'sku', 'RAM011', 'category', 'Instant Noodles',
    'price', 60.00, 'stock', 45, 'reorderLevel', 15, 'status', 'In Stock',
    'description', 'Popular Korean spicy beef flavor ramen', 'image', '',
    'lastUpdated', DATE_FORMAT(NOW(), '%Y-%m-%dT%H:%i:%s.000Z'), 'supplierId', 's1',
    'expirationDate', DATE_FORMAT(DATE_ADD(NOW(), INTERVAL 12 MONTH), '%Y-%m-%d'),
    'batchNumber', 'BT202608011', 'archived', false
)),

('RAM012', JSON_OBJECT(
    'id', 'RAM012', 'name', 'Shin Black', 'sku', 'RAM012', 'category', 'Instant Noodles',
    'price', 95.00, 'stock', 25, 'reorderLevel', 10, 'status', 'Low Stock',
    'description', 'Premium Korean spicy ramen with beef bone broth', 'image', '',
    'lastUpdated', DATE_FORMAT(NOW(), '%Y-%m-%dT%H:%i:%s.000Z'), 'supplierId', 's1',
    'expirationDate', DATE_FORMAT(DATE_ADD(NOW(), INTERVAL 12 MONTH), '%Y-%m-%d'),
    'batchNumber', 'BT202608012', 'archived', false
)),

-- MEAT & PROTEIN (MEAT001-MEAT003) - Shorter expiration dates
('MEAT001', JSON_OBJECT(
    'id', 'MEAT001', 'name', 'Beef Bulgogi (500g)', 'sku', 'MEAT001', 'category', 'Meat & Seafood',
    'price', 320.00, 'stock', 20, 'reorderLevel', 5, 'status', 'In Stock',
    'description', 'Marinated Korean beef bulgogi, frozen', 'image', '',
    'lastUpdated', DATE_FORMAT(NOW(), '%Y-%m-%dT%H:%i:%s.000Z'), 'supplierId', 's1',
    'expirationDate', DATE_FORMAT(DATE_ADD(NOW(), INTERVAL 6 MONTH), '%Y-%m-%d'),
    'batchNumber', 'BT202608013', 'archived', false
)),

('MEAT002', JSON_OBJECT(
    'id', 'MEAT002', 'name', 'Lotte Luncheon Meat (340g)', 'sku', 'MEAT002', 'category', 'Meat & Seafood',
    'price', 120.00, 'stock', 35, 'reorderLevel', 10, 'status', 'In Stock',
    'description', 'Korean premium luncheon meat', 'image', '',
    'lastUpdated', DATE_FORMAT(NOW(), '%Y-%m-%dT%H:%i:%s.000Z'), 'supplierId', 's1',
    'expirationDate', DATE_FORMAT(DATE_ADD(NOW(), INTERVAL 18 MONTH), '%Y-%m-%d'),
    'batchNumber', 'BT202608014', 'archived', false
)),

('MEAT003', JSON_OBJECT(
    'id', 'MEAT003', 'name', 'Korean Sausage', 'sku', 'MEAT003', 'category', 'Meat & Seafood',
    'price', 220.00, 'stock', 18, 'reorderLevel', 5, 'status', 'Low Stock',
    'description', 'Traditional Korean style sausage', 'image', '',
    'lastUpdated', DATE_FORMAT(NOW(), '%Y-%m-%dT%H:%i:%s.000Z'), 'supplierId', 's1',
    'expirationDate', DATE_FORMAT(DATE_ADD(NOW(), INTERVAL 3 MONTH), '%Y-%m-%d'),
    'batchNumber', 'BT202608016', 'archived', false
)),

-- SEAFOOD (SEA001)
('SEA001', JSON_OBJECT(
    'id', 'SEA001', 'name', 'Fish Cake (500g)', 'sku', 'SEA001', 'category', 'Meat & Seafood',
    'price', 170.00, 'stock', 25, 'reorderLevel', 8, 'status', 'In Stock',
    'description', 'Korean fish cake for soup and hot pot', 'image', '',
    'lastUpdated', DATE_FORMAT(NOW(), '%Y-%m-%dT%H:%i:%s.000Z'), 'supplierId', 's2',
    'expirationDate', DATE_FORMAT(DATE_ADD(NOW(), INTERVAL 4 MONTH), '%Y-%m-%d'),
    'batchNumber', 'BT202608015', 'archived', false
)),

-- OILS & CONDIMENTS (OIL001, SAU001)
('OIL001', JSON_OBJECT(
    'id', 'OIL001', 'name', 'Sesame Oil (1L)', 'sku', 'OIL001', 'category', 'Condiments & Sauces',
    'price', 450.00, 'stock', 15, 'reorderLevel', 5, 'status', 'Low Stock',
    'description', 'Premium Korean sesame oil for cooking', 'image', '',
    'lastUpdated', DATE_FORMAT(NOW(), '%Y-%m-%dT%H:%i:%s.000Z'), 'supplierId', 's1',
    'expirationDate', DATE_FORMAT(DATE_ADD(NOW(), INTERVAL 24 MONTH), '%Y-%m-%d'),
    'batchNumber', 'BT202608017', 'archived', false
)),

('SAU001', JSON_OBJECT(
    'id', 'SAU001', 'name', 'Bulgogi Sauce', 'sku', 'SAU001', 'category', 'Condiments & Sauces',
    'price', 160.00, 'stock', 28, 'reorderLevel', 10, 'status', 'In Stock',
    'description', 'Korean bulgogi marinade and sauce', 'image', '',
    'lastUpdated', DATE_FORMAT(NOW(), '%Y-%m-%dT%H:%i:%s.000Z'), 'supplierId', 's1',
    'expirationDate', DATE_FORMAT(DATE_ADD(NOW(), INTERVAL 18 MONTH), '%Y-%m-%d'),
    'batchNumber', 'BT202608018', 'archived', false
)),

-- PANTRY ITEMS (PAN001, PAN002)
('PAN001', JSON_OBJECT(
    'id', 'PAN001', 'name', 'Kimchi (500g)', 'sku', 'PAN001', 'category', 'Rice & Pantry',
    'price', 180.00, 'stock', 22, 'reorderLevel', 8, 'status', 'In Stock',
    'description', 'Traditional Korean fermented cabbage', 'image', '',
    'lastUpdated', DATE_FORMAT(NOW(), '%Y-%m-%dT%H:%i:%s.000Z'), 'supplierId', 's1',
    'expirationDate', DATE_FORMAT(DATE_ADD(NOW(), INTERVAL 2 MONTH), '%Y-%m-%d'),
    'batchNumber', 'BT202608019', 'archived', false
)),

('PAN002', JSON_OBJECT(
    'id', 'PAN002', 'name', 'Nori Seaweed', 'sku', 'PAN002', 'category', 'Rice & Pantry',
    'price', 80.00, 'stock', 40, 'reorderLevel', 15, 'status', 'In Stock',
    'description', 'Dried seaweed sheets for sushi and snacks', 'image', '',
    'lastUpdated', DATE_FORMAT(NOW(), '%Y-%m-%dT%H:%i:%s.000Z'), 'supplierId', 's2',
    'expirationDate', DATE_FORMAT(DATE_ADD(NOW(), INTERVAL 12 MONTH), '%Y-%m-%d'),
    'batchNumber', 'BT202608020', 'archived', false
)),

-- SNACKS (SNK001-SNK004)
('SNK001', JSON_OBJECT(
    'id', 'SNK001', 'name', 'Pepero', 'sku', 'SNK001', 'category', 'Snacks',
    'price', 55.00, 'stock', 60, 'reorderLevel', 20, 'status', 'In Stock',
    'description', 'Korean chocolate covered biscuit sticks', 'image', '',
    'lastUpdated', DATE_FORMAT(NOW(), '%Y-%m-%dT%H:%i:%s.000Z'), 'supplierId', 's1',
    'expirationDate', DATE_FORMAT(DATE_ADD(NOW(), INTERVAL 9 MONTH), '%Y-%m-%d'),
    'batchNumber', 'BT202608021', 'archived', false
)),

('SNK002', JSON_OBJECT(
    'id', 'SNK002', 'name', 'Lotte Binch', 'sku', 'SNK002', 'category', 'Snacks',
    'price', 130.00, 'stock', 30, 'reorderLevel', 10, 'status', 'Low Stock',
    'description', 'Korean premium chocolate snack', 'image', '',
    'lastUpdated', DATE_FORMAT(NOW(), '%Y-%m-%dT%H:%i:%s.000Z'), 'supplierId', 's1',
    'expirationDate', DATE_FORMAT(DATE_ADD(NOW(), INTERVAL 8 MONTH), '%Y-%m-%d'),
    'batchNumber', 'BT202608022', 'archived', false
)),

('SNK003', JSON_OBJECT(
    'id', 'SNK003', 'name', 'Snickers', 'sku', 'SNK003', 'category', 'Snacks',
    'price', 45.00, 'stock', 50, 'reorderLevel', 20, 'status', 'In Stock',
    'description', 'Classic chocolate bar with peanuts and caramel', 'image', '',
    'lastUpdated', DATE_FORMAT(NOW(), '%Y-%m-%dT%H:%i:%s.000Z'), 'supplierId', 's2',
    'expirationDate', DATE_FORMAT(DATE_ADD(NOW(), INTERVAL 6 MONTH), '%Y-%m-%d'),
    'batchNumber', 'BT202608023', 'archived', false
)),

('SNK004', JSON_OBJECT(
    'id', 'SNK004', 'name', 'Mars', 'sku', 'SNK004', 'category', 'Snacks',
    'price', 45.00, 'stock', 45, 'reorderLevel', 20, 'status', 'In Stock',
    'description', 'Chocolate bar with caramel and nougat', 'image', '',
    'lastUpdated', DATE_FORMAT(NOW(), '%Y-%m-%dT%H:%i:%s.000Z'), 'supplierId', 's2',
    'expirationDate', DATE_FORMAT(DATE_ADD(NOW(), INTERVAL 6 MONTH), '%Y-%m-%d'),
    'batchNumber', 'BT202608024', 'archived', false
)),

-- DRINKS (DRK001-DRK009)
('DRK001', JSON_OBJECT(
    'id', 'DRK001', 'name', 'Welch\'s Grape', 'sku', 'DRK001', 'category', 'Beverages',
    'price', 55.00, 'stock', 35, 'reorderLevel', 15, 'status', 'In Stock',
    'description', 'Welch\'s grape juice drink', 'image', '',
    'lastUpdated', DATE_FORMAT(NOW(), '%Y-%m-%dT%H:%i:%s.000Z'), 'supplierId', 's2',
    'expirationDate', DATE_FORMAT(DATE_ADD(NOW(), INTERVAL 12 MONTH), '%Y-%m-%d'),
    'batchNumber', 'BT202608025', 'archived', false
)),

('DRK002', JSON_OBJECT(
    'id', 'DRK002', 'name', 'Welch\'s Strawberry', 'sku', 'DRK002', 'category', 'Beverages',
    'price', 55.00, 'stock', 30, 'reorderLevel', 15, 'status', 'Low Stock',
    'description', 'Welch\'s strawberry juice drink', 'image', '',
    'lastUpdated', DATE_FORMAT(NOW(), '%Y-%m-%dT%H:%i:%s.000Z'), 'supplierId', 's2',
    'expirationDate', DATE_FORMAT(DATE_ADD(NOW(), INTERVAL 12 MONTH), '%Y-%m-%d'),
    'batchNumber', 'BT202608026', 'archived', false
)),

('DRK003', JSON_OBJECT(
    'id', 'DRK003', 'name', 'Welch\'s Peach', 'sku', 'DRK003', 'category', 'Beverages',
    'price', 55.00, 'stock', 28, 'reorderLevel', 15, 'status', 'Low Stock',
    'description', 'Welch\'s peach juice drink', 'image', '',
    'lastUpdated', DATE_FORMAT(NOW(), '%Y-%m-%dT%H:%i:%s.000Z'), 'supplierId', 's2',
    'expirationDate', DATE_FORMAT(DATE_ADD(NOW(), INTERVAL 12 MONTH), '%Y-%m-%d'),
    'batchNumber', 'BT202608027', 'archived', false
)),

('DRK004', JSON_OBJECT(
    'id', 'DRK004', 'name', 'Pororo Apple', 'sku', 'DRK004', 'category', 'Beverages',
    'price', 45.00, 'stock', 40, 'reorderLevel', 15, 'status', 'In Stock',
    'description', 'Korean Pororo brand apple juice drink', 'image', '',
    'lastUpdated', DATE_FORMAT(NOW(), '%Y-%m-%dT%H:%i:%s.000Z'), 'supplierId', 's1',
    'expirationDate', DATE_FORMAT(DATE_ADD(NOW(), INTERVAL 10 MONTH), '%Y-%m-%d'),
    'batchNumber', 'BT202608028', 'archived', false
)),

('DRK005', JSON_OBJECT(
    'id', 'DRK005', 'name', 'Pororo Milk', 'sku', 'DRK005', 'category', 'Beverages',
    'price', 45.00, 'stock', 35, 'reorderLevel', 15, 'status', 'In Stock',
    'description', 'Korean Pororo brand milk drink', 'image', '',
    'lastUpdated', DATE_FORMAT(NOW(), '%Y-%m-%dT%H:%i:%s.000Z'), 'supplierId', 's1',
    'expirationDate', DATE_FORMAT(DATE_ADD(NOW(), INTERVAL 6 MONTH), '%Y-%m-%d'),
    'batchNumber', 'BT202608029', 'archived', false
)),

('DRK006', JSON_OBJECT(
    'id', 'DRK006', 'name', 'Pororo Blueberry', 'sku', 'DRK006', 'category', 'Beverages',
    'price', 45.00, 'stock', 32, 'reorderLevel', 15, 'status', 'In Stock',
    'description', 'Korean Pororo brand blueberry juice drink', 'image', '',
    'lastUpdated', DATE_FORMAT(NOW(), '%Y-%m-%dT%H:%i:%s.000Z'), 'supplierId', 's1',
    'expirationDate', DATE_FORMAT(DATE_ADD(NOW(), INTERVAL 10 MONTH), '%Y-%m-%d'),
    'batchNumber', 'BT202608030', 'archived', false
)),

('DRK007', JSON_OBJECT(
    'id', 'DRK007', 'name', 'Coldtalk Peach', 'sku', 'DRK007', 'category', 'Beverages',
    'price', 60.00, 'stock', 25, 'reorderLevel', 10, 'status', 'Low Stock',
    'description', 'Korean Coldtalk premium peach drink', 'image', '',
    'lastUpdated', DATE_FORMAT(NOW(), '%Y-%m-%dT%H:%i:%s.000Z'), 'supplierId', 's1',
    'expirationDate', DATE_FORMAT(DATE_ADD(NOW(), INTERVAL 8 MONTH), '%Y-%m-%d'),
    'batchNumber', 'BT202608031', 'archived', false
)),

('DRK008', JSON_OBJECT(
    'id', 'DRK008', 'name', 'Coldtalk Grape', 'sku', 'DRK008', 'category', 'Beverages',
    'price', 60.00, 'stock', 25, 'reorderLevel', 10, 'status', 'Low Stock',
    'description', 'Korean Coldtalk premium grape drink', 'image', '',
    'lastUpdated', DATE_FORMAT(NOW(), '%Y-%m-%dT%H:%i:%s.000Z'), 'supplierId', 's1',
    'expirationDate', DATE_FORMAT(DATE_ADD(NOW(), INTERVAL 8 MONTH), '%Y-%m-%d'),
    'batchNumber', 'BT202608032', 'archived', false
)),

('DRK009', JSON_OBJECT(
    'id', 'DRK009', 'name', 'Coldtalk Lychee', 'sku', 'DRK009', 'category', 'Beverages',
    'price', 60.00, 'stock', 20, 'reorderLevel', 10, 'status', 'Low Stock',
    'description', 'Korean Coldtalk premium lychee drink', 'image', '',
    'lastUpdated', DATE_FORMAT(NOW(), '%Y-%m-%dT%H:%i:%s.000Z'), 'supplierId', 's1',
    'expirationDate', DATE_FORMAT(DATE_ADD(NOW(), INTERVAL 8 MONTH), '%Y-%m-%d'),
    'batchNumber', 'BT202608033', 'archived', false
))

ON DUPLICATE KEY UPDATE id = id;

-- Verify the products were added
SELECT 
    JSON_UNQUOTE(JSON_EXTRACT(data, '$.sku')) as SKU,
    JSON_UNQUOTE(JSON_EXTRACT(data, '$.name')) as Name,
    JSON_UNQUOTE(JSON_EXTRACT(data, '$.category')) as Category,
    JSON_EXTRACT(data, '$.price') as Price,
    JSON_EXTRACT(data, '$.stock') as Stock,
    JSON_UNQUOTE(JSON_EXTRACT(data, '$.status')) as Status
FROM products 
WHERE id LIKE 'RAM%' OR id LIKE 'MEAT%' OR id LIKE 'SEA%' OR id LIKE 'OIL%' OR id LIKE 'SAU%' OR id LIKE 'PAN%' OR id LIKE 'SNK%' OR id LIKE 'DRK%'
ORDER BY id;