-- ============================================================
-- POD WORKFLOW COMPLETE MIGRATION
-- ============================================================
-- Adds tables and fields for complete QR + Camera + POD workflow
-- for Stock Transfer receiving with photo evidence
-- ============================================================

-- ============================================================
-- TABLE: proof_of_delivery (Enhanced)
-- ============================================================
-- Main POD record linking stock transfers to receiving confirmation
-- Includes QR token for scanning and receiving validation
-- ============================================================

CREATE TABLE IF NOT EXISTS `proof_of_delivery` (
  `id` varchar(40) NOT NULL PRIMARY KEY,
  `transfer_id` varchar(40) NOT NULL,
  `transfer_number` varchar(50) NOT NULL,
  `qr_token` varchar(100) NOT NULL UNIQUE,
  `source_location_id` varchar(40) NOT NULL,
  `source_location_name` varchar(255) NOT NULL,
  `destination_location_id` varchar(40) NOT NULL,
  `destination_location_name` varchar(255) NOT NULL,
  `scanned_at` datetime DEFAULT NULL,
  `scanned_by_id` varchar(40) DEFAULT NULL,
  `scanned_by_name` varchar(100) DEFAULT NULL,
  `received_by_id` varchar(40) DEFAULT NULL,
  `received_by_name` varchar(100) DEFAULT NULL,
  `received_at` datetime DEFAULT NULL,
  `confirmation_notes` text DEFAULT NULL,
  `status` varchar(30) NOT NULL DEFAULT 'Pending',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  KEY `idx_transfer_id` (`transfer_id`),
  KEY `idx_qr_token` (`qr_token`),
  KEY `idx_status` (`status`),
  KEY `idx_scanned_at` (`scanned_at`),
  KEY `idx_received_at` (`received_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- TABLE: pod_items
-- ============================================================
-- Individual items in a POD record
-- Tracks expected vs received quantities and item condition
-- ============================================================

CREATE TABLE IF NOT EXISTS `pod_items` (
  `id` varchar(40) NOT NULL PRIMARY KEY,
  `pod_id` varchar(40) NOT NULL,
  `transfer_id` varchar(40) NOT NULL,
  `product_id` varchar(40) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `sku` varchar(50) DEFAULT NULL,
  `expected_quantity` decimal(12,2) NOT NULL DEFAULT 0,
  `received_quantity` decimal(12,2) NOT NULL DEFAULT 0,
  `unit` varchar(50) NOT NULL DEFAULT 'pcs',
  `condition_status` varchar(30) NOT NULL DEFAULT 'Good',
  `notes` text DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  KEY `idx_pod_id` (`pod_id`),
  KEY `idx_transfer_id` (`transfer_id`),
  KEY `idx_product_id` (`product_id`),
  KEY `idx_condition_status` (`condition_status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- TABLE: pod_photos
-- ============================================================
-- Photo evidence for POD records
-- Includes both delivery photos and damage evidence
-- ============================================================

CREATE TABLE IF NOT EXISTS `pod_photos` (
  `id` varchar(40) NOT NULL PRIMARY KEY,
  `pod_id` varchar(40) NOT NULL,
  `pod_item_id` varchar(40) DEFAULT NULL,
  `transfer_id` varchar(40) NOT NULL,
  `photo_type` varchar(30) NOT NULL DEFAULT 'delivery',
  `file_path` varchar(500) NOT NULL,
  `file_size` int(11) DEFAULT NULL,
  `mime_type` varchar(100) DEFAULT NULL,
  `caption` text DEFAULT NULL,
  `uploaded_by_id` varchar(40) NOT NULL,
  `uploaded_by_name` varchar(100) NOT NULL,
  `uploaded_at` datetime NOT NULL DEFAULT current_timestamp(),
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  KEY `idx_pod_id` (`pod_id`),
  KEY `idx_pod_item_id` (`pod_item_id`),
  KEY `idx_transfer_id` (`transfer_id`),
  KEY `idx_photo_type` (`photo_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- TABLE: damage_evidence (Enhanced for Stock Transfers)
-- ============================================================
-- Stores damage evidence for both PO receiving and Stock Transfer POD
-- ============================================================

CREATE TABLE IF NOT EXISTS `damage_evidence` (
  `id` varchar(40) NOT NULL PRIMARY KEY,
  `reference_type` varchar(30) NOT NULL DEFAULT 'PO',
  `reference_id` varchar(40) NOT NULL,
  `reference_number` varchar(50) NOT NULL,
  `receiving_id` varchar(40) DEFAULT NULL,
  `pod_id` varchar(40) DEFAULT NULL,
  `product_id` varchar(40) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `expected_quantity` decimal(12,2) NOT NULL DEFAULT 0,
  `received_quantity` decimal(12,2) NOT NULL DEFAULT 0,
  `damaged_quantity` decimal(12,2) NOT NULL DEFAULT 0,
  `damage_type` varchar(50) DEFAULT NULL,
  `damage_description` text DEFAULT NULL,
  `evidence_image_path` varchar(500) DEFAULT NULL,
  `recorded_by_id` varchar(40) NOT NULL,
  `recorded_by_name` varchar(100) NOT NULL,
  `recorded_at` datetime NOT NULL DEFAULT current_timestamp(),
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  KEY `idx_reference_type` (`reference_type`),
  KEY `idx_reference_id` (`reference_id`),
  KEY `idx_receiving_id` (`receiving_id`),
  KEY `idx_pod_id` (`pod_id`),
  KEY `idx_product_id` (`product_id`),
  KEY `idx_recorded_at` (`recorded_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- INDEXES AND CONSTRAINTS
-- ============================================================

-- Additional composite indexes for better query performance
CREATE INDEX IF NOT EXISTS idx_pod_status_transfer ON proof_of_delivery(status, transfer_id);
CREATE INDEX IF NOT EXISTS idx_pod_items_condition ON pod_items(pod_id, condition_status);
CREATE INDEX IF NOT EXISTS idx_photos_pod_type ON pod_photos(pod_id, photo_type);

-- ============================================================
-- VERIFICATION QUERIES (for testing)
-- ============================================================

-- Check all POD-related tables exist
SELECT 'proof_of_delivery' as table_name, COUNT(*) as exists_check 
FROM information_schema.tables 
WHERE table_schema = DATABASE() AND table_name = 'proof_of_delivery'
UNION ALL
SELECT 'pod_items', COUNT(*) 
FROM information_schema.tables 
WHERE table_schema = DATABASE() AND table_name = 'pod_items'
UNION ALL
SELECT 'pod_photos', COUNT(*) 
FROM information_schema.tables 
WHERE table_schema = DATABASE() AND table_name = 'pod_photos'
UNION ALL
SELECT 'damage_evidence', COUNT(*) 
FROM information_schema.tables 
WHERE table_schema = DATABASE() AND table_name = 'damage_evidence';

-- ============================================================
-- MIGRATION COMPLETE
-- ============================================================
