-- ==========================================
-- SIMPLE FIX: Add SKU normalized column
-- Drop if exists, then recreate
-- ==========================================

-- Drop the column if it exists (ignore error if it doesn't)
ALTER TABLE products DROP COLUMN IF EXISTS sku_normalized;

-- Add the column with GENERATED ALWAYS (MySQL 5.7.6+)
-- This creates a virtual/stored column that automatically extracts SKU from JSON
ALTER TABLE products 
ADD COLUMN sku_normalized VARCHAR(100) 
GENERATED ALWAYS AS (JSON_UNQUOTE(JSON_EXTRACT(data, '$.sku'))) STORED;

-- Add index for better query performance
CREATE INDEX idx_sku_normalized ON products(sku_normalized);

-- Verify the result
SELECT 
    'Column added successfully' AS status,
    COUNT(*) as total_products,
    COUNT(sku_normalized) as products_with_sku
FROM products;
