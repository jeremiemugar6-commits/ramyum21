-- =====================================================================
-- Stock Transfer Audit Trail Data Only
-- Run this in phpMyAdmin to add comprehensive audit trail entries
-- =====================================================================

USE ramyum_db;

-- Ensure audit table exists
CREATE TABLE IF NOT EXISTS stock_transfer_audit (
    id            VARCHAR(40) PRIMARY KEY,
    transfer_id   VARCHAR(100) NOT NULL,
    action        VARCHAR(50) NOT NULL,
    performed_by  VARCHAR(40) NOT NULL,
    performed_by_name VARCHAR(255) NOT NULL,
    details       TEXT,
    created_at    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_transfer_id (transfer_id),
    INDEX idx_action (action),
    INDEX idx_performed_by (performed_by),
    INDEX idx_created_at (created_at)
) ENGINE=InnoDB;

-- Clear existing demo audit entries
DELETE FROM stock_transfer_audit WHERE transfer_id LIKE 'ST-2026-01%';

-- Add comprehensive audit trail entries for all transfers
INSERT INTO stock_transfer_audit (id, transfer_id, action, performed_by, performed_by_name, details, created_at) VALUES

-- =====================================================================
-- ST-2026-0101: Urgent restock scenario audit trail
-- =====================================================================
('audit_001', 'ST-2026-0101', 'CREATED', 'u2', 'Staff User', 'Transfer created for urgent Branch 1 restock', DATE_FORMAT(DATE_SUB(NOW(), INTERVAL 2 HOUR), '%Y-%m-%d %H:%i:%s')),
('audit_002', 'ST-2026-0101', 'SUBMITTED', 'u2', 'Staff User', 'Transfer submitted for manager approval', DATE_FORMAT(DATE_SUB(NOW(), INTERVAL 2 HOUR), '%Y-%m-%d %H:%i:%s')),

-- =====================================================================
-- ST-2026-0102: New product launch scenario audit trail  
-- =====================================================================
('audit_003', 'ST-2026-0102', 'CREATED', 'u3', 'Manager User', 'Transfer created for new product distribution', DATE_FORMAT(DATE_SUB(NOW(), INTERVAL 4 HOUR), '%Y-%m-%d %H:%i:%s')),
('audit_004', 'ST-2026-0102', 'SUBMITTED', 'u3', 'Manager User', 'Transfer submitted for admin approval', DATE_FORMAT(DATE_SUB(NOW(), INTERVAL 4 HOUR), '%Y-%m-%d %H:%i:%s')),

-- =====================================================================
-- ST-2026-0103: Completed transfer scenario audit trail
-- =====================================================================
('audit_005', 'ST-2026-0103', 'CREATED', 'u2', 'Staff User', 'Transfer created for inventory optimization', DATE_FORMAT(DATE_SUB(NOW(), INTERVAL 1 DAY), '%Y-%m-%d %H:%i:%s')),
('audit_006', 'ST-2026-0103', 'SUBMITTED', 'u2', 'Staff User', 'Transfer submitted for approval', DATE_FORMAT(DATE_SUB(NOW(), INTERVAL 22 HOUR), '%Y-%m-%d %H:%i:%s')),
('audit_007', 'ST-2026-0103', 'APPROVED', 'u1', 'Admin User', 'Transfer approved for execution', DATE_FORMAT(DATE_SUB(NOW(), INTERVAL 6 HOUR), '%Y-%m-%d %H:%i:%s')),
('audit_008', 'ST-2026-0103', 'COMPLETED', 'u2', 'Staff User', 'Inventory transfer completed successfully', DATE_FORMAT(DATE_SUB(NOW(), INTERVAL 4 HOUR), '%Y-%m-%d %H:%i:%s')),

-- =====================================================================
-- ST-2026-0104: Rejected transfer scenario audit trail
-- =====================================================================
('audit_009', 'ST-2026-0104', 'CREATED', 'u2', 'Staff User', 'Transfer created for special customer order', DATE_FORMAT(DATE_SUB(NOW(), INTERVAL 2 DAY), '%Y-%m-%d %H:%i:%s')),
('audit_010', 'ST-2026-0104', 'SUBMITTED', 'u2', 'Staff User', 'Transfer submitted for manager review', DATE_FORMAT(DATE_SUB(NOW(), INTERVAL 46 HOUR), '%Y-%m-%d %H:%i:%s')),
('audit_011', 'ST-2026-0104', 'REJECTED', 'u3', 'Manager User', 'Transfer rejected due to insufficient source inventory', DATE_FORMAT(DATE_SUB(NOW(), INTERVAL 1 DAY), '%Y-%m-%d %H:%i:%s')),

-- =====================================================================
-- ST-2026-0105: Emergency transfer scenario audit trail
-- =====================================================================
('audit_012', 'ST-2026-0105', 'CREATED', 'u3', 'Manager User', 'Emergency transfer created for stockout situation', DATE_FORMAT(DATE_SUB(NOW(), INTERVAL 3 HOUR), '%Y-%m-%d %H:%i:%s')),
('audit_013', 'ST-2026-0105', 'SUBMITTED', 'u3', 'Manager User', 'Emergency transfer submitted for immediate approval', DATE_FORMAT(DATE_SUB(NOW(), INTERVAL 3 HOUR), '%Y-%m-%d %H:%i:%s')),
('audit_014', 'ST-2026-0105', 'APPROVED', 'u1', 'Admin User', 'Emergency transfer approved with fast-track priority', DATE_FORMAT(DATE_SUB(NOW(), INTERVAL 2 HOUR), '%Y-%m-%d %H:%i:%s'))

ON DUPLICATE KEY UPDATE id = id;

-- =====================================================================
-- Verification queries
-- =====================================================================
SELECT 'Audit Trail Setup Complete!' as status;

SELECT 'Total Audit Entries:' as metric, COUNT(*) as count 
FROM stock_transfer_audit;

SELECT 'Audit Actions Summary:' as metric, action, COUNT(*) as count 
FROM stock_transfer_audit 
GROUP BY action 
ORDER BY action;

SELECT 'Recent Audit Entries:' as info;
SELECT 
    transfer_id,
    action,
    performed_by_name,
    LEFT(details, 50) as details_preview,
    created_at
FROM stock_transfer_audit 
ORDER BY created_at DESC 
LIMIT 10;

-- Show audit trail by transfer
SELECT 'Audit Trail by Transfer:' as info;
SELECT 
    transfer_id,
    COUNT(*) as audit_entries,
    GROUP_CONCAT(action ORDER BY created_at) as workflow_steps
FROM stock_transfer_audit
WHERE transfer_id LIKE 'ST-2026-01%'
GROUP BY transfer_id
ORDER BY transfer_id;