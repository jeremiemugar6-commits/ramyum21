-- =====================================================================
-- STEP 1: Create Database Tables
-- Run this first in phpMyAdmin
-- =====================================================================

USE ramyum_db;

-- Create locations table
CREATE TABLE IF NOT EXISTS locations (
    id         VARCHAR(40) PRIMARY KEY,
    data       JSON NOT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Create inventory_locations table  
CREATE TABLE IF NOT EXISTS inventory_locations (
    id         VARCHAR(40) PRIMARY KEY,
    data       JSON NOT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Create stock_transfer_audit table
CREATE TABLE IF NOT EXISTS stock_transfer_audit (
    id            VARCHAR(40) PRIMARY KEY,
    transfer_id   VARCHAR(100) NOT NULL,
    action        VARCHAR(50) NOT NULL,
    performed_by  VARCHAR(40) NOT NULL,
    performed_by_name VARCHAR(255) NOT NULL,
    details       TEXT,
    created_at    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_transfer_id (transfer_id),
    INDEX idx_action (action),
    INDEX idx_performed_by (performed_by),
    INDEX idx_created_at (created_at)
) ENGINE=InnoDB;

SELECT 'Step 1 Complete: Tables Created' as status;