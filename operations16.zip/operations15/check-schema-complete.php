<?php
require_once 'config/database.php';

$db = getDB();

$tables = [
    'purchase_orders', 'receivings', 'proof_of_receiving', 
    'proof_of_receiving_items', 'stock_transfers', 
    'inventory_movements', 'products', 'suppliers', 'locations'
];

foreach($tables as $table) {
    echo "\n=== $table ===\n";
    try {
        $stmt = $db->query("DESCRIBE $table");
        foreach($stmt->fetchAll() as $col) {
            echo "{$col['Field']} ({$col['Type']})\n";
        }
    } catch (Exception $e) {
        echo "ERROR: " . $e->getMessage() . "\n";
    }
}
