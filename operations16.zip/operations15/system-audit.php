<?php
/**
 * COMPREHENSIVE SYSTEM AUDIT SCRIPT
 * RAM-YUM Product & Inventory Operations System
 */

require_once 'config/database.php';

error_reporting(E_ALL);
ini_set('display_errors', 1);

$db = getDB();

echo "═══════════════════════════════════════════════════════════════════════\n";
echo "RAM-YUM SYSTEM AUDIT - " . date('Y-m-d H:i:s') . "\n";
echo "═══════════════════════════════════════════════════════════════════════\n\n";

// 1. DATABASE STRUCTURE AUDIT
echo "1. DATABASE STRUCTURE\n";
echo "───────────────────────────────────────────────────────────────────────\n";

$tables = $db->query('SHOW TABLES')->fetchAll(PDO::FETCH_COLUMN);
echo "✓ Total Tables: " . count($tables) . "\n";
echo "  Tables: " . implode(', ', $tables) . "\n\n";

// 2. CHECK CRITICAL TABLES
$criticalTables = [
    'users' => 'User accounts and authentication',
    'products' => 'Product catalog',
    'suppliers' => 'Supplier information',
    'purchase_orders' => 'Purchase orders',
    'receivings' => 'Receiving records',
    'proof_of_receiving' => 'POR records',
    'proof_of_receiving_items' => 'POR line items',
    'inventory_movements' => 'Inventory transactions',
    'stock_transfers' => 'Stock transfer records',
    'transfer_proof' => 'Transfer proof/delivery',
    'locations' => 'Warehouse/branch locations',
    'security_logs' => 'Audit trail'
];

echo "2. CRITICAL TABLES CHECK\n";
echo "───────────────────────────────────────────────────────────────────────\n";
foreach ($criticalTables as $table => $desc) {
    $exists = in_array($table, $tables);
    echo ($exists ? "✓" : "✗") . " {$table} - {$desc}\n";
    
    if ($exists) {
        $count = $db->query("SELECT COUNT(*) FROM {$table}")->fetchColumn();
        echo "  Records: {$count}\n";
    }
}
echo "\n";

// 3. DATA INTEGRITY CHECKS
echo "3. DATA INTEGRITY\n";
echo "───────────────────────────────────────────────────────────────────────\n";

// Products
$prodCount = $db->query("SELECT COUNT(*) FROM products")->fetchColumn();
$prodWithImage = $db->query("SELECT COUNT(*) FROM products WHERE JSON_EXTRACT(data, '$.image') IS NOT NULL")->fetchColumn();
echo "✓ Products: {$prodCount} total, {$prodWithImage} with images\n";

// Duplicate SKUs
$dupSKU = $db->query("
    SELECT COUNT(*) FROM (
        SELECT JSON_EXTRACT(data, '$.sku') as sku, COUNT(*) as cnt 
        FROM products 
        GROUP BY sku 
        HAVING cnt > 1
    ) x
")->fetchColumn();
echo ($dupSKU > 0 ? "⚠" : "✓") . " Duplicate SKUs: {$dupSKU}\n";

// Users
$userCount = $db->query("SELECT COUNT(*) FROM users")->fetchColumn();
$adminCount = $db->query("SELECT COUNT(*) FROM users WHERE JSON_EXTRACT(data, '$.role') = 'admin'")->fetchColumn();
echo "✓ Users: {$userCount} total, {$adminCount} admins\n";

// Purchase Orders
$poCount = $db->query("SELECT COUNT(*) FROM purchase_orders")->fetchColumn();
$poCompleted = $db->query("SELECT COUNT(*) FROM purchase_orders WHERE JSON_EXTRACT(data, '$.status') = 'Completed'")->fetchColumn();
echo "✓ Purchase Orders: {$poCount} total, {$poCompleted} completed\n";

// POR
$porCount = $db->query("SELECT COUNT(*) FROM proof_of_receiving")->fetchColumn();
$porCompleted = $db->query("SELECT COUNT(*) FROM proof_of_receiving WHERE status = 'Completed'")->fetchColumn();
echo "✓ Proof of Receiving: {$porCount} total, {$porCompleted} completed\n";

// Stock Transfers
$stCount = $db->query("SELECT COUNT(*) FROM stock_transfers")->fetchColumn();
$stCompleted = $db->query("SELECT COUNT(*) FROM stock_transfers WHERE JSON_EXTRACT(data, '$.status') = 'Completed'")->fetchColumn();
echo "✓ Stock Transfers: {$stCount} total, {$stCompleted} completed\n";

// Inventory Movements
$invMovCount = $db->query("SELECT COUNT(*) FROM inventory_movements")->fetchColumn();
echo "✓ Inventory Movements: {$invMovCount} transactions\n";

// Locations
$locCount = $db->query("SELECT COUNT(*) FROM locations")->fetchColumn();
echo "✓ Locations: {$locCount} locations\n";

echo "\n";

// 4. ORPHAN RECORDS CHECK
echo "4. ORPHAN RECORDS CHECK\n";
echo "───────────────────────────────────────────────────────────────────────\n";

// POR items without parent POR
$orphanPORItems = $db->query("
    SELECT COUNT(*) FROM proof_of_receiving_items pri
    LEFT JOIN proof_of_receiving pr ON pri.por_id = pr.id
    WHERE pr.id IS NULL
")->fetchColumn();
echo ($orphanPORItems > 0 ? "⚠" : "✓") . " POR Items without parent: {$orphanPORItems}\n";

// Transfer proof items without parent
$orphanTransferItems = $db->query("
    SELECT COUNT(*) FROM transfer_proof_items tpi
    LEFT JOIN transfer_proof tp ON tpi.proof_id = tp.id
    WHERE tp.id IS NULL
")->fetchColumn();
echo ($orphanTransferItems > 0 ? "⚠" : "✓") . " Transfer Proof Items without parent: {$orphanTransferItems}\n";

echo "\n";

// 5. FILE SYSTEM CHECK
echo "5. FILE SYSTEM CHECK\n";
echo "───────────────────────────────────────────────────────────────────────\n";

$criticalFiles = [
    'index.php' => 'Login page',
    'dashboard.php' => 'Main dashboard',
    'config/database.php' => 'Database configuration',
    'includes/auth.php' => 'Authentication system',
    'includes/functions.php' => 'Helper functions',
    'api/data.php' => 'Main data API',
    'api/users.php' => 'Users API',
    'api/por.php' => 'POR API',
    'api/stock-transfers.php' => 'Stock Transfer API'
];

foreach ($criticalFiles as $file => $desc) {
    $exists = file_exists($file);
    echo ($exists ? "✓" : "✗") . " {$file} - {$desc}\n";
}

echo "\n";

// 6. MODULE CHECK
echo "6. MODULES CHECK\n";
echo "───────────────────────────────────────────────────────────────────────\n";

$modules = [
    'modules/products' => 'Product Catalog',
    'modules/inventory' => 'Inventory Management',
    'modules/purchase-orders' => 'Purchase Orders',
    'modules/receiving' => 'Receiving',
    'modules/por' => 'Proof of Receiving',
    'modules/stock-transfers' => 'Stock Transfers',
    'modules/reports' => 'Reports'
];

foreach ($modules as $path => $name) {
    $exists = is_dir($path);
    echo ($exists ? "✓" : "✗") . " {$name} ({$path})\n";
}

echo "\n";

// 7. SECURITY CHECK
echo "7. SECURITY CHECK\n";
echo "───────────────────────────────────────────────────────────────────────\n";

// Check password hashing
$weakPasswords = $db->query("
    SELECT COUNT(*) FROM users 
    WHERE JSON_EXTRACT(data, '$.password') NOT LIKE '\$2y\$%'
")->fetchColumn();
echo ($weakPasswords > 0 ? "⚠" : "✓") . " Users with weak passwords: {$weakPasswords}\n";

// Check login attempts table
$loginAttempts = $db->query("SELECT COUNT(*) FROM login_attempts")->fetchColumn();
echo "✓ Login attempts tracked: {$loginAttempts}\n";

// Check security logs
$securityLogs = $db->query("SELECT COUNT(*) FROM security_logs")->fetchColumn();
echo "✓ Security log entries: {$securityLogs}\n";

echo "\n";

// 8. WORKFLOW VALIDATION
echo "8. WORKFLOW VALIDATION\n";
echo "───────────────────────────────────────────────────────────────────────\n";

// Check if POs have corresponding receiving records
$poWithReceiving = $db->query("
    SELECT COUNT(DISTINCT po.id) FROM purchase_orders po
    INNER JOIN receivings r ON JSON_EXTRACT(r.data, '$.poId') = po.id
")->fetchColumn();
echo "✓ POs with receiving records: {$poWithReceiving}/{$poCount}\n";

// Check if receiving has POR
$receivingWithPOR = $db->query("
    SELECT COUNT(DISTINCT r.id) FROM receivings r
    INNER JOIN proof_of_receiving pr ON pr.receiving_id = r.id
")->fetchColumn();
$receivingCount = $db->query("SELECT COUNT(*) FROM receivings")->fetchColumn();
echo "✓ Receivings with POR: {$receivingWithPOR}/{$receivingCount}\n";

// Check if transfers have proof
$transfersWithProof = $db->query("
    SELECT COUNT(DISTINCT st.id) FROM stock_transfers st
    INNER JOIN transfer_proof tp ON tp.transfer_id = st.id
")->fetchColumn();
echo "✓ Transfers with proof: {$transfersWithProof}/{$stCount}\n";

echo "\n";

// 9. SUMMARY
echo "9. AUDIT SUMMARY\n";
echo "───────────────────────────────────────────────────────────────────────\n";

$issues = [];
if ($dupSKU > 0) $issues[] = "Duplicate SKUs found";
if ($weakPasswords > 0) $issues[] = "Weak passwords detected";
if ($orphanPORItems > 0) $issues[] = "Orphan POR items";
if ($orphanTransferItems > 0) $issues[] = "Orphan transfer proof items";

if (empty($issues)) {
    echo "✓ NO CRITICAL ISSUES FOUND\n";
} else {
    echo "⚠ ISSUES DETECTED:\n";
    foreach ($issues as $issue) {
        echo "  • {$issue}\n";
    }
}

echo "\n";
echo "═══════════════════════════════════════════════════════════════════════\n";
echo "AUDIT COMPLETE\n";
echo "═══════════════════════════════════════════════════════════════════════\n";
