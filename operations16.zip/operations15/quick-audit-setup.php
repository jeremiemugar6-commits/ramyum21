<?php
/**
 * Quick Audit Trail Setup - Browser Access
 */

// Simple check - no auth needed for setup
require_once __DIR__ . '/config/database.php';

echo "<h1>📊 Quick Audit Trail Setup</h1>";
echo "<p>Loading the exact audit trail data you requested...</p>";

try {
    $db = getDB();
    
    // Ensure audit table exists
    $db->exec("
    CREATE TABLE IF NOT EXISTS stock_transfer_audit (
        id VARCHAR(40) PRIMARY KEY,
        transfer_id VARCHAR(100) NOT NULL,
        action VARCHAR(50) NOT NULL,
        performed_by VARCHAR(40) NOT NULL,
        performed_by_name VARCHAR(255) NOT NULL,
        details TEXT,
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB");
    
    echo "<p>✅ Audit table ready</p>";
    
    // Clear existing entries
    $db->exec("DELETE FROM stock_transfer_audit WHERE id LIKE 'audit_%'");
    echo "<p>🧹 Cleared existing audit entries</p>";
    
    // Execute the exact SQL you provided
    $auditEntries = [
        ['audit_001', 'ST-2026-0101', 'CREATED', 'u2', 'Staff User', 'Transfer created for urgent Branch 1 restock', 'DATE_SUB(NOW(), INTERVAL 2 HOUR)'],
        ['audit_002', 'ST-2026-0101', 'SUBMITTED', 'u2', 'Staff User', 'Transfer submitted for manager approval', 'DATE_SUB(NOW(), INTERVAL 2 HOUR)'],
        ['audit_003', 'ST-2026-0102', 'CREATED', 'u3', 'Manager User', 'Transfer created for new product distribution', 'DATE_SUB(NOW(), INTERVAL 4 HOUR)'],
        ['audit_004', 'ST-2026-0102', 'SUBMITTED', 'u3', 'Manager User', 'Transfer submitted for admin approval', 'DATE_SUB(NOW(), INTERVAL 4 HOUR)'],
        ['audit_005', 'ST-2026-0103', 'CREATED', 'u2', 'Staff User', 'Transfer created for inventory optimization', 'DATE_SUB(NOW(), INTERVAL 1 DAY)'],
        ['audit_006', 'ST-2026-0103', 'SUBMITTED', 'u2', 'Staff User', 'Transfer submitted for approval', 'DATE_SUB(NOW(), INTERVAL 22 HOUR)'],
        ['audit_007', 'ST-2026-0103', 'APPROVED', 'u1', 'Admin User', 'Transfer approved for execution', 'DATE_SUB(NOW(), INTERVAL 6 HOUR)'],
        ['audit_008', 'ST-2026-0103', 'COMPLETED', 'u2', 'Staff User', 'Inventory transfer completed successfully', 'DATE_SUB(NOW(), INTERVAL 4 HOUR)'],
        ['audit_009', 'ST-2026-0104', 'CREATED', 'u2', 'Staff User', 'Transfer created for special customer order', 'DATE_SUB(NOW(), INTERVAL 2 DAY)'],
        ['audit_010', 'ST-2026-0104', 'SUBMITTED', 'u2', 'Staff User', 'Transfer submitted for manager review', 'DATE_SUB(NOW(), INTERVAL 46 HOUR)'],
        ['audit_011', 'ST-2026-0104', 'REJECTED', 'u3', 'Manager User', 'Transfer rejected due to insufficient source inventory', 'DATE_SUB(NOW(), INTERVAL 1 DAY)'],
        ['audit_012', 'ST-2026-0105', 'CREATED', 'u3', 'Manager User', 'Emergency transfer created for stockout situation', 'DATE_SUB(NOW(), INTERVAL 3 HOUR)'],
        ['audit_013', 'ST-2026-0105', 'SUBMITTED', 'u3', 'Manager User', 'Emergency transfer submitted for immediate approval', 'DATE_SUB(NOW(), INTERVAL 3 HOUR)'],
        ['audit_014', 'ST-2026-0105', 'APPROVED', 'u1', 'Admin User', 'Emergency transfer approved with fast-track priority', 'DATE_SUB(NOW(), INTERVAL 2 HOUR)']
    ];
    
    // Insert each audit entry
    foreach ($auditEntries as $entry) {
        $sql = "INSERT INTO stock_transfer_audit (id, transfer_id, action, performed_by, performed_by_name, details, created_at) 
                VALUES (?, ?, ?, ?, ?, ?, DATE_FORMAT({$entry[6]}, '%Y-%m-%d %H:%i:%s'))";
        $stmt = $db->prepare($sql);
        $stmt->execute([$entry[0], $entry[1], $entry[2], $entry[3], $entry[4], $entry[5]]);
        echo "<p>✅ Added: {$entry[0]} - {$entry[2]} for {$entry[1]}</p>";
    }
    
    // Verification
    $stmt = $db->query("SELECT COUNT(*) as count FROM stock_transfer_audit");
    $count = $stmt->fetch()['count'];
    echo "<p><strong>🎯 SUCCESS! Created $count audit trail entries</strong></p>";
    
    // Show summary
    echo "<h2>📋 Audit Summary by Transfer:</h2>";
    $stmt = $db->query("
        SELECT 
            transfer_id,
            GROUP_CONCAT(action ORDER BY created_at SEPARATOR ' → ') as workflow
        FROM stock_transfer_audit 
        WHERE transfer_id LIKE 'ST-2026-01%'
        GROUP BY transfer_id 
        ORDER BY transfer_id
    ");
    
    while ($row = $stmt->fetch()) {
        echo "<p><strong>{$row['transfer_id']}</strong>: {$row['workflow']}</p>";
    }
    
    echo "<h2>🎉 Ready for Demo!</h2>";
    echo "<p><a href='dashboard.php' style='background:#10b981;color:white;padding:10px 20px;text-decoration:none;border-radius:5px;'>📊 Go to Dashboard</a></p>";
    
} catch (Exception $e) {
    echo "<p style='color:red;'>❌ Error: " . $e->getMessage() . "</p>";
}
?>