<?php
/**
 * Comprehensive Supplier Data Consistency Audit
 * Inspects the entire purchasing flow for supplier relationship integrity
 */

require_once 'config/database.php';

$db = getDB();

echo "═══════════════════════════════════════════════════════════════════════\n";
echo "SUPPLIER DATA CONSISTENCY AUDIT\n";
echo "═══════════════════════════════════════════════════════════════════════\n\n";

// 1. Check Suppliers Table
echo "1. SUPPLIERS TABLE STRUCTURE\n";
echo "───────────────────────────────────────────────────────────────────────\n";
try {
    $stmt = $db->query("DESCRIBE suppliers");
    $columns = $stmt->fetchAll(PDO::FETCH_ASSOC);
    foreach ($columns as $col) {
        echo sprintf("%-30s %-20s %-10s %-10s\n", 
            $col['Field'], 
            $col['Type'], 
            $col['Null'], 
            $col['Key']
        );
    }
    
    $countStmt = $db->query("SELECT COUNT(*) as count FROM suppliers");
    $count = $countStmt->fetch()['count'];
    echo "\nTotal Suppliers: $count\n";
} catch (Exception $e) {
    echo "ERROR: " . $e->getMessage() . "\n";
}

echo "\n";

// 2. Check Purchase Orders Table
echo "2. PURCHASE ORDERS TABLE STRUCTURE\n";
echo "───────────────────────────────────────────────────────────────────────\n";
try {
    $stmt = $db->query("DESCRIBE purchase_orders");
    $columns = $stmt->fetchAll(PDO::FETCH_ASSOC);
    foreach ($columns as $col) {
        echo sprintf("%-30s %-20s %-10s %-10s\n", 
            $col['Field'], 
            $col['Type'], 
            $col['Null'], 
            $col['Key']
        );
    }
    
    $countStmt = $db->query("SELECT COUNT(*) as count FROM purchase_orders");
    $count = $countStmt->fetch()['count'];
    echo "\nTotal Purchase Orders: $count\n";
} catch (Exception $e) {
    echo "ERROR: " . $e->getMessage() . "\n";
}

echo "\n";

// 3. Check Receivings Table
echo "3. RECEIVINGS TABLE STRUCTURE\n";
echo "───────────────────────────────────────────────────────────────────────\n";
try {
    $stmt = $db->query("DESCRIBE receivings");
    $columns = $stmt->fetchAll(PDO::FETCH_ASSOC);
    foreach ($columns as $col) {
        echo sprintf("%-30s %-20s %-10s %-10s\n", 
            $col['Field'], 
            $col['Type'], 
            $col['Null'], 
            $col['Key']
        );
    }
    
    $countStmt = $db->query("SELECT COUNT(*) as count FROM receivings");
    $count = $countStmt->fetch()['count'];
    echo "\nTotal Receivings: $count\n";
} catch (Exception $e) {
    echo "ERROR: " . $e->getMessage() . "\n";
}

echo "\n";

// 4. Check Proof of Receiving Table
echo "4. PROOF OF RECEIVING TABLE STRUCTURE\n";
echo "───────────────────────────────────────────────────────────────────────\n";
try {
    $stmt = $db->query("DESCRIBE proof_of_receiving");
    $columns = $stmt->fetchAll(PDO::FETCH_ASSOC);
    foreach ($columns as $col) {
        echo sprintf("%-30s %-20s %-10s %-10s\n", 
            $col['Field'], 
            $col['Type'], 
            $col['Null'], 
            $col['Key']
        );
    }
    
    $countStmt = $db->query("SELECT COUNT(*) as count FROM proof_of_receiving");
    $count = $countStmt->fetch()['count'];
    echo "\nTotal POR Records: $count\n";
} catch (Exception $e) {
    echo "ERROR: " . $e->getMessage() . "\n";
}

echo "\n";

// 5. Check Foreign Key Relationships
echo "5. FOREIGN KEY RELATIONSHIPS\n";
echo "───────────────────────────────────────────────────────────────────────\n";
try {
    $fkQuery = "
        SELECT 
            TABLE_NAME,
            COLUMN_NAME,
            CONSTRAINT_NAME,
            REFERENCED_TABLE_NAME,
            REFERENCED_COLUMN_NAME
        FROM INFORMATION_SCHEMA.KEY_COLUMN_USAGE
        WHERE TABLE_SCHEMA = DATABASE()
        AND REFERENCED_TABLE_NAME IS NOT NULL
        AND TABLE_NAME IN ('purchase_orders', 'receivings', 'proof_of_receiving')
        ORDER BY TABLE_NAME, ORDINAL_POSITION
    ";
    
    $stmt = $db->query($fkQuery);
    $fks = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    if (count($fks) > 0) {
        foreach ($fks as $fk) {
            echo sprintf("%-25s %-20s → %-25s %-20s\n",
                $fk['TABLE_NAME'],
                $fk['COLUMN_NAME'],
                $fk['REFERENCED_TABLE_NAME'],
                $fk['REFERENCED_COLUMN_NAME']
            );
        }
    } else {
        echo "⚠ NO FOREIGN KEYS FOUND\n";
    }
} catch (Exception $e) {
    echo "ERROR: " . $e->getMessage() . "\n";
}

echo "\n";

// 6. Sample Supplier Data
echo "6. SAMPLE SUPPLIER RECORDS\n";
echo "───────────────────────────────────────────────────────────────────────\n";
try {
    $stmt = $db->query("SELECT data FROM suppliers LIMIT 3");
    $suppliers = $stmt->fetchAll();
    
    foreach ($suppliers as $row) {
        $supplier = json_decode($row['data'], true);
        echo "ID: " . ($supplier['id'] ?? 'N/A') . "\n";
        echo "Name: " . ($supplier['name'] ?? 'N/A') . "\n";
        echo "Contact: " . ($supplier['contactPerson'] ?? 'N/A') . "\n";
        echo "Phone: " . ($supplier['phone'] ?? 'N/A') . "\n";
        echo "---\n";
    }
} catch (Exception $e) {
    echo "ERROR: " . $e->getMessage() . "\n";
}

echo "\n";

// 7. Sample PO Data with Supplier Info
echo "7. SAMPLE PURCHASE ORDER RECORDS (Supplier Info)\n";
echo "───────────────────────────────────────────────────────────────────────\n";
try {
    $stmt = $db->query("SELECT data FROM purchase_orders LIMIT 3");
    $pos = $stmt->fetchAll();
    
    foreach ($pos as $row) {
        $po = json_decode($row['data'], true);
        echo "PO Number: " . ($po['poNumber'] ?? 'N/A') . "\n";
        echo "Supplier ID: " . ($po['supplierId'] ?? 'N/A') . "\n";
        echo "Supplier Name: " . ($po['supplier'] ?? 'N/A') . "\n";
        echo "Status: " . ($po['status'] ?? 'N/A') . "\n";
        echo "---\n";
    }
} catch (Exception $e) {
    echo "ERROR: " . $e->getMessage() . "\n";
}

echo "\n";

// 8. Check POR Supplier Relationship
echo "8. PROOF OF RECEIVING SUPPLIER FIELDS\n";
echo "───────────────────────────────────────────────────────────────────────\n";
try {
    $stmt = $db->query("SELECT * FROM proof_of_receiving LIMIT 3");
    $pors = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    if (count($pors) > 0) {
        foreach ($pors as $por) {
            echo "POR Number: " . $por['por_number'] . "\n";
            echo "PO ID: " . ($por['purchase_order_id'] ?? 'N/A') . "\n";
            echo "Supplier ID: " . ($por['supplier_id'] ?? 'N/A') . "\n";
            echo "Supplier Name: " . ($por['supplier_name'] ?? 'N/A') . "\n";
            echo "---\n";
        }
    } else {
        echo "No POR records found\n";
    }
} catch (Exception $e) {
    echo "ERROR: " . $e->getMessage() . "\n";
}

echo "\n";

// 9. Check for Duplicate Suppliers
echo "9. DUPLICATE SUPPLIER CHECK\n";
echo "───────────────────────────────────────────────────────────────────────\n";
try {
    $stmt = $db->query("SELECT data FROM suppliers");
    $suppliers = $stmt->fetchAll();
    
    $names = [];
    foreach ($suppliers as $row) {
        $supplier = json_decode($row['data'], true);
        $name = strtolower(trim($supplier['name'] ?? ''));
        if (isset($names[$name])) {
            $names[$name]++;
        } else {
            $names[$name] = 1;
        }
    }
    
    $duplicates = array_filter($names, function($count) { return $count > 1; });
    
    if (count($duplicates) > 0) {
        echo "⚠ DUPLICATE SUPPLIER NAMES FOUND:\n";
        foreach ($duplicates as $name => $count) {
            echo "  - \"$name\" appears $count times\n";
        }
    } else {
        echo "✓ No duplicate supplier names found\n";
    }
} catch (Exception $e) {
    echo "ERROR: " . $e->getMessage() . "\n";
}

echo "\n";

// 10. Check Supplier Consistency Across Transactions
echo "10. SUPPLIER CONSISTENCY VALIDATION\n";
echo "───────────────────────────────────────────────────────────────────────\n";
try {
    // Get all PORs with their PO supplier info
    $stmt = $db->query("
        SELECT 
            por.id as por_id,
            por.por_number,
            por.purchase_order_id,
            por.supplier_id as por_supplier_id,
            por.supplier_name as por_supplier_name
        FROM proof_of_receiving por
        LIMIT 10
    ");
    $pors = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    $inconsistencies = 0;
    
    foreach ($pors as $por) {
        if (empty($por['purchase_order_id'])) {
            echo "⚠ POR {$por['por_number']}: Missing PO ID\n";
            $inconsistencies++;
            continue;
        }
        
        // Get PO supplier info
        $poStmt = $db->prepare("SELECT data FROM purchase_orders WHERE id = ?");
        $poStmt->execute([$por['purchase_order_id']]);
        $poResult = $poStmt->fetch();
        
        if ($poResult) {
            $po = json_decode($poResult['data'], true);
            $poSupplierId = $po['supplierId'] ?? null;
            
            if ($poSupplierId !== $por['por_supplier_id']) {
                echo "✗ POR {$por['por_number']}: Supplier mismatch\n";
                echo "  PO Supplier: $poSupplierId\n";
                echo "  POR Supplier: {$por['por_supplier_id']}\n";
                $inconsistencies++;
            }
        } else {
            echo "⚠ POR {$por['por_number']}: PO not found (ID: {$por['purchase_order_id']})\n";
            $inconsistencies++;
        }
    }
    
    if ($inconsistencies == 0) {
        echo "✓ No inconsistencies found in sampled records\n";
    } else {
        echo "\n⚠ Total inconsistencies found: $inconsistencies\n";
    }
    
} catch (Exception $e) {
    echo "ERROR: " . $e->getMessage() . "\n";
}

echo "\n";
echo "═══════════════════════════════════════════════════════════════════════\n";
echo "AUDIT COMPLETE\n";
echo "═══════════════════════════════════════════════════════════════════════\n";
?>
