<?php
/**
 * AUDIT POR PRODUCT REFERENCES
 */

require_once 'config/database.php';

$db = getDB();

echo "═══════════════════════════════════════════════════════════════════════\n";
echo "POR PRODUCT REFERENCE AUDIT\n";
echo "═══════════════════════════════════════════════════════════════════════\n\n";

// Get all POR items
$porItems = $db->query("
    SELECT 
        pori.*,
        por.por_number,
        por.status as por_status
    FROM proof_of_receiving_items pori
    INNER JOIN proof_of_receiving por ON pori.por_id = por.id
    ORDER BY por.por_number, pori.id
")->fetchAll();

echo "Total POR items: " . count($porItems) . "\n\n";

// Group by product_id
$byProduct = [];
$invalidRefs = [];

foreach ($porItems as $item) {
    $productId = $item['product_id'];
    
    if (!isset($byProduct[$productId])) {
        $byProduct[$productId] = [];
    }
    $byProduct[$productId][] = $item;
    
    // Check if product exists
    $checkStmt = $db->prepare("SELECT id, data FROM products WHERE id = ?");
    $checkStmt->execute([$productId]);
    $product = $checkStmt->fetch();
    
    if (!$product) {
        $invalidRefs[] = $item;
    }
}

echo "UNIQUE PRODUCT IDS REFERENCED:\n";
echo "───────────────────────────────────────────────────────────────────────\n";
foreach ($byProduct as $productId => $items) {
    echo "{$productId}: " . count($items) . " references\n";
}

echo "\n";

echo "INVALID PRODUCT REFERENCES:\n";
echo "───────────────────────────────────────────────────────────────────────\n";
echo "Items referencing non-existent products: " . count($invalidRefs) . "\n\n";

if (count($invalidRefs) > 0) {
    foreach ($invalidRefs as $item) {
        echo "POR: {$item['por_number']}\n";
        echo "  Item: {$item['product_name']} (SKU: {$item['sku']})\n";
        echo "  Invalid Product ID: {$item['product_id']}\n";
        echo "  Quantity: {$item['accepted_quantity']}\n";
        echo "\n";
    }
}

echo "\n";

// Check actual products in database
echo "ACTUAL PRODUCTS IN DATABASE:\n";
echo "───────────────────────────────────────────────────────────────────────\n";

$products = $db->query("SELECT id, data FROM products ORDER BY id LIMIT 10")->fetchAll();

foreach ($products as $prod) {
    $data = json_decode($prod['data'], true);
    echo "ID: {$prod['id']}\n";
    echo "  Name: {$data['name']}\n";
    echo "  SKU: {$data['sku']}\n";
    echo "  Stock: {$data['stock']}\n";
    echo "\n";
}

echo "... (showing first 10 of " . $db->query("SELECT COUNT(*) FROM products")->fetchColumn() . " total)\n";

echo "\n";

// Try to match POR items to actual products by SKU or name
echo "ATTEMPTING TO MATCH BY SKU/NAME:\n";
echo "───────────────────────────────────────────────────────────────────────\n";

$matchesFound = 0;
$matchesNotFound = 0;

foreach ($invalidRefs as $item) {
    // Try matching by SKU
    $skuStmt = $db->prepare("
        SELECT id, data FROM products 
        WHERE JSON_EXTRACT(data, '$.sku') = ?
        LIMIT 1
    ");
    $skuStmt->execute([$item['sku']]);
    $match = $skuStmt->fetch();
    
    if ($match) {
        $matchData = json_decode($match['data'], true);
        echo "✓ {$item['product_name']} (SKU: {$item['sku']})\n";
        echo "    Invalid ID: {$item['product_id']}\n";
        echo "    Correct ID: {$match['id']}\n";
        echo "    Product: {$matchData['name']}\n";
        $matchesFound++;
    } else {
        // Try matching by name (partial)
        $nameStmt = $db->prepare("
            SELECT id, data FROM products 
            WHERE JSON_EXTRACT(data, '$.name') LIKE ?
            LIMIT 1
        ");
        $nameStmt->execute(['%' . $item['product_name'] . '%']);
        $match = $nameStmt->fetch();
        
        if ($match) {
            $matchData = json_decode($match['data'], true);
            echo "✓ {$item['product_name']} (by name)\n";
            echo "    Invalid ID: {$item['product_id']}\n";
            echo "    Correct ID: {$match['id']}\n";
            echo "    Product: {$matchData['name']}\n";
            $matchesFound++;
        } else {
            echo "✗ {$item['product_name']} (SKU: {$item['sku']}) - No match found\n";
            $matchesNotFound++;
        }
    }
    echo "\n";
}

echo "Matches found: {$matchesFound}\n";
echo "No matches: {$matchesNotFound}\n";

echo "\n";
echo "═══════════════════════════════════════════════════════════════════════\n";
echo "AUDIT COMPLETE\n";
echo "═══════════════════════════════════════════════════════════════════════\n";
