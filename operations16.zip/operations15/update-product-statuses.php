<?php
/**
 * Update Product Statuses Script
 * Updates all products in database with automatic stock status
 * based on their current stock quantity
 */

require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/stock-status.php';

echo "=================================================\n";
echo "UPDATE PRODUCT STATUSES\n";
echo "=================================================\n\n";

try {
    $db = getDB();
    
    // Get all products
    $stmt = $db->query("SELECT id, data FROM products");
    $products = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "Found " . count($products) . " products\n\n";
    
    if (count($products) === 0) {
        echo "No products to update.\n";
        exit(0);
    }
    
    $updated = 0;
    $errors = 0;
    
    foreach ($products as $row) {
        $productData = json_decode($row['data'], true);
        $productId = $row['id'];
        $productName = $productData['name'] ?? 'Unknown';
        $currentStock = $productData['stock'] ?? 0;
        $oldStatus = $productData['status'] ?? 'N/A';
        
        // Calculate automatic status
        $newStatus = getStockStatus($currentStock);
        $emoji = getStockStatusEmoji($newStatus);
        
        // Update product data
        $productData['status'] = $newStatus;
        
        try {
            $updateStmt = $db->prepare("UPDATE products SET data = ? WHERE id = ?");
            $updateStmt->execute([json_encode($productData), $productId]);
            
            $statusChanged = ($oldStatus !== $newStatus);
            $changeIndicator = $statusChanged ? ' [CHANGED]' : '';
            
            echo "✓ $productName\n";
            echo "  Stock: $currentStock\n";
            echo "  Old Status: $oldStatus\n";
            echo "  New Status: $emoji $newStatus$changeIndicator\n\n";
            
            $updated++;
            
        } catch (Exception $e) {
            echo "✗ Error updating $productName: " . $e->getMessage() . "\n\n";
            $errors++;
        }
    }
    
    echo "=================================================\n";
    echo "UPDATE COMPLETE\n";
    echo "=================================================\n";
    echo "Total Products: " . count($products) . "\n";
    echo "Successfully Updated: $updated\n";
    echo "Errors: $errors\n";
    echo "=================================================\n";
    
} catch (Exception $e) {
    echo "Fatal Error: " . $e->getMessage() . "\n";
    exit(1);
}
?>
