import { DataService } from '../../assets/js/utils/data-service.js';
import { StockTransferService } from '../../assets/js/utils/stock-transfer-service.js';
import { toast } from '../../assets/js/components/toast.js';
import { modal } from '../../assets/js/components/modal.js';
import { DataTable } from '../../assets/js/components/table.js';
import { store } from '../../assets/js/store.js';
import { BadgeHelper } from '../../assets/js/utils/badge-helper.js';

const dataService = new DataService();
const transferService = new StockTransferService();

let currentTransfers = [];
let currentLocations = [];
let stockTransferTable = null;
let currentView = 'dashboard';

// --- MAIN RENDER FUNCTION ---
export async function renderStockTransfer() {
    const container = document.getElementById('appContent');
    const userRole = store.getState().role;
    const canCreate = userRole === 'admin' || userRole === 'manager' || userRole === 'staff';
    const canApprove = userRole === 'admin' || userRole === 'manager';

    container.innerHTML = `
        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:26px; flex-wrap:wrap; gap:16px; background:var(--bg-card); padding:22px 26px; border-radius:12px; border:1px solid var(--border-color); box-shadow:var(--shadow-sm);">
            <div>
                <h1 class="page-title">Stock Transfer</h1>
                <p class="page-subtitle">Transfer inventory between locations with approval workflow.</p>
            </div>
            <div style="display:flex; gap:12px; flex-wrap:wrap;">
                <a href="scan-qr.php" style="background:#3B82F6; color:white; padding:10px 20px; border:none; border-radius:8px; font-weight:600; cursor:pointer; display:flex; align-items:center; gap:8px; text-decoration:none;">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/></svg>
                    Scan QR
                </a>
                ${canCreate ? `<button id="createTransferBtn" style="background:var(--primary-red); color:white; padding:10px 20px; border:none; border-radius:8px; font-weight:600; cursor:pointer; display:flex; align-items:center; gap:8px;">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 5v14M5 12h14"/></svg>
                    Create Transfer
                </button>` : ''}
                ${canApprove ? `<button id="pendingApprovalsBtn" style="background:#F59E0B; color:white; padding:10px 20px; border:none; border-radius:8px; font-weight:600; cursor:pointer; display:flex; align-items:center; gap:8px;">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="3"/><path d="M12 1v6M12 17v6M5.05 5.05l4.24 4.24M14.71 14.71l4.24 4.24"/></svg>
                    Pending Approvals
                </button>` : ''}
            </div>
        </div>

        <!-- Navigation Tabs -->
        <div class="tab-navigation" style="margin-bottom:24px; border-bottom:1px solid var(--border-color);">
            <button class="tab-btn active" data-view="dashboard">Dashboard</button>
            <button class="tab-btn" data-view="transfers">All Transfers</button>
            ${canApprove ? '<button class="tab-btn" data-view="approvals">Approvals</button>' : ''}
        </div>

        <!-- Content Area -->
        <div id="stockTransferContent">
            <div style="display:flex; align-items:center; justify-content:center; padding:60px; color:var(--text-muted);">
                <div class="loading-spinner" style="margin-right:16px;"></div>
                <span style="font-weight:500;">Loading Stock Transfer Data...</span>
            </div>
        </div>
    `;

    // Event Listeners
    document.getElementById('createTransferBtn')?.addEventListener('click', () => openCreateTransferModal());
    document.getElementById('pendingApprovalsBtn')?.addEventListener('click', () => switchView('approvals'));
    
    // Tab Navigation
    document.querySelectorAll('.tab-btn').forEach(btn => {
        btn.addEventListener('click', (e) => {
            document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
            e.target.classList.add('active');
            switchView(e.target.dataset.view);
        });
    });

    // Initialize with dashboard view
    await loadInitialData();
    switchView('dashboard');
}
// --- DATA LOADING ---
async function loadInitialData() {
    try {
        // Load transfers and locations
        const [transfersResult, locationsResult] = await Promise.all([
            transferService.getAllTransfers(),
            transferService.getLocations()
        ]);

        currentTransfers = transfersResult.data || [];
        currentLocations = locationsResult.data || [];
        
        // Debug: Log locations data
        console.log('Loaded locations:', currentLocations);
        
        // If no locations found, show helpful message
        if (currentLocations.length === 0) {
            console.warn('No locations found. Database may not be set up.');
            toast.show('No locations found. Please set up the database first.', 'warning');
        }
    } catch (error) {
        console.error('Error loading data:', error);
        console.error('Full error details:', error);
        toast.show('Failed to load stock transfer data: ' + error.message, 'error');
    }
}

// --- VIEW SWITCHING ---
async function switchView(view) {
    currentView = view;
    const contentContainer = document.getElementById('stockTransferContent');
    
    contentContainer.innerHTML = `<div style="display:flex; align-items:center; justify-content:center; padding:40px; color:var(--text-muted);">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="animation:spin 1s linear infinite; margin-right:10px;"><path d="M21 12a9 9 0 11-18 0 9 9 0 0118 0z" opacity=".3"/><path d="M21 12a9 9 0 00-9-9"/></svg>
        Loading...
    </div>`;

    try {
        switch (view) {
            case 'dashboard':
                await renderDashboard();
                break;
            case 'transfers':
                await renderTransfersList();
                break;
            case 'approvals':
                await renderApprovals();
                break;
        }
    } catch (error) {
        console.error(`Error rendering ${view}:`, error);
        contentContainer.innerHTML = `<div class="card" style="padding:40px; text-align:center;">
            <h3 style="color:var(--text-primary); margin-bottom:12px;">Error Loading View</h3>
            <p style="color:var(--text-secondary);">Unable to load the ${view} view. Please try again.</p>
        </div>`;
    }
}

// --- DASHBOARD VIEW ---
async function renderDashboard() {
    const container = document.getElementById('stockTransferContent');
    
    // Calculate statistics
    const stats = calculateStatistics();
    
    container.innerHTML = `
        <!-- Summary Cards -->
        <div class="grid-4" style="margin-bottom:24px;">
            <div class="card" style="border-left: 4px solid #3B82F6;">
                <p style="color:var(--text-secondary); font-size:0.9rem;">Total Transfers</p>
                <h3 style="font-size:1.8rem; color:var(--text-primary);">${stats.total}</h3>
                <small style="color:var(--text-muted);">All time</small>
            </div>
            <div class="card" style="border-left: 4px solid #F59E0B;">
                <p style="color:var(--text-secondary); font-size:0.9rem;">Pending Approval</p>
                <h3 style="font-size:1.8rem; color:var(--text-primary);">${stats.pending}</h3>
                <small style="color:var(--text-muted);">Awaiting review</small>
            </div>
            <div class="card" style="border-left: 4px solid #3B82F6;">
                <p style="color:var(--text-secondary); font-size:0.9rem;">In Transit</p>
                <h3 style="font-size:1.8rem; color:var(--text-primary);">${stats.inTransit}</h3>
                <small style="color:var(--text-muted);">Being delivered</small>
            </div>
            <div class="card" style="border-left: 4px solid #10B981;">
                <p style="color:var(--text-secondary); font-size:0.9rem;">Completed</p>
                <h3 style="font-size:1.8rem; color:var(--text-primary);">${stats.completed}</h3>
                <small style="color:var(--text-muted);">Successfully received</small>
            </div>
        </div>

        <!-- Recent Transfers -->
        <div class="card" style="margin-bottom:24px;">
            <h3 style="margin-bottom:16px; color:var(--text-primary);">Recent Stock Transfers</h3>
            <div id="recentTransfersContainer">
                ${renderRecentTransfersList()}
            </div>
        </div>

        <!-- Quick Actions -->
        <div class="card">
            <h3 style="margin-bottom:16px; color:var(--text-primary);">Quick Actions</h3>
            <div style="display:flex; gap:12px; flex-wrap:wrap;">
                <a href="scan-qr.php" style="background:#3B82F6; color:white; padding:12px 24px; border:none; border-radius:8px; cursor:pointer; font-weight:600; text-decoration:none; display:inline-flex; align-items:center; gap:8px;">
                    📱 Scan QR Code
                </a>
                <button onclick="openCreateTransferModal()" style="background:var(--primary-red); color:white; padding:12px 24px; border:none; border-radius:8px; cursor:pointer; font-weight:600;">
                    New Transfer
                </button>
                <button onclick="switchView('transfers')" style="background:var(--bg-gray); color:var(--text-primary); padding:12px 24px; border:1px solid var(--border-color); border-radius:8px; cursor:pointer; font-weight:600;">
                    View All Transfers
                </button>
                ${store.getState().role !== 'staff' ? `
                <button onclick="switchView('approvals')" style="background:#F59E0B; color:white; padding:12px 24px; border:none; border-radius:8px; cursor:pointer; font-weight:600;">
                    Review Pending
                </button>
                ` : ''}
            </div>
        </div>
    `;
}
// --- STATISTICS CALCULATION ---
function calculateStatistics() {
    const stats = {
        total: currentTransfers.length,
        pending: currentTransfers.filter(t => t.status === 'Pending Approval').length,
        approved: currentTransfers.filter(t => t.status === 'Approved').length,
        inTransit: currentTransfers.filter(t => t.status === 'In Transit').length,
        completed: currentTransfers.filter(t => t.status === 'Completed').length,
        rejected: currentTransfers.filter(t => t.status === 'Rejected').length,
        draft: currentTransfers.filter(t => t.status === 'Draft').length,
        cancelled: currentTransfers.filter(t => t.status === 'Cancelled').length
    };
    return stats;
}

// --- RECENT TRANSFERS LIST ---
function renderRecentTransfersList() {
    const recentTransfers = currentTransfers
        .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))
        .slice(0, 5);

    if (recentTransfers.length === 0) {
        return `<div style="text-align:center; padding:40px; color:var(--text-muted);">
            <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" style="margin-bottom:16px; opacity:0.5;">
                <path d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4"/>
            </svg>
            <p>No stock transfers found.</p>
            <button onclick="openCreateTransferModal()" style="margin-top:16px; background:var(--primary-red); color:white; padding:10px 20px; border:none; border-radius:6px; cursor:pointer;">
                Create First Transfer
            </button>
        </div>`;
    }

    return recentTransfers.map(transfer => `
        <div class="recent-transfer-item" style="display:flex; justify-content:space-between; align-items:center; padding:16px; border:1px solid var(--border-color); border-radius:8px; margin-bottom:8px; background:var(--bg-white); cursor:pointer;" onclick="viewTransferDetails('${transfer.id}')">
            <div style="flex:1;">
                <div style="display:flex; align-items:center; gap:12px; margin-bottom:4px;">
                    <strong style="color:var(--text-primary);">${transfer.transferNumber}</strong>
                    ${BadgeHelper.getStockTransferStatusBadge(transfer.status)}
                </div>
                <div style="font-size:0.9rem; color:var(--text-secondary);">
                    ${transfer.sourceLocationName} → ${transfer.destinationLocationName}
                </div>
                <div style="font-size:0.8rem; color:var(--text-muted); margin-top:4px;">
                    ${transfer.totalItems} items • ${transferService.formatDate(transfer.createdAt)}
                </div>
            </div>
            <div style="text-align:right;">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M9 18l6-6-6-6"/>
                </svg>
            </div>
        </div>
    `).join('');
}

// --- TRANSFERS LIST VIEW ---
async function renderTransfersList() {
    const container = document.getElementById('stockTransferContent');
    const userRole = store.getState().role;
    
    container.innerHTML = `
        <!-- Filters -->
        <div style="display:flex; gap:16px; margin-bottom:20px; flex-wrap:wrap; background:var(--bg-card); padding:16px; border-radius:8px; border:1px solid var(--border-color);">
            <input type="text" id="transferSearch" placeholder="Search by transfer #, location..." style="flex:1; min-width:200px; padding:10px 14px; border:1px solid var(--border-color); border-radius:8px; background:var(--bg-white);">
            <select id="statusFilter" style="padding:10px 14px; border:1px solid var(--border-color); border-radius:8px; background:var(--bg-white); min-width:150px;">
                <option value="">All Status</option>
                <option value="Draft">Draft</option>
                <option value="Pending Approval">Pending Approval</option>
                <option value="Approved">Approved</option>
                <option value="In Transit">In Transit</option>
                <option value="Completed">Completed</option>
                <option value="Rejected">Rejected</option>
                <option value="Cancelled">Cancelled</option>
            </select>
            <select id="locationFilter" style="padding:10px 14px; border:1px solid var(--border-color); border-radius:8px; background:var(--bg-white); min-width:150px;">
                <option value="">All Locations</option>
                ${currentLocations.map(loc => `<option value="${loc.id}">${loc.name}</option>`).join('')}
            </select>
        </div>

        <!-- Transfers Table -->
        <div id="transfersTableContainer"></div>
    `;

    // Add filter event listeners
    document.getElementById('transferSearch').addEventListener('input', filterTransfers);
    document.getElementById('statusFilter').addEventListener('change', filterTransfers);
    document.getElementById('locationFilter').addEventListener('change', filterTransfers);

    // Render table
    renderTransfersTable(currentTransfers);
}

// --- TRANSFERS TABLE ---
function renderTransfersTable(transfers) {
    const container = document.getElementById('transfersTableContainer');
    const userRole = store.getState().role;
    const canApprove = userRole === 'admin' || userRole === 'manager';

    const columns = [
        { key: 'transferNumber', label: 'Transfer #' },
        { key: 'transferDate', label: 'Date' },
        { key: 'sourceLocation', label: 'From' },
        { key: 'destinationLocation', label: 'To' },
        { key: 'totalItems', label: 'Items' },
        { key: 'requestedBy', label: 'Requested By' },
        { key: 'status', label: 'Status' }
    ];

    const formattedData = transfers.map(transfer => ({
        ...transfer,
        transferDate: transferService.formatDate(transfer.transferDate),
        sourceLocation: transfer.sourceLocationName,
        destinationLocation: transfer.destinationLocationName,
        requestedBy: transfer.requestedByName,
        status: BadgeHelper.getStockTransferStatusBadge(transfer.status),
        rawStatus: transfer.status // Keep for filtering
    }));

    if (!stockTransferTable) {
        stockTransferTable = new DataTable('transfersTableContainer', columns, formattedData, {
            actions: true,
            onEdit: (rowData) => viewTransferDetails(rowData.id),
            editLabel: 'View',
            onDelete: canApprove ? (rowData) => handleTransferActions(rowData) : null,
            deleteLabel: 'Actions'
        });
    } else {
        stockTransferTable.updateData(formattedData);
    }
}
// --- FILTER TRANSFERS ---
function filterTransfers() {
    const searchTerm = document.getElementById('transferSearch').value.toLowerCase();
    const statusFilter = document.getElementById('statusFilter').value;
    const locationFilter = document.getElementById('locationFilter').value;

    const filtered = currentTransfers.filter(transfer => {
        const matchesSearch = !searchTerm || 
            transfer.transferNumber.toLowerCase().includes(searchTerm) ||
            transfer.sourceLocationName.toLowerCase().includes(searchTerm) ||
            transfer.destinationLocationName.toLowerCase().includes(searchTerm) ||
            transfer.requestedByName.toLowerCase().includes(searchTerm);

        const matchesStatus = !statusFilter || transfer.status === statusFilter;
        
        const matchesLocation = !locationFilter || 
            transfer.sourceLocationId === locationFilter || 
            transfer.destinationLocationId === locationFilter;

        return matchesSearch && matchesStatus && matchesLocation;
    });

    renderTransfersTable(filtered);
}

// --- APPROVALS VIEW ---
async function renderApprovals() {
    const container = document.getElementById('stockTransferContent');
    
    try {
        const result = await transferService.getPendingApprovals();
        const pendingTransfers = result.data || [];

        container.innerHTML = `
            <div class="card" style="margin-bottom:24px;">
                <h3 style="margin-bottom:16px; color:var(--text-primary);">Pending Approvals (${pendingTransfers.length})</h3>
                <p style="color:var(--text-secondary); margin-bottom:20px;">Review and approve or reject stock transfer requests.</p>
                
                ${pendingTransfers.length === 0 ? `
                    <div style="text-align:center; padding:40px; color:var(--text-muted);">
                        <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" style="margin-bottom:16px; opacity:0.5;">
                            <path d="M9 12l2 2 4-4"/>
                            <path d="M21 12c0 4.97-4.03 9-9 9s-9-4.03-9-9 4.03-9 9-9c2.25 0 4.31.83 5.89 2.2"/>
                        </svg>
                        <p>No transfers pending approval.</p>
                    </div>
                ` : `
                    <div id="pendingTransfersContainer">
                        ${pendingTransfers.map(renderPendingTransferCard).join('')}
                    </div>
                `}
            </div>
        `;
    } catch (error) {
        console.error('Error loading pending approvals:', error);
        container.innerHTML = `
            <div class="card" style="text-align:center; padding:40px;">
                <h3 style="color:var(--text-primary); margin-bottom:12px;">Error Loading Approvals</h3>
                <p style="color:var(--text-secondary);">Unable to load pending approvals. Please try again.</p>
                <button onclick="renderApprovals()" style="margin-top:16px; background:var(--primary-red); color:white; padding:10px 20px; border:none; border-radius:6px; cursor:pointer;">
                    Retry
                </button>
            </div>
        `;
    }
}

// --- PENDING TRANSFER CARD ---
function renderPendingTransferCard(transfer) {
    const urgency = transferService.getTransferUrgency(transfer);
    const urgencyClass = urgency === 'urgent' ? 'border-red-400' : urgency === 'high' ? 'border-yellow-400' : 'border-gray-200';
    
    return `
        <div class="pending-transfer-card" style="border:2px solid var(--border-color); border-radius:12px; padding:20px; margin-bottom:16px; background:var(--bg-white); ${urgency === 'urgent' ? 'border-color:#EF4444;' : urgency === 'high' ? 'border-color:#F59E0B;' : ''}">
            <div style="display:flex; justify-content:space-between; align-items:start; margin-bottom:16px;">
                <div>
                    <h4 style="color:var(--text-primary); margin-bottom:4px;">${transfer.transferNumber}</h4>
                    <p style="color:var(--text-secondary); font-size:0.9rem;">${transfer.sourceLocationName} → ${transfer.destinationLocationName}</p>
                </div>
                <div style="text-align:right;">
                    ${BadgeHelper.getStockTransferStatusBadge(transfer.status)}
                    ${urgency !== 'normal' ? `<div style="font-size:0.8rem; color:${urgency === 'urgent' ? '#EF4444' : '#F59E0B'}; margin-top:4px;">${urgency.toUpperCase()}</div>` : ''}
                </div>
            </div>

            <div style="display:grid; grid-template-columns:1fr 1fr 1fr; gap:16px; margin-bottom:16px; font-size:0.9rem;">
                <div>
                    <strong>Requested by:</strong><br>
                    ${transfer.requestedByName}
                </div>
                <div>
                    <strong>Date:</strong><br>
                    ${transferService.formatDate(transfer.transferDate)}
                </div>
                <div>
                    <strong>Items:</strong><br>
                    ${transfer.totalItems} items
                </div>
            </div>

            ${transfer.remarks ? `
                <div style="background:var(--bg-gray); padding:12px; border-radius:6px; margin-bottom:16px;">
                    <strong style="font-size:0.9rem;">Remarks:</strong><br>
                    <span style="color:var(--text-secondary);">${transfer.remarks}</span>
                </div>
            ` : ''}

            <div style="display:flex; gap:12px; justify-content:flex-end;">
                <button onclick="viewTransferDetails('${transfer.id}')" style="background:var(--bg-gray); color:var(--text-primary); padding:8px 16px; border:1px solid var(--border-color); border-radius:6px; cursor:pointer;">
                    View Details
                </button>
                <button onclick="approveTransfer('${transfer.id}')" style="background:#10B981; color:white; padding:8px 16px; border:none; border-radius:6px; cursor:pointer; font-weight:600;">
                    Approve
                </button>
                <button onclick="rejectTransfer('${transfer.id}')" style="background:#EF4444; color:white; padding:8px 16px; border:none; border-radius:6px; cursor:pointer; font-weight:600;">
                    Reject
                </button>
            </div>
        </div>
    `;
}
// --- CREATE TRANSFER MODAL ---
async function openCreateTransferModal() {
    // Check if locations are available
    if (!currentLocations || currentLocations.length === 0) {
        toast.show('No locations available. Please ensure database is set up properly.', 'error');
        console.error('No locations available:', currentLocations);
        return;
    }

    const formHTML = `
        <form id="createTransferForm">
            <div style="display:grid; gap:16px;">
                <!-- Location Selection -->
                <div style="display:grid; grid-template-columns:1fr 1fr; gap:16px;">
                    <div>
                        <label style="display:block; font-weight:600; margin-bottom:6px;">Source Location *</label>
                        <select id="sourceLocation" class="form-input" required>
                            <option value="">-- Select Source --</option>
                            ${currentLocations.map(loc => `<option value="${loc.id}">${loc.name || 'Unknown Location'}</option>`).join('')}
                        </select>
                    </div>
                    <div>
                        <label style="display:block; font-weight:600; margin-bottom:6px;">Destination Location *</label>
                        <select id="destinationLocation" class="form-input" required>
                            <option value="">-- Select Destination --</option>
                            ${currentLocations.map(loc => `<option value="${loc.id}">${loc.name || 'Unknown Location'}</option>`).join('')}
                        </select>
                    </div>
                </div>

                <!-- Items Section -->
                <div>
                    <label style="display:block; font-weight:600; margin-bottom:6px;">Transfer Items</label>
                    <div id="transferItemsContainer" style="border:1px solid var(--border-color); border-radius:6px; padding:16px; background:var(--bg-white);">
                        <div style="text-align:center; padding:20px; color:var(--text-muted);">
                            <p>Select source location to load available products</p>
                        </div>
                    </div>
                </div>

                <!-- Remarks -->
                <div>
                    <label style="display:block; font-weight:600; margin-bottom:6px;">Remarks (Optional)</label>
                    <textarea id="transferRemarks" class="form-input" rows="3" placeholder="Add any notes about this transfer..."></textarea>
                </div>

                <!-- Transfer Summary -->
                <div id="transferSummary" style="background:var(--bg-gray); padding:16px; border-radius:6px; display:none;">
                    <h4 style="margin-bottom:8px;">Transfer Summary</h4>
                    <div id="summaryContent"></div>
                </div>
            </div>
        </form>
    `;

    modal.open('Create Stock Transfer', formHTML, {
        confirmText: 'Submit for Approval',
        onConfirm: async () => {
            await submitTransfer();
        },
        width: 'large'
    });

    // Setup event listeners
    setupCreateTransferEvents();
}

// --- SETUP CREATE TRANSFER EVENTS ---
function setupCreateTransferEvents() {
    const sourceSelect = document.getElementById('sourceLocation');
    const destinationSelect = document.getElementById('destinationLocation');

    // Load inventory when source location changes
    sourceSelect.addEventListener('change', async () => {
        const locationId = sourceSelect.value;
        if (locationId && destinationSelect.value === locationId) {
            destinationSelect.value = '';
            toast.show('Destination cleared: it cannot match the source location', 'info');
        }
        await loadSourceInventory(locationId);
    });

    // Validate destinations don't match source
    destinationSelect.addEventListener('change', () => {
        validateLocationSelection();
    });
}

// --- LOAD SOURCE INVENTORY ---
async function loadSourceInventory(locationId) {
    const container = document.getElementById('transferItemsContainer');
    
    if (!locationId) {
        container.innerHTML = `
            <div style="text-align:center; padding:20px; color:var(--text-muted);">
                <p>Select source location to load available products</p>
            </div>
        `;
        return;
    }

    container.innerHTML = `
        <div style="display:flex; align-items:center; justify-content:center; padding:20px; color:var(--text-muted);">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="animation:spin 1s linear infinite; margin-right:8px;">
                <path d="M21 12a9 9 0 11-18 0 9 9 0 0118 0z" opacity=".3"/>
                <path d="M21 12a9 9 0 00-9-9"/>
            </svg>
            Loading inventory...
        </div>
    `;

    try {
        const result = await transferService.getInventoryByLocation(locationId);
        const inventory = result.data || [];

        if (inventory.length === 0) {
            container.innerHTML = `
                <div style="text-align:center; padding:20px; color:var(--text-muted);">
                    <p>No inventory found at this location</p>
                </div>
            `;
            return;
        }

        container.innerHTML = `
            <div style="margin-bottom:12px;">
                <h4>Available Products (${inventory.length})</h4>
                <p style="font-size:0.9rem; color:var(--text-secondary);">Select products to transfer</p>
            </div>
            <div id="productsList">
                ${inventory.map(item => renderProductSelectionItem(item)).join('')}
            </div>
            <div style="margin-top:16px; padding-top:16px; border-top:1px solid var(--border-color);">
                <button type="button" id="addAllItemsBtn" style="background:var(--primary-red); color:white; padding:8px 16px; border:none; border-radius:6px; cursor:pointer; font-size:0.9rem;">
                    Add All Available Items
                </button>
            </div>
        `;

        // Setup item selection events
        setupProductSelectionEvents(inventory);

    } catch (error) {
        console.error('Error loading inventory:', error);
        container.innerHTML = `
            <div style="text-align:center; padding:20px; color:var(--text-danger);">
                <p>Error loading inventory. Please try again.</p>
            </div>
        `;
    }
}
// --- RENDER PRODUCT SELECTION ITEM ---
function escAttr(v) {
    return String(v ?? '').replace(/&/g, '&amp;').replace(/"/g, '&quot;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}

function renderProductSelectionItem(item) {
    const unit = item.unit || 'pcs';
    return `
        <div class="product-item" data-product-id="${escAttr(item.productId)}" data-product-name="${escAttr(item.productName)}" data-sku="${escAttr(item.sku)}" data-unit="${escAttr(unit)}" style="display:flex; justify-content:space-between; align-items:center; padding:12px; border:1px solid var(--border-color); border-radius:6px; margin-bottom:8px;">
            <div style="flex:1;">
                <div style="font-weight:600; color:var(--text-primary);">${escAttr(item.productName)}</div>
                <div style="font-size:0.9rem; color:var(--text-secondary);">
                    SKU: ${escAttr(item.sku)} | Available: ${item.availableQuantity} ${escAttr(unit)}
                </div>
            </div>
            <div style="display:flex; align-items:center; gap:8px;">
                <input type="number" 
                       class="quantity-input" 
                       data-product-id="${escAttr(item.productId)}"
                       min="0" 
                       max="${item.availableQuantity}" 
                       value="0" 
                       style="width:80px; padding:4px 8px; border:1px solid var(--border-color); border-radius:4px;">
                <span style="font-size:0.9rem; color:var(--text-secondary);">${escAttr(unit)}</span>
            </div>
        </div>
    `;
}

// --- SETUP PRODUCT SELECTION EVENTS ---
function setupProductSelectionEvents(inventory) {
    // Quantity input events
    document.querySelectorAll('.quantity-input').forEach(input => {
        input.addEventListener('input', updateTransferSummary);
        input.addEventListener('change', updateTransferSummary);
    });

    // Add all items button
    document.getElementById('addAllItemsBtn')?.addEventListener('click', () => {
        document.querySelectorAll('.quantity-input').forEach(input => {
            const maxQuantity = parseInt(input.getAttribute('max'));
            input.value = Math.min(10, maxQuantity); // Add up to 10 or max available
        });
        updateTransferSummary();
        toast.show('Added all available items with default quantities', 'info');
    });

    // Initial summary update
    updateTransferSummary();
}

// --- UPDATE TRANSFER SUMMARY ---
function updateTransferSummary() {
    const transferItems = collectTransferItems();
    const summaryContainer = document.getElementById('transferSummary');
    const summaryContent = document.getElementById('summaryContent');

    if (transferItems.length === 0) {
        summaryContainer.style.display = 'none';
        return;
    }

    const totalQuantity = transferItems.reduce((sum, item) => sum + item.quantity, 0);
    
    summaryContainer.style.display = 'block';
    summaryContent.innerHTML = `
        <div style="display:grid; grid-template-columns:1fr 1fr 1fr; gap:16px; margin-bottom:12px;">
            <div><strong>Items:</strong> ${transferItems.length}</div>
            <div><strong>Total Quantity:</strong> ${totalQuantity}</div>
            <div><strong>Locations:</strong> ${document.getElementById('sourceLocation')?.selectedOptions[0]?.text || 'Not selected'} → ${document.getElementById('destinationLocation')?.selectedOptions[0]?.text || 'Not selected'}</div>
        </div>
        <div style="max-height:120px; overflow-y:auto;">
            ${transferItems.map(item => `
                <div style="display:flex; justify-content:space-between; padding:4px 0; border-bottom:1px solid var(--border-color); font-size:0.9rem;">
                    <span>${item.productName}</span>
                    <span>${item.quantity} ${item.unit}</span>
                </div>
            `).join('')}
        </div>
    `;
}

// --- COLLECT TRANSFER ITEMS ---
function collectTransferItems() {
    const items = [];
    document.querySelectorAll('.quantity-input').forEach(input => {
        const quantity = parseInt(input.value) || 0;
        if (quantity <= 0) return;

        // Read clean values from data attributes (not from rendered text)
        const row = input.closest('.product-item');
        items.push({
            productId: input.dataset.productId,
            productName: row?.dataset.productName || '',
            sku: row?.dataset.sku || '',
            quantity: Math.min(quantity, parseInt(input.getAttribute('max')) || quantity),
            unit: row?.dataset.unit || 'pcs',
            sourceStock: parseInt(input.getAttribute('max'))
        });
    });
    return items;
}

// --- VALIDATE LOCATION SELECTION ---
function validateLocationSelection() {
    const sourceLocation = document.getElementById('sourceLocation').value;
    const destinationLocation = document.getElementById('destinationLocation').value;
    
    if (sourceLocation && destinationLocation && sourceLocation === destinationLocation) {
        toast.show('Source and destination cannot be the same location', 'error');
        document.getElementById('destinationLocation').value = '';
    }
}

// --- SUBMIT TRANSFER ---
async function submitTransfer() {
    const sourceLocationId = document.getElementById('sourceLocation').value;
    const destinationLocationId = document.getElementById('destinationLocation').value;
    const remarks = document.getElementById('transferRemarks').value.trim();
    const transferItems = collectTransferItems();

    // Validation
    if (!sourceLocationId) {
        toast.show('Please select source location', 'error');
        return;
    }

    if (!destinationLocationId) {
        toast.show('Please select destination location', 'error');
        return;
    }

    if (transferItems.length === 0) {
        toast.show('Please add at least one item to transfer', 'error');
        return;
    }

    const transferData = {
        sourceLocationId,
        destinationLocationId,
        items: transferItems,
        remarks
    };

    // Client-side validation
    const validation = transferService.validateTransfer(transferData);
    if (!validation.isValid) {
        toast.show(validation.errors[0], 'error');
        return;
    }

    try {
        const result = await transferService.createTransfer(transferData);
        
        toast.show(result.message || 'Transfer created successfully!', 'success');
        modal.close();
        
        // Refresh data and view
        await loadInitialData();
        if (currentView === 'transfers') {
            renderTransfersList();
        } else {
            switchView('dashboard');
        }
        
    } catch (error) {
        console.error('Error creating transfer:', error);
        toast.show(error.message || 'Failed to create transfer', 'error');
    }
}
// --- VIEW TRANSFER DETAILS ---
async function viewTransferDetails(transferId) {
    try {
        const result = await transferService.getTransfer(transferId);
        const transfer = result.data;

        if (!transfer) {
            toast.show('Transfer not found', 'error');
            return;
        }

        // Check for existing QR code
        let qrData = null;
        if (transfer.status === 'Approved' || transfer.status === 'In Transit' || transfer.status === 'Completed') {
            try {
                const qrResult = await transferService.getQRToken(transferId);
                if (qrResult.success) {
                    qrData = qrResult.data;
                }
            } catch (error) {
                console.log('No QR code yet:', error.message);
            }
        }

        const detailsHTML = `
            <div style="display:grid; gap:20px;">
                <!-- Transfer Header -->
                <div style="background:var(--bg-gray); padding:20px; border-radius:8px;">
                    <div style="display:flex; justify-content:space-between; align-items:start; margin-bottom:12px;">
                        <div>
                            <h3 style="color:var(--text-primary); margin-bottom:4px;">${transfer.transferNumber}</h3>
                            <p style="color:var(--text-secondary);">${transferService.formatDate(transfer.transferDate)}</p>
                        </div>
                        ${BadgeHelper.getStockTransferStatusBadge(transfer.status)}
                    </div>
                    
                    <div style="display:grid; grid-template-columns:1fr 1fr; gap:20px;">
                        <div>
                            <strong>From:</strong> ${transfer.sourceLocationName}<br>
                            <strong>To:</strong> ${transfer.destinationLocationName}<br>
                            <strong>Requested by:</strong> ${transfer.requestedByName}
                        </div>
                        <div>
                            <strong>Items:</strong> ${transfer.totalItems}<br>
                            <strong>Created:</strong> ${transferService.formatDate(transfer.createdAt)}<br>
                            ${transfer.submittedAt ? `<strong>Submitted:</strong> ${transferService.formatDate(transfer.submittedAt)}<br>` : ''}
                        </div>
                    </div>
                    
                    ${transfer.remarks ? `
                        <div style="margin-top:16px; padding-top:16px; border-top:1px solid var(--border-color);">
                            <strong>Remarks:</strong><br>
                            <span style="color:var(--text-secondary);">${transfer.remarks}</span>
                        </div>
                    ` : ''}
                </div>

                <!-- Items Details -->
                <div>
                    <h4 style="margin-bottom:12px;">Transfer Items</h4>
                    <div style="border:1px solid var(--border-color); border-radius:8px; overflow:hidden;">
                        <div style="background:var(--bg-gray); padding:12px; border-bottom:1px solid var(--border-color); font-weight:600; display:grid; grid-template-columns:2fr 1fr 1fr 1fr; gap:12px;">
                            <div>Product</div>
                            <div>SKU</div>
                            <div>Quantity</div>
                            <div>Unit</div>
                        </div>
                        ${transfer.items.map(item => `
                            <div style="padding:12px; border-bottom:1px solid var(--border-color); display:grid; grid-template-columns:2fr 1fr 1fr 1fr; gap:12px;">
                                <div style="font-weight:500;">${item.productName}</div>
                                <div style="color:var(--text-secondary);">${item.sku}</div>
                                <div><strong>${item.quantity}</strong></div>
                                <div>${item.unit || 'pcs'}</div>
                            </div>
                        `).join('')}
                    </div>
                </div>

                <!-- Approval Actions (Only for Pending Approval status) -->
                ${transfer.status === 'Pending Approval' && (store.getState().role === 'admin' || store.getState().role === 'manager') ? `
                    <div style="background:#FEF3C7; border:1px solid #F59E0B; padding:20px; border-radius:8px;">
                        <h4 style="color:#92400E; margin-bottom:12px;">Awaiting Your Approval</h4>
                        <p style="color:#92400E; margin-bottom:16px;">
                            Review the transfer details above. Approving will allow the transfer to be processed and inventory to be updated.
                        </p>
                        <div style="display:flex; gap:12px; flex-wrap:wrap;">
                            <button onclick="handleApproveFromDetails('${transfer.id}')" style="background:#10B981; color:white; padding:12px 24px; border:none; border-radius:8px; cursor:pointer; font-weight:600; display:flex; align-items:center; gap:8px;">
                                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                    <path d="M22 11.08V12a10 10 0 11-5.93-9.14"/>
                                    <path d="M22 4L12 14.01l-3-3"/>
                                </svg>
                                Approve Transfer
                            </button>
                            <button onclick="handleRejectFromDetails('${transfer.id}')" style="background:#EF4444; color:white; padding:12px 24px; border:none; border-radius:8px; cursor:pointer; font-weight:600; display:flex; align-items:center; gap:8px;">
                                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                    <circle cx="12" cy="12" r="10"/>
                                    <path d="M15 9l-6 6M9 9l6 6"/>
                                </svg>
                                Reject Transfer
                            </button>
                        </div>
                    </div>
                ` : ''}

                <!-- QR Code Section -->
                ${transfer.status === 'Approved' && !qrData ? `
                    <div style="background:#FEF3C7; border:1px solid #F59E0B; padding:16px; border-radius:8px;">
                        <h4 style="color:#92400E; margin-bottom:12px;">Ready for Dispatch</h4>
                        <p style="margin-bottom:16px;">Generate QR code to mark this transfer as "In Transit" and enable POD scanning.</p>
                        <button id="generateQRBtn" style="background:var(--primary-red); color:white; padding:10px 20px; border:none; border-radius:6px; cursor:pointer; font-weight:600;">
                            Generate QR Code
                        </button>
                    </div>
                ` : ''}

                ${qrData ? `
                    <div style="background:#DBEAFE; border:1px solid #3B82F6; padding:20px; border-radius:8px; text-align:center;">
                        <h4 style="color:#1E40AF; margin-bottom:16px;">📱 Proof of Delivery QR Code</h4>
                        <div id="qrCodeContainer" style="background:white; padding:20px; border-radius:8px; display:inline-block; margin-bottom:16px;">
                            <!-- QR code will be generated here -->
                        </div>
                        <div style="margin-top:12px;">
                            <p style="font-size:0.9rem; color:#1E40AF; margin-bottom:8px;">
                                <strong>Status:</strong> ${qrData.status || 'Pending Receipt'}
                            </p>
                            <p style="font-size:0.85rem; color:#64748B;">
                                Scan this QR code at the destination to confirm delivery
                            </p>
                        </div>
                        <div style="margin-top:16px; display:flex; gap:8px; justify-content:center; flex-wrap:wrap;">
                            <button id="printQRBtn" style="background:#10B981; color:white; padding:8px 16px; border:none; border-radius:6px; cursor:pointer;">
                                Print QR
                            </button>
                            <button id="copyLinkBtn" style="background:#6B7280; color:white; padding:8px 16px; border:none; border-radius:6px; cursor:pointer;">
                                🔗 Copy Link
                            </button>
                        </div>
                    </div>
                ` : ''}

                <!-- Approval/Rejection Info -->
                ${transfer.status === 'Approved' ? `
                    <div style="background:#D1FAE5; border:1px solid #10B981; padding:16px; border-radius:8px;">
                        <h4 style="color:#065F46; margin-bottom:8px;">Approved</h4>
                        <p><strong>Approved by:</strong> ${transfer.approvedByName}</p>
                        <p><strong>Approved at:</strong> ${transferService.formatDate(transfer.approvedAt)}</p>
                        ${transfer.approvalRemarks ? `<p><strong>Remarks:</strong> ${transfer.approvalRemarks}</p>` : ''}
                    </div>
                ` : ''}

                ${transfer.status === 'In Transit' ? `
                    <div style="background:#DBEAFE; border:1px solid #3B82F6; padding:16px; border-radius:8px;">
                        <h4 style="color:#1E40AF; margin-bottom:8px;">In Transit</h4>
                        <p><strong>Dispatched:</strong> ${transferService.formatDate(transfer.inTransitAt)}</p>
                        ${transfer.qrGeneratedByName ? `<p><strong>By:</strong> ${transfer.qrGeneratedByName}</p>` : ''}
                        <p style="margin-top:8px; color:#1E40AF;">Awaiting delivery confirmation at destination.</p>
                    </div>
                ` : ''}

                ${transfer.status === 'Completed' ? `
                    <div style="background:#D1FAE5; border:1px solid #10B981; padding:16px; border-radius:8px;">
                        <h4 style="color:#065F46; margin-bottom:8px;">Completed</h4>
                        <p><strong>Completed at:</strong> ${transferService.formatDate(transfer.completedAt)}</p>
                        ${transfer.completedBy ? `<p><strong>Received by:</strong> ${transfer.completedBy}</p>` : ''}
                        <p style="margin-top:8px; color:#065F46;">Transfer successfully received and confirmed.</p>
                    </div>
                ` : ''}
                
                ${transfer.status === 'Rejected' ? `
                    <div style="background:#FEE2E2; border:1px solid #EF4444; padding:16px; border-radius:8px;">
                        <h4 style="color:#991B1B; margin-bottom:8px;">Rejected</h4>
                        <p><strong>Rejected by:</strong> ${transfer.rejectedByName}</p>
                        <p><strong>Rejected at:</strong> ${transferService.formatDate(transfer.rejectedAt)}</p>
                        <p><strong>Reason:</strong> ${transfer.rejectionReason}</p>
                    </div>
                ` : ''}
            </div>
        `;

        modal.open(`Transfer Details - ${transfer.transferNumber}`, detailsHTML, {
            confirmText: 'Close',
            onConfirm: () => modal.close(),
            width: 'large'
        });

        // Setup event handlers after modal opens
        setupTransferDetailsHandlers(transfer, qrData);

    } catch (error) {
        console.error('Error loading transfer details:', error);
        toast.show('Failed to load transfer details', 'error');
    }
}

// --- SETUP TRANSFER DETAILS HANDLERS ---
async function setupTransferDetailsHandlers(transfer, qrData) {
    // Generate QR Code button
    const generateBtn = document.getElementById('generateQRBtn');
    if (generateBtn) {
        generateBtn.addEventListener('click', async () => {
            generateBtn.disabled = true;
            generateBtn.textContent = 'Generating...';

            try {
                const result = await transferService.generateQRCode(transfer.id);
                toast.show('QR code generated successfully!', 'success');
                modal.close();
                
                // Reload transfer details to show QR code
                await loadInitialData();
                viewTransferDetails(transfer.id);
            } catch (error) {
                console.error('Error generating QR:', error);
                toast.show(error.message || 'Failed to generate QR code', 'error');
                generateBtn.disabled = false;
                generateBtn.textContent = 'Generate QR Code';
            }
        });
    }

    // If QR data exists, generate the QR code image
    if (qrData && qrData.qr_token) {
        const { QRGenerator } = await import('../../assets/js/utils/qr-generator.js');
        
        // Ensure QRCode library is loaded
        if (!QRGenerator.isLibraryLoaded()) {
            await QRGenerator.loadLibrary();
        }

        const qrUrl = window.location.origin + qrData.qr_url;
        QRGenerator.generateInContainer('qrCodeContainer', qrUrl, 200);

        // Print QR button
        document.getElementById('printQRBtn')?.addEventListener('click', () => {
            printQRCode(transfer, qrUrl);
        });

        // Copy link button
        document.getElementById('copyLinkBtn')?.addEventListener('click', async () => {
            try {
                await navigator.clipboard.writeText(qrUrl);
                toast.show('Link copied to clipboard!', 'success');
            } catch (error) {
                toast.show('Failed to copy link', 'error');
            }
        });
    }
}

// --- PRINT QR CODE ---
function printQRCode(transfer, qrUrl) {
    const printWindow = window.open('', '', 'width=600,height=600');
    printWindow.document.write(`
        <!DOCTYPE html>
        <html>
        <head>
            <title>Stock Transfer QR - ${transfer.transferNumber}</title>
            <style>
                body {
                    font-family: Arial, sans-serif;
                    text-align: center;
                    padding: 20px;
                }
                .header {
                    margin-bottom: 20px;
                }
                .qr-container {
                    margin: 20px auto;
                }
                .info {
                    margin-top: 20px;
                    text-align: left;
                    max-width: 400px;
                    margin-left: auto;
                    margin-right: auto;
                }
                .info-row {
                    padding: 8px 0;
                    border-bottom: 1px solid #ddd;
                }
                @media print {
                    button { display: none; }
                }
            </style>
            <script src="https://cdn.jsdelivr.net/npm/qrcodejs@1.0.0/qrcode.min.js"></script>
        </head>
        <body>
            <div class="header">
                <h1>RAM-YUM Stock Transfer</h1>
                <h2>${transfer.transferNumber}</h2>
            </div>
            <div id="qrcode" class="qr-container"></div>
            <div class="info">
                <div class="info-row"><strong>From:</strong> ${transfer.sourceLocationName}</div>
                <div class="info-row"><strong>To:</strong> ${transfer.destinationLocationName}</div>
                <div class="info-row"><strong>Items:</strong> ${transfer.totalItems}</div>
                <div class="info-row"><strong>Date:</strong> ${new Date().toLocaleDateString()}</div>
            </div>
            <p style="margin-top:30px; font-size:0.9em; color:#666;">
                Scan QR code at destination to confirm delivery
            </p>
            <script>
                new QRCode(document.getElementById("qrcode"), {
                    text: "${qrUrl}",
                    width: 256,
                    height: 256
                });
                setTimeout(() => window.print(), 500);
            </script>
        </body>
        </html>
    `);
    printWindow.document.close();
}

// --- APPROVE TRANSFER ---
async function approveTransfer(transferId) {
    if (transferId && typeof transferId === 'object') transferId = transferId.id;
    const approvalHTML = `
        <div style="margin-bottom:16px;">
            <p style="color:var(--text-secondary);">Are you sure you want to approve this stock transfer? This action will update inventory levels and cannot be undone.</p>
        </div>
        <div>
            <label style="display:block; font-weight:600; margin-bottom:6px;">Approval Remarks (Optional)</label>
            <textarea id="approvalRemarks" class="form-input" rows="3" placeholder="Add any notes about this approval..."></textarea>
        </div>
    `;

    modal.open('Approve Transfer', approvalHTML, {
        confirmText: 'Approve Transfer',
        cancelText: 'Cancel',
        onConfirm: async () => {
            const remarksEl = document.getElementById('approvalRemarks');
            const remarks = remarksEl ? remarksEl.value.trim() : '';
            const confirmButton = document.getElementById('modal-confirm-btn');
            if (confirmButton) {
                confirmButton.disabled = true;
                confirmButton.textContent = 'Processing...';
            }
            try {
                const result = await transferService.approveTransfer(transferId, remarks);
                toast.show(result.message || 'Transfer approved successfully!', 'success');
                modal.close();
                await loadInitialData();
                switchView(currentView);
                return true;
            } catch (error) {
                console.error('Error approving transfer:', error);
                toast.show(error.message || 'Failed to approve transfer', 'error');
                if (confirmButton) {
                    confirmButton.disabled = false;
                    confirmButton.textContent = 'Approve Transfer';
                    confirmButton.dataset.busy = '0';
                }
                return false; // keep modal open
            }
        }
    });
}

// --- REJECT TRANSFER ---
async function rejectTransfer(transferId) {
    if (transferId && typeof transferId === 'object') transferId = transferId.id;
    const rejectionHTML = `
        <div style="margin-bottom:16px;">
            <p style="color:var(--text-secondary);">Please provide a reason for rejecting this stock transfer.</p>
        </div>
        <div>
            <label style="display:block; font-weight:600; margin-bottom:6px;">Rejection Reason *</label>
            <textarea id="rejectionReason" class="form-input" rows="3" placeholder="Explain why this transfer is being rejected..." required></textarea>
        </div>
    `;

    modal.open('Reject Transfer', rejectionHTML, {
        confirmText: 'Reject Transfer',
        cancelText: 'Cancel',
        onConfirm: async () => {
            const reason = document.getElementById('rejectionReason').value.trim();
            
            if (!reason) {
                toast.show('Rejection reason is required', 'error');
                return;
            }
            
            // Disable the confirm button to prevent double submission
            const confirmButton = document.querySelector('.modal-footer .btn-primary');
            if (confirmButton) {
                confirmButton.disabled = true;
                confirmButton.textContent = 'Processing...';
            }
            
            try {
                const result = await transferService.rejectTransfer(transferId, reason);
                toast.show(result.message || 'Transfer rejected', 'info');
                modal.close();
                
                // Refresh current view
                await loadInitialData();
                switchView(currentView);
                
            } catch (error) {
                console.error('Error rejecting transfer:', error);
                toast.show(error.message || 'Failed to reject transfer', 'error');
                
                // Re-enable button on error so user can retry
                if (confirmButton) {
                    confirmButton.disabled = false;
                    confirmButton.textContent = 'Reject Transfer';
                }
            }
        }
    });
}

// --- HANDLE TRANSFER ACTIONS ---
function handleTransferActions(transfer) {
    const userRole = store.getState().role;
    const actions = transferService.getAvailableActions(transfer, userRole);
    
    // For now, just show the view details - more actions can be added later
    viewTransferDetails(transfer.id);
}

// Make functions global for onclick handlers
window.openCreateTransferModal = openCreateTransferModal;
window.viewTransferDetails = viewTransferDetails;
window.approveTransfer = approveTransfer;
window.rejectTransfer = rejectTransfer;
window.switchView = switchView;
window.renderApprovals = renderApprovals;

// Handler functions for approve/reject buttons in details modal
window.handleApproveFromDetails = async function(transferId) {
    // Don't close the modal - modal.open() will replace content.
    // approveTransfer() expects the transfer ID (string), not the object.
    await approveTransfer(transferId);
};

window.handleRejectFromDetails = async function(transferId) {
    // Don't close the modal - modal.open() will replace content.
    // rejectTransfer() expects the transfer ID (string), not the object.
    await rejectTransfer(transferId);
};