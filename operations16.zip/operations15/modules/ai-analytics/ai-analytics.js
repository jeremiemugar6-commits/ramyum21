import { store } from '../../assets/js/store.js';
import { toast } from '../../assets/js/components/toast.js';
import { DataTable } from '../../assets/js/components/table.js';
import { formatNumber } from '../../assets/js/utils/format.js';

const API_URL = 'api/ai-predictions.php';
const RUN_BTN_ICON = `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M23 4v6h-6M1 20v-6h6"/><path d="M3.51 9a9 9 0 0114.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0020.49 15"/></svg>`;

let predictions = [];
let demandChartInstance = null;
let trendChartInstance = null;

// --- RENDER FUNCTION ---
export async function renderAIAnalytics() {
    const container = document.getElementById('appContent');
    const userRole = store.getState().role;

    if (userRole !== 'admin' && userRole !== 'manager') {
        container.innerHTML = `
            <div class="card" style="padding:40px; text-align:center;">
                <h2 style="color:var(--text-primary); margin-bottom:12px;">Access Restricted</h2>
                <p style="color:var(--text-secondary);">AI Analytics is available to Admin and Manager roles only.</p>
            </div>`;
        return;
    }

    container.innerHTML = `
        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:26px; flex-wrap:wrap; gap:16px; background:var(--bg-card); padding:22px 26px; border-radius:12px; border:1px solid var(--border-color); box-shadow:var(--shadow-sm);">
            <div>
                <h1 class="page-title">AI Inventory Analytics</h1>
                <p class="page-subtitle">Demand prediction and restock recommendations powered by linear regression.</p>
            </div>
            <button id="runPredictionsBtn" class="btn-primary">${RUN_BTN_ICON} Run Predictions</button>
        </div>

        <div id="aiKpiRow" style="display:grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap:16px; margin-bottom:24px;"></div>

        <div style="display:grid; grid-template-columns: 1.3fr 1fr; gap:20px; margin-bottom:24px;">
            <div class="card" style="padding:20px;">
                <h3 style="margin-bottom:16px; font-size:1rem;">Product Demand Prediction</h3>
                <canvas id="demandChart" height="260"></canvas>
            </div>
            <div class="card" style="padding:20px;">
                <h3 style="margin-bottom:16px; font-size:1rem;">Demand Trend Mix</h3>
                <canvas id="trendChart" height="260"></canvas>
            </div>
        </div>

        <div class="card" style="padding:20px; margin-bottom:24px;">
            <h3 style="margin-bottom:16px; font-size:1rem;">Top Predicted Products</h3>
            <div id="topProductsTable"></div>
        </div>

        <div class="card" style="padding:20px; margin-bottom:24px;">
            <h3 style="margin-bottom:16px; font-size:1rem; color:#EF4444;">Low Stock Risk Products</h3>
            <div id="riskTable"></div>
        </div>

        <div class="card" style="padding:20px;">
            <h3 style="margin-bottom:16px; font-size:1rem;">AI Recommendations</h3>
            <div id="aiRecommendations"></div>
        </div>
    `;

    document.getElementById('runPredictionsBtn').addEventListener('click', () => runPredictions());

    await loadPredictions();
}

// --- DATA LOADING ---
async function loadPredictions() {
    try {
        const res = await fetch(API_URL);
        const body = await res.json();
        if (!body.success) throw new Error(body.error || 'Failed to load predictions.');

        predictions = body.data || [];

        if (predictions.length === 0) {
            // No cached predictions yet — generate them automatically on first visit.
            await runPredictions(true);
            return;
        }

        renderAll();
    } catch (error) {
        console.error(error);
        toast.show(error.message || 'Failed to load AI predictions.', 'error');
    }
}

async function runPredictions(silent = false) {
    const btn = document.getElementById('runPredictionsBtn');
    if (btn) { btn.disabled = true; btn.innerHTML = 'Analyzing...'; }

    try {
        const res = await fetch(`${API_URL}?action=run`, { method: 'POST' });
        const body = await res.json();
        if (!body.success) throw new Error(body.error || 'Prediction run failed.');

        predictions = body.data || [];
        renderAll();
        if (!silent) toast.show('AI predictions updated.', 'success');
    } catch (error) {
        console.error(error);
        toast.show(error.message || 'Failed to run AI predictions.', 'error');
    } finally {
        if (btn) { btn.disabled = false; btn.innerHTML = `${RUN_BTN_ICON} Run Predictions`; }
    }
}

// --- RENDER HELPERS ---
function renderAll() {
    renderKpis();
    renderDemandChart();
    renderTrendChart();
    renderTopProductsTable();
    renderRiskTable();
    renderRecommendations();
}

function renderKpis() {
    const row = document.getElementById('aiKpiRow');
    if (!row) return;

    const totalPredicted = predictions.reduce((sum, p) => sum + p.predicted_quantity, 0);
    const avgAccuracy = predictions.length
        ? predictions.reduce((sum, p) => sum + p.accuracy_score, 0) / predictions.length
        : 0;
    const riskCount = predictions.filter(p => p.current_stock < p.predicted_quantity).length;

    const kpis = [
        { label: 'Products Analyzed', value: formatNumber(predictions.length), color: 'var(--primary-red)' },
        { label: 'Total Predicted Demand', value: `${formatNumber(totalPredicted)} units`, color: '#3B82F6' },
        { label: 'Avg Model Accuracy', value: `${avgAccuracy.toFixed(1)}%`, color: '#10B981' },
        { label: 'Low Stock Risk', value: formatNumber(riskCount), color: '#EF4444' }
    ];

    row.innerHTML = kpis.map(k => `
        <div class="card" style="padding:18px 20px;">
            <span style="color:var(--text-secondary); font-size:0.8rem; font-weight:600; text-transform:uppercase; letter-spacing:0.05em;">${k.label}</span>
            <div style="font-size:1.6rem; font-weight:700; color:${k.color}; margin-top:6px;">${k.value}</div>
        </div>
    `).join('');
}

function renderDemandChart() {
    const ctx = document.getElementById('demandChart');
    if (!ctx || typeof Chart === 'undefined') return;

    if (demandChartInstance) { demandChartInstance.destroy(); }

    const top = [...predictions].sort((a, b) => b.predicted_quantity - a.predicted_quantity).slice(0, 8);

    demandChartInstance = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: top.map(p => p.product_name),
            datasets: [
                {
                    label: 'Predicted Demand (units)',
                    data: top.map(p => p.predicted_quantity),
                    backgroundColor: '#FF7A00',
                    borderRadius: 6
                },
                {
                    label: 'Current Stock',
                    data: top.map(p => p.current_stock),
                    backgroundColor: '#E5E7EB',
                    borderRadius: 6
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: true,
            plugins: { legend: { display: true, position: 'bottom' } },
            scales: { y: { beginAtZero: true } }
        }
    });
}

function renderTrendChart() {
    const ctx = document.getElementById('trendChart');
    if (!ctx || typeof Chart === 'undefined') return;

    if (trendChartInstance) { trendChartInstance.destroy(); }

    const counts = { Increasing: 0, Stable: 0, Decreasing: 0 };
    predictions.forEach(p => { counts[p.demand_status] = (counts[p.demand_status] || 0) + 1; });

    trendChartInstance = new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: ['Increasing', 'Stable', 'Decreasing'],
            datasets: [{
                data: [counts.Increasing, counts.Stable, counts.Decreasing],
                backgroundColor: ['#10B981', '#F59E0B', '#EF4444']
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: true,
            plugins: { legend: { display: true, position: 'bottom' } }
        }
    });
}

function trendBadge(status) {
    const colors = {
        Increasing: { bg: 'var(--green-bg)', text: 'var(--green-text)' },
        Decreasing: { bg: 'var(--red-bg)', text: 'var(--red-text)' },
        Stable: { bg: 'var(--yellow-bg)', text: 'var(--yellow-text)' }
    };
    const c = colors[status] || colors.Stable;
    return `<span style="padding:3px 10px; border-radius:999px; font-size:0.75rem; font-weight:600; background:${c.bg}; color:${c.text};">${status}</span>`;
}

function renderTopProductsTable() {
    const columns = [
        { key: 'product_name', label: 'Product' },
        { key: 'sku', label: 'SKU' },
        { key: 'predicted_quantity', label: 'Predicted Demand' },
        { key: 'demand_status', label: 'Trend' },
        { key: 'recommended_stock', label: 'Recommended Stock' },
        { key: 'accuracy_score', label: 'Model Accuracy' }
    ];

    const top = [...predictions].sort((a, b) => b.predicted_quantity - a.predicted_quantity).slice(0, 10);
    const data = top.map(p => ({
        ...p,
        predicted_quantity: `${formatNumber(p.predicted_quantity)} units`,
        recommended_stock: `${formatNumber(p.recommended_stock)} units`,
        demand_status: trendBadge(p.demand_status),
        accuracy_score: `${p.accuracy_score.toFixed(1)}%`
    }));

    new DataTable('topProductsTable', columns, data, {});
}

function renderRiskTable() {
    const tableContainer = document.getElementById('riskTable');
    if (!tableContainer) return;

    const risky = predictions
        .filter(p => p.current_stock < p.predicted_quantity)
        .sort((a, b) => (b.predicted_quantity - b.current_stock) - (a.predicted_quantity - a.current_stock));

    if (risky.length === 0) {
        tableContainer.innerHTML = `<p style="color:var(--text-secondary); text-align:center; padding:20px 0;">No products at risk of stockout right now.</p>`;
        return;
    }

    const columns = [
        { key: 'product_name', label: 'Product' },
        { key: 'sku', label: 'SKU' },
        { key: 'current_stock', label: 'Current Stock' },
        { key: 'predicted_quantity', label: 'Predicted Demand' },
        { key: 'shortfall', label: 'Shortfall' }
    ];

    const data = risky.map(p => ({
        ...p,
        current_stock: `${formatNumber(p.current_stock)} units`,
        predicted_quantity: `${formatNumber(p.predicted_quantity)} units`,
        shortfall: `<span style="color:#EF4444; font-weight:600;">${formatNumber(p.predicted_quantity - p.current_stock)} units short</span>`
    }));

    new DataTable('riskTable', columns, data, {});
}

function renderRecommendations() {
    const box = document.getElementById('aiRecommendations');
    if (!box) return;

    if (predictions.length === 0) {
        box.innerHTML = `<p style="color:var(--text-secondary);">Not enough historical data yet. Recommendations will appear once stock movements are recorded.</p>`;
        return;
    }

    const recs = [];

    predictions
        .filter(p => p.current_stock < p.predicted_quantity)
        .sort((a, b) => (b.predicted_quantity - b.current_stock) - (a.predicted_quantity - a.current_stock))
        .slice(0, 5)
        .forEach(p => {
            const orderQty = Math.max(p.recommended_stock - p.current_stock, 0);
            recs.push(`Restock <strong>${p.product_name}</strong> — predicted demand of ${formatNumber(p.predicted_quantity)} units exceeds current stock of ${formatNumber(p.current_stock)}. Recommended order: <strong>${formatNumber(orderQty)} units</strong>.`);
        });

    predictions
        .filter(p => p.demand_status === 'Decreasing' && p.current_stock > p.predicted_quantity * 1.5)
        .slice(0, 3)
        .forEach(p => {
            recs.push(`Consider a promotion or reduced purchasing for <strong>${p.product_name}</strong> — demand is trending down while stock remains high.`);
        });

    if (recs.length === 0) {
        recs.push('Inventory levels look well balanced based on current predictions. No urgent actions needed.');
    }

    box.innerHTML = `<ul style="margin:0; padding-left:20px; display:grid; gap:10px; color:var(--text-primary); font-size:0.9rem; line-height:1.5;">${recs.map(r => `<li>${r}</li>`).join('')}</ul>`;
}
