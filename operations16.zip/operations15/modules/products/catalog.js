import { DataService } from '../../assets/js/utils/data-service.js';
import { Validator } from '../../assets/js/utils/validator.js';
import { toast } from '../../assets/js/components/toast.js';
import { modal } from '../../assets/js/components/modal.js';
import { DataTable } from '../../assets/js/components/table.js';
import { store } from '../../assets/js/store.js';
import { Sanitizer } from '../../assets/js/utils/sanitizer.js';
import { formatCurrency, formatQuantity } from '../../assets/js/utils/format.js';

// Pricing constraints — keeps entered prices within a sane, realistic range
const MIN_PRICE = 0.01;
const MAX_PRICE = 1000000; // ₱1,000,000 ceiling

// Defined RAM-YUM product categories (kept in sync with the dashboard's category cards)
const RAMYUM_CATEGORIES = [
    'Instant Noodles',
    'Sauces & Condiments',
    'Frozen Foods',
    'Rice & Pantry',
    'Snacks',
    'Beverages',
    'Kimchi & Pickled',
    'Specialty Items'
];

// Product units for ordering and inventory
const PRODUCT_UNITS = ['Piece', 'Pack', 'Bundle', 'Box', 'Bottle', 'Can', 'Bag', 'Jar'];

const dataService = new DataService();
let currentProducts = [];
let filteredProducts = [];
let productTable = null;
let showArchived = false;
let viewMode = 'table'; // 'table' or 'grid'

// --- RENDER FUNCTION ---
export async function renderProductCatalog() {
    const container = document.getElementById('appContent');
    const userRole = store.getState().role;
    const canEdit = userRole === 'admin' || userRole === 'manager';

    container.innerHTML = `
        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:26px; flex-wrap:wrap; gap:16px; background:var(--bg-card); padding:22px 26px; border-radius:12px; border:1px solid var(--border-color); box-shadow:var(--shadow-sm);">
            <div>
                <h1 class="page-title">Product Catalog Management</h1>
                <p class="page-subtitle">Manage your store's product listings with images, pricing, and inventory limits.</p>
            </div>
            <div style="display:flex; gap:12px; align-items:center;">
                <div style="display:flex; gap:4px; background:var(--bg-gray); padding:4px; border-radius:8px;">
                    <button id="viewTableBtn" class="view-toggle-btn ${viewMode === 'table' ? 'active' : ''}" data-view="table" style="padding:6px 12px; border:none; background:${viewMode === 'table' ? 'white' : 'transparent'}; color:var(--text-primary); border-radius:6px; cursor:pointer; font-weight:500; transition:all 0.2s;">
                        📋 Table
                    </button>
                    <button id="viewGridBtn" class="view-toggle-btn ${viewMode === 'grid' ? 'active' : ''}" data-view="grid" style="padding:6px 12px; border:none; background:${viewMode === 'grid' ? 'white' : 'transparent'}; color:var(--text-primary); border-radius:6px; cursor:pointer; font-weight:500; transition:all 0.2s;">
                        🔲 Grid
                    </button>
                </div>
                ${canEdit ? `<button id="promoPricingBtn" class="btn-secondary" title="Manage promotional SRP">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 2v20M17 5H9.5a3.5 3.5 0 000 7h5a3.5 3.5 0 010 7H6"/></svg>
                    Promo Pricing
                </button>
                <button id="seasonalSuggestBtn" class="btn-secondary" title="Seasonal product suggestions">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="18" height="18" rx="2"/><path d="M16 2v4M8 2v4M3 10h18"/></svg>
                    Seasonal
                </button>
                <button id="addProductBtn" class="btn-primary">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 5v14M5 12h14"/></svg>
                    Add Product
                </button>` : ''}
            </div>
        </div>
        <div style="display:flex; gap:12px; margin-bottom:20px; flex-wrap:wrap; align-items:center;">
            <input type="text" id="productSearch" placeholder="Search by name, SKU..."
                style="flex:1; min-width:200px; padding:10px 14px; border:1.5px solid var(--border-color); border-radius:10px; background:var(--bg-white); color:var(--text-primary); font-size:0.9rem; font-family:inherit; transition:border-color 0.2s;"
                onfocus="this.style.borderColor='var(--primary-red)'" onblur="this.style.borderColor='var(--border-color)'">
            <select id="categoryFilter"
                style="padding:10px 14px; border:1.5px solid var(--border-color); border-radius:10px; background:var(--bg-white); color:var(--text-primary); font-size:0.9rem; font-family:inherit; cursor:pointer; min-width:150px;">
                <option value="">All Categories</option>
            </select>
            <select id="statusFilter"
                style="padding:10px 14px; border:1.5px solid var(--border-color); border-radius:10px; background:var(--bg-white); color:var(--text-primary); font-size:0.9rem; font-family:inherit; cursor:pointer; min-width:140px;">
                <option value="">All Status</option>
                <option value="In Stock">In Stock</option>
                <option value="Low Stock">Low Stock</option>
                <option value="Out of Stock">Out of Stock</option>
            </select>
            <label style="display:flex; align-items:center; gap:8px; padding:10px 14px; border:1.5px solid var(--border-color); border-radius:10px; background:var(--bg-white); color:var(--text-primary); font-size:0.9rem; cursor:pointer; user-select:none;">
                <input type="checkbox" id="showArchivedToggle" style="width:16px; height:16px; accent-color:var(--primary-red); cursor:pointer;">
                Show Archived
            </label>
        </div>
        <div id="productTableContainer"></div>
    `;

    document.getElementById('addProductBtn')?.addEventListener('click', () => openProductForm());
    document.getElementById('promoPricingBtn')?.addEventListener('click', () => openPromoPricingManager());
    document.getElementById('seasonalSuggestBtn')?.addEventListener('click', () => openSeasonalSuggestions());
    document.getElementById('productSearch')?.addEventListener('input', applyFilters);
    document.getElementById('categoryFilter')?.addEventListener('change', applyFilters);
    document.getElementById('statusFilter')?.addEventListener('change', applyFilters);
    document.getElementById('showArchivedToggle')?.addEventListener('change', (e) => {
        showArchived = e.target.checked;
        applyFilters();
    });

    // View mode toggles
    document.querySelectorAll('.view-toggle-btn').forEach(btn => {
        btn.addEventListener('click', (e) => {
            const newView = e.target.dataset.view;
            if (newView !== viewMode) {
                viewMode = newView;
                document.querySelectorAll('.view-toggle-btn').forEach(b => {
                    b.classList.remove('active');
                    b.style.background = 'transparent';
                });
                e.target.classList.add('active');
                e.target.style.background = 'white';
                renderTable();
            }
        });
    });

    await loadProducts();
}

async function loadProducts() {
    try {
        currentProducts = await dataService.findAll('products');
        const catFilter = document.getElementById('categoryFilter');
        const dbCategories = await dataService.findAll('categories').catch(() => []);
        const dbCategoryNames = (dbCategories || []).map(c => c.name).filter(Boolean);
        const allCategoryNames = [...new Set([...RAMYUM_CATEGORIES, ...dbCategoryNames])];
        allCategoryNames.forEach(name => {
            const opt = document.createElement('option');
            opt.value = name;
            opt.textContent = name;
            catFilter.appendChild(opt);
        });
        applyFilters();
    } catch (error) {
        toast.show('Failed to load products.', 'error');
        console.error(error);
    }
}

function applyFilters() {
    const searchTerm = document.getElementById('productSearch').value.toLowerCase();
    const category = document.getElementById('categoryFilter').value;
    const status = document.getElementById('statusFilter').value;
    
    filteredProducts = currentProducts.filter(p => {
        // Archived products are hidden unless "Show Archived" is checked
        const matchesArchiveState = showArchived ? !!p.archived : !p.archived;

        // Check if search term matches name, SKU, OR category name
        const matchesSearch = searchTerm === '' || 
            p.name.toLowerCase().includes(searchTerm) || 
            (p.sku || '').toLowerCase().includes(searchTerm) ||
            (p.category || '').toLowerCase().includes(searchTerm) ||
            (p.batchNumber || '').toLowerCase().includes(searchTerm);
        
        // Check category filter
        const matchesCategory = !category || p.category === category;
        
        // Check status filter
        const matchesStatus = !status || p.status === status;
        
        return matchesArchiveState && matchesSearch && matchesCategory && matchesStatus;
    });
    renderTable();
}

function renderTable() {
    const container = document.getElementById('productTableContainer');
    const userRole = store.getState().role;
    const canEdit = userRole === 'admin' || userRole === 'manager';
    const canArchive = userRole === 'admin';

    if (viewMode === 'grid') {
        renderGridView(container, canEdit, canArchive);
    } else {
        renderTableView(container, canEdit, canArchive);
    }
}

function renderGridView(container, canEdit, canArchive) {
    if (filteredProducts.length === 0) {
        container.innerHTML = `
            <div class="card" style="text-align:center; padding:40px;">
                <p style="color:var(--text-secondary); font-size:1.1rem;">No products found.</p>
            </div>
        `;
        return;
    }

    const productsHTML = filteredProducts.map(p => {
        const stockStatus = getStockLevelStatus(p.stock, p.minimumStock, p.maximumStock);
        const imageSrc = p.image || 'assets/images/placeholder-product.png';
        
        return `
            <div class="product-card" style="background:var(--bg-card); border:1px solid var(--border-color); border-radius:12px; padding:16px; transition:all 0.3s; cursor:pointer; position:relative;" onmouseenter="this.style.boxShadow='var(--shadow-md)'" onmouseleave="this.style.boxShadow='none'">
                <!-- Product Image -->
                <div style="width:100%; aspect-ratio:1; background:#F3F4F6; border-radius:8px; overflow:hidden; margin-bottom:12px; display:flex; align-items:center; justify-content:center;">
                    ${p.image ? `<img src="${p.image}" style="width:100%; height:100%; object-fit:cover;">` : `<div style="color:#9CA3AF; font-size:0.9rem; text-align:center;">No Image</div>`}
                </div>
                
                <!-- Product Info -->
                <div style="margin-bottom:8px;">
                    <h3 style="font-size:1rem; font-weight:600; margin-bottom:4px; color:var(--text-primary); white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">${p.name}</h3>
                    <p style="font-size:0.8rem; color:var(--text-secondary); margin-bottom:8px;">SKU: ${p.sku}</p>
                </div>

                <!-- Pricing -->
                <div style="display:grid; grid-template-columns:1fr 1fr; gap:8px; margin-bottom:8px; padding:8px; background:var(--bg-gray); border-radius:6px;">
                    <div>
                        <p style="font-size:0.7rem; color:var(--text-secondary); margin-bottom:2px;">Costing</p>
                        <p style="font-size:0.9rem; font-weight:600; color:var(--text-primary);">₱${formatCurrency(p.costingPrice || p.price || 0)}</p>
                    </div>
                    <div>
                        <p style="font-size:0.7rem; color:var(--text-secondary); margin-bottom:2px;">SRP</p>
                        <p style="font-size:0.9rem; font-weight:600; color:var(--primary-red);">${formatActiveSrp(p)}</p>
                    </div>
                </div>

                <!-- Stock & Unit -->
                <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:8px;">
                    <div>
                        <p style="font-size:0.75rem; color:var(--text-secondary);">Stock</p>
                        <p style="font-size:1.1rem; font-weight:700; color:var(--text-primary);">${formatQuantity(p.stock || 0)} <span style="font-size:0.8rem; font-weight:400; color:var(--text-secondary);">${p.unit || 'pcs'}</span></p>
                    </div>
                    <div style="text-align:right;">
                        ${stockStatus}
                    </div>
                </div>

                <!-- Status Badge -->
                <div style="margin-bottom:12px;">
                    ${p.archived
                        ? `<span style="padding:4px 10px; border-radius:999px; font-size:0.75rem; font-weight:600; display:inline-block; background:#E5E7EB; color:#374151;">Archived</span>`
                        : `<span style="padding:4px 10px; border-radius:999px; font-size:0.75rem; font-weight:600; display:inline-block; ${p.status === 'In Stock' ? 'background:var(--green-bg); color:var(--green-text);' : p.status === 'Low Stock' ? 'background:var(--yellow-bg); color:var(--yellow-text);' : 'background:var(--red-bg); color:var(--red-text);'}">${p.status || 'Unknown'}</span>`
                    }
                </div>

                <!-- Actions -->
                ${canEdit ? `
                    <div style="display:flex; gap:8px;">
                        <button onclick='window.editProduct("${p.id}")' style="flex:1; padding:6px 12px; background:var(--primary-red); color:white; border:none; border-radius:6px; cursor:pointer; font-size:0.85rem; font-weight:500;">
                            Edit
                        </button>
                        ${canArchive ? `
                            <button onclick='window.archiveProduct("${p.id}")' style="flex:1; padding:6px 12px; background:${showArchived ? '#10B981' : '#EF4444'}; color:white; border:none; border-radius:6px; cursor:pointer; font-size:0.85rem; font-weight:500;">
                                ${showArchived ? 'Restore' : 'Archive'}
                            </button>
                        ` : ''}
                    </div>
                ` : ''}
            </div>
        `;
    }).join('');

    container.innerHTML = `
        <div style="display:grid; grid-template-columns:repeat(auto-fill, minmax(250px, 1fr)); gap:20px;">
            ${productsHTML}
        </div>
    `;

    // Expose functions to window for onclick handlers
    window.editProduct = (id) => {
        const product = currentProducts.find(p => p.id === id);
        if (product) openProductForm(product);
    };
    
    window.archiveProduct = (id) => {
        const product = currentProducts.find(p => p.id === id);
        if (product) confirmArchiveToggle(product);
    };
}

function getStockLevelStatus(stock, minStock, maxStock) {
    const current = parseFloat(stock || 0);
    const min = parseFloat(minStock || 0);
    const max = parseFloat(maxStock || 999999);
    
    if (current < min) {
        return `<span style="font-size:0.7rem; padding:3px 8px; border-radius:999px; background:#FEE2E2; color:#991B1B; font-weight:600;">Low</span>`;
    } else if (current > max) {
        return `<span style="font-size:0.7rem; padding:3px 8px; border-radius:999px; background:#FEF3C7; color:#92400E; font-weight:600;">High</span>`;
    } else {
        return `<span style="font-size:0.7rem; padding:3px 8px; border-radius:999px; background:#D1FAE5; color:#065F46; font-weight:600;">OK</span>`;
    }
}

function renderTableView(container, canEdit, canArchive) {

    const columns = [
        { key: 'image', label: 'Image' },
        { key: 'sku', label: 'SKU' },
        { key: 'name', label: 'Name' },
        { key: 'batchNumber', label: 'Batch No.' },
        { key: 'manufacturingDate', label: 'Start (Mfg)' },
        { key: 'expirationDate', label: 'End (Exp)' },
        { key: 'unit', label: 'Unit' },
        { key: 'stock', label: 'Stock' },
        { key: 'costingPrice', label: 'Costing' },
        { key: 'srp', label: 'SRP' },
        { key: 'stockStatus', label: 'Stock Level' },
        { key: 'status', label: 'Status' }
    ];

    // Determine expiration badge color: red if expired, yellow if within 30 days, plain otherwise
    const formatExpiration = (dateStr) => {
        if (!dateStr) return '<span style="color:var(--text-secondary);">—</span>';
        const expDate = new Date(dateStr);
        if (isNaN(expDate.getTime())) return '<span style="color:var(--text-secondary);">—</span>';
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        const msPerDay = 1000 * 60 * 60 * 24;
        const daysLeft = Math.round((expDate - today) / msPerDay);
        const label = expDate.toLocaleDateString();
        if (daysLeft < 0) {
            return `<span style="color:#EF4444; font-weight:600;">${label} (Expired)</span>`;
        } else if (daysLeft <= 30) {
            return `<span style="color:#F59E0B; font-weight:600;">${label} (${daysLeft}d left)</span>`;
        }
        return `<span>${label}</span>`;
    };

    // Determine stock level status badge based on min/max stock
    const getStockLevelBadge = (stock, minStock, maxStock) => {
        // Canonical rules (same as PHP getStockStatus): 0 Out, 1-20 Low, 21-100 In, 101+ Overstock
        const qty = parseFloat(stock) || 0;
        if (qty <= 0) {
            return `<span style="padding:3px 10px; border-radius:999px; font-size:0.75rem; font-weight:600; display:inline-block; background:var(--red-bg); color:var(--red-text);">Out of Stock</span>`;
        }
        if (qty < 21) {
            return `<span style="padding:3px 10px; border-radius:999px; font-size:0.75rem; font-weight:600; display:inline-block; background:var(--yellow-bg); color:var(--yellow-text);">Low Stock</span>`;
        }
        if (qty <= 100) {
            return `<span style="padding:3px 10px; border-radius:999px; font-size:0.75rem; font-weight:600; display:inline-block; background:var(--green-bg); color:var(--green-text);">In Stock</span>`;
        }
        return `<span style="padding:3px 10px; border-radius:999px; font-size:0.75rem; font-weight:600; display:inline-block; background:#DBEAFE; color:#1E40AF;">Overstock</span>`;
    };

    // Format the data for the table view
    const formattedData = filteredProducts.map(p => ({
        ...p,
        image: p.image ? `<img src="${p.image}" style="width:50px; height:50px; object-fit:cover; border-radius:6px; border:1px solid var(--border-color);">` : `<div style="width:50px; height:50px; background:#E5E7EB; border-radius:6px; display:flex; align-items:center; justify-content:center; color:#9CA3AF; font-size:0.7rem;">No Image</div>`,
        batchNumber: p.batchNumber
            ? `<span style="font-weight:500; font-family:ui-monospace,monospace; font-size:0.85rem;">${p.batchNumber}</span>`
            : '<span style="color:var(--text-secondary);">—</span>',
        manufacturingDate: (p.manufacturingDate || p.manufacturing_date)
            ? `<span>${p.manufacturingDate || p.manufacturing_date}</span>`
            : '<span style="color:var(--text-secondary);">—</span>',
        expirationDate: (typeof formatExpiration === 'function' ? formatExpiration(p.expirationDate) : (p.expirationDate || '—')),
        unit: p.unit ? `<span style="font-weight:500;">${p.unit}</span>` : '<span style="color:var(--text-secondary);">—</span>',
        stock: `<span style="font-weight:600;">${formatQuantity(p.stock || 0)}</span>`,
        costingPrice: p.costingPrice ? `₱${formatCurrency(p.costingPrice)}` : `₱${formatCurrency(p.price || 0)}`,
        srp: formatActiveSrp(p),
        stockStatus: getStockLevelBadge(p.stock, p.minimumStock, p.maximumStock),
        status: p.archived
            ? `<span style="padding:3px 10px; border-radius:999px; font-size:0.75rem; font-weight:600; display:inline-block; background:#E5E7EB; color:#374151;">Archived</span>`
            : `<span style="padding:3px 10px; border-radius:999px; font-size:0.75rem; font-weight:600; display:inline-block; ${p.status === 'In Stock' ? 'background:var(--green-bg); color:var(--green-text);' : p.status === 'Low Stock' ? 'background:var(--yellow-bg); color:var(--yellow-text);' : 'background:var(--red-bg); color:var(--red-text);'}">${p.status || 'Unknown'}</span>`,
        // Keep original values for editing
        originalBatchNumber: p.batchNumber,
        originalStatus: p.status,
        originalPrice: p.price,
        originalCostingPrice: p.costingPrice,
        originalSrp: p.srp,
        originalStock: p.stock,
        originalUnit: p.unit
    }));

    if (!productTable) {
        productTable = new DataTable('productTableContainer', columns, formattedData, {
            actions: canEdit,
            onEdit: (rowData) => openProductForm(rowData),
            onDelete: canArchive ? (rowData) => confirmArchiveToggle(rowData) : null,
            deleteLabel: showArchived ? 'Restore' : 'Archive'
        });
    } else {
        productTable.options.onDelete = canArchive ? (rowData) => confirmArchiveToggle(rowData) : null;
        productTable.options.deleteLabel = showArchived ? 'Restore' : 'Archive';
        productTable.updateData(formattedData);
    }
}

async function openProductForm(existingProduct = null) {
    const isEdit = !!existingProduct;
    // If editing, get the original product data (not the formatted table data)
    let originalProduct = existingProduct;
    if (isEdit && existingProduct.id) {
        // First try to get from currentProducts array for clean data
        const cleanProduct = currentProducts.find(p => p.id === existingProduct.id);
        if (cleanProduct) {
            originalProduct = cleanProduct;
        } else {
            // Fallback: use original values from table data if they exist
            originalProduct = {
                ...existingProduct,
                batchNumber: existingProduct.originalBatchNumber || existingProduct.batchNumber,
                status: existingProduct.originalStatus || existingProduct.status,
                price: existingProduct.originalPrice || existingProduct.price,
                stock: existingProduct.originalStock || existingProduct.stock
            };
        }
    }
    const title = isEdit ? `Edit Product: ${originalProduct.name}` : 'Add New Product';

    const formHTML = `
        <form id="productForm" style="display:grid; gap:16px;">
            <!-- Image Upload Section -->
            <div style="border:2px dashed var(--border-color); border-radius:8px; padding:20px; text-align:center;">
                <div id="imagePreview" style="margin-bottom:12px;">
                    ${isEdit && originalProduct.image ? `<img src="${originalProduct.image}" style="max-width:200px; max-height:200px; border-radius:6px;">` : `<div style="width:120px; height:120px; margin:0 auto; background:#F3F4F6; border-radius:6px; display:flex; align-items:center; justify-content:center; color:#9CA3AF;">No Image</div>`}
                </div>
                <input type="file" id="p_image" accept="image/*" style="display:none;">
                <button type="button" id="uploadImageBtn" class="btn-secondary" style="padding:8px 16px; background:var(--secondary-orange); color:white; border:none; border-radius:6px; cursor:pointer;">
                    📷 Upload Product Image
                </button>
                <p style="color:var(--text-muted); font-size:0.8rem; margin-top:8px;">JPG, PNG, GIF, WebP (Max 5MB)</p>
                <input type="hidden" id="p_image_path" value="${isEdit ? originalProduct.image || '' : ''}">
            </div>

            <div style="display:grid; grid-template-columns:1fr 1fr; gap:14px;">
                <div>
                    <label style="display:block; font-weight:600; font-size:0.875rem; color:var(--text-primary); margin-bottom:6px;">Product Name *</label>
                    <input type="text" id="p_name" value="${isEdit ? Sanitizer.sanitizeString(String(originalProduct.name ?? '')) : ''}" class="form-input" required>
                </div>
                <div>
                    <label style="display:block; font-weight:600; font-size:0.875rem; color:var(--text-primary); margin-bottom:6px;">SKU *</label>
                    <input type="text" id="p_sku" value="${isEdit ? Sanitizer.sanitizeString(String(originalProduct.sku ?? '')) : ''}" class="form-input" required>
                </div>
                <div>
                    <label style="display:block; font-weight:600; font-size:0.875rem; color:var(--text-primary); margin-bottom:6px;">Category *</label>
                    <select id="p_category" class="form-input" required>
                        <option value="">-- Select Category --</option>
                        ${RAMYUM_CATEGORIES.map(c => `<option value="${c}" ${isEdit && originalProduct.category === c ? 'selected' : ''}>${c}</option>`).join('')}
                    </select>
                </div>
                <div>
                    <label style="display:block; font-weight:600; font-size:0.875rem; color:var(--text-primary); margin-bottom:6px;">Unit *</label>
                    <select id="p_unit" class="form-input" required>
                        <option value="">-- Select Unit --</option>
                        ${PRODUCT_UNITS.map(u => `<option value="${u}" ${isEdit && originalProduct.unit === u ? 'selected' : ''}>${u}</option>`).join('')}
                    </select>
                </div>
                <div>
                    <label style="display:block; font-weight:600; font-size:0.875rem; color:var(--text-primary); margin-bottom:6px;">Costing Price (₱) *</label>
                    <input type="number" step="0.01" min="${MIN_PRICE}" max="${MAX_PRICE}" id="p_costingPrice" value="${isEdit ? (originalProduct.costingPrice ?? originalProduct.price ?? '') : ''}" class="form-input" required>
                    <small style="color:var(--text-muted); font-size:0.78rem; display:block; margin-top:4px;">Cost to acquire the product</small>
                </div>
                <div>
                    <label style="display:block; font-weight:600; font-size:0.875rem; color:var(--text-primary); margin-bottom:6px;">SRP (₱) *</label>
                    <input type="number" step="0.01" min="${MIN_PRICE}" max="${MAX_PRICE}" id="p_srp" value="${isEdit ? (originalProduct.srp ?? '') : ''}" class="form-input" required>
                    <small style="color:var(--text-muted); font-size:0.78rem; display:block; margin-top:4px;">Suggested Retail Price (regular)</small>
                </div>
                <div style="grid-column:1 / -1; background:var(--bg-gray); padding:14px; border-radius:10px; border:1px dashed var(--border-color);">
                    <p style="font-weight:700; font-size:0.85rem; color:var(--text-primary); margin-bottom:10px;">Promo Pricing (optional)</p>
                    <div style="display:grid; grid-template-columns:1fr 1fr 1fr; gap:12px;">
                        <div>
                            <label style="display:block; font-weight:600; font-size:0.8rem; color:var(--text-secondary); margin-bottom:4px;">Promo SRP (₱)</label>
                            <input type="number" step="0.01" min="0" max="${MAX_PRICE}" id="p_promoSrp" value="${isEdit ? (originalProduct.promoSrp ?? '') : ''}" class="form-input" placeholder="Discounted SRP">
                        </div>
                        <div>
                            <label style="display:block; font-weight:600; font-size:0.8rem; color:var(--text-secondary); margin-bottom:4px;">Promo Start</label>
                            <input type="date" id="p_promoStart" value="${isEdit ? (originalProduct.promoStartDate ?? '') : ''}" class="form-input">
                        </div>
                        <div>
                            <label style="display:block; font-weight:600; font-size:0.8rem; color:var(--text-secondary); margin-bottom:4px;">Promo End</label>
                            <input type="date" id="p_promoEnd" value="${isEdit ? (originalProduct.promoEndDate ?? '') : ''}" class="form-input">
                        </div>
                    </div>
                    <small style="color:var(--text-muted); font-size:0.75rem; display:block; margin-top:8px;">When active, customers see Promo SRP instead of regular SRP. Leave blank for no promo.</small>
                </div>
                <div>
                    <label style="display:block; font-weight:600; font-size:0.875rem; color:var(--text-primary); margin-bottom:6px;">Current Stock *</label>
                    <input type="number" step="0.01" min="0" id="p_stock" value="${isEdit ? Sanitizer.sanitizeString(String(originalProduct.stock ?? '')) : ''}" class="form-input" required>
                </div>
                <div>
                    <label style="display:block; font-weight:600; font-size:0.875rem; color:var(--text-primary); margin-bottom:6px;">Minimum Stock *</label>
                    <input type="number" step="0.01" min="0" id="p_minimumStock" value="${isEdit ? (originalProduct.minimumStock ?? originalProduct.reorderLevel ?? '') : ''}" class="form-input" required>
                    <small style="color:var(--text-muted); font-size:0.78rem; display:block; margin-top:4px;">Alert when stock falls below</small>
                </div>
                <div>
                    <label style="display:block; font-weight:600; font-size:0.875rem; color:var(--text-primary); margin-bottom:6px;">Maximum Stock *</label>
                    <input type="number" step="0.01" min="0" id="p_maximumStock" value="${isEdit ? (originalProduct.maximumStock ?? '') : ''}" class="form-input" required>
                    <small style="color:var(--text-muted); font-size:0.78rem; display:block; margin-top:4px;">Maximum inventory capacity</small>
                </div>
                <div>
                    <label style="display:block; font-weight:600; font-size:0.875rem; color:var(--text-primary); margin-bottom:6px;">Start (Mfg) Date</label>
                    <input type="date" id="p_manufacturingDate" value="${isEdit ? Sanitizer.sanitizeString(String(originalProduct.manufacturingDate ?? originalProduct.manufacturing_date ?? '')) : ''}" class="form-input">
                    <small style="color:var(--text-muted); font-size:0.78rem; display:block; margin-top:4px;">Manufacturing / production start date for this batch.</small>
                </div>
                <div>
                    <label style="display:block; font-weight:600; font-size:0.875rem; color:var(--text-primary); margin-bottom:6px;">Expiration Date ${isEdit ? '' : '*'}</label>
                    <input type="date" id="p_expirationDate" value="${isEdit ? Sanitizer.sanitizeString(String(originalProduct.expirationDate ?? '')) : ''}" class="form-input" ${isEdit ? '' : 'required'}>
                    <small style="color:var(--text-muted); font-size:0.78rem; display:block; margin-top:4px;">Required for new products. Different batches keep separate dates.</small>
                </div>
                ${isEdit ? `
                <div>
                    <label style="display:block; font-weight:600; font-size:0.875rem; color:var(--text-primary); margin-bottom:6px;">Batch No.</label>
                    <input type="text" id="p_batchNumber" value="${Sanitizer.sanitizeString(String(originalProduct.batchNumber ?? ''))}" class="form-input" placeholder="e.g. B-2025-10-001">
                    <small style="color:var(--text-muted); font-size:0.78rem; display:block; margin-top:4px;">Available when editing product / batch record</small>
                </div>
                ` : `<input type="hidden" id="p_batchNumber" value="">`}
                <div>
                    <label style="display:block; font-weight:600; font-size:0.875rem; color:var(--text-primary); margin-bottom:6px;">Status</label>
                    <select id="p_status" class="form-input">
                        <option value="In Stock" ${isEdit && originalProduct.status === 'In Stock' ? 'selected' : ''}>In Stock</option>
                        <option value="Low Stock" ${isEdit && originalProduct.status === 'Low Stock' ? 'selected' : ''}>Low Stock</option>
                        <option value="Out of Stock" ${isEdit && originalProduct.status === 'Out of Stock' ? 'selected' : ''}>Out of Stock</option>
                    </select>
                </div>
            </div>
            <div>
                <label style="display:block; font-weight:600; font-size:0.875rem; color:var(--text-primary); margin-bottom:6px;">Description</label>
                <textarea id="p_description" rows="3" class="form-input" style="resize:vertical;">${isEdit ? originalProduct.description || '' : ''}</textarea>
            </div>
        </form>
    `;

    modal.open(title, formHTML, {
        confirmText: isEdit ? 'Update Product' : 'Add Product',
        onConfirm: async () => {
            const name = document.getElementById('p_name').value.trim();
            const sku = document.getElementById('p_sku').value.trim();
            const category = document.getElementById('p_category').value.trim();
            const unit = document.getElementById('p_unit').value.trim();
            const batchNumber = document.getElementById('p_batchNumber').value.trim();
            const costingPriceRaw = document.getElementById('p_costingPrice').value.trim();
            const srpRaw = document.getElementById('p_srp').value.trim();
            const stockRaw = document.getElementById('p_stock').value.trim();
            const minimumStockRaw = document.getElementById('p_minimumStock').value.trim();
            const maximumStockRaw = document.getElementById('p_maximumStock').value.trim();
            const manufacturingDate = document.getElementById('p_manufacturingDate')?.value || '';
            const expirationDate = document.getElementById('p_expirationDate').value || '';
            const status = document.getElementById('p_status').value;
            const description = document.getElementById('p_description').value.trim();
            const imagePath = document.getElementById('p_image_path').value;

            // Required-field check
            const rules = {
                name: 'required',
                sku: 'required',
                category: 'required',
                unit: 'required',
                costingPrice: 'required',
                srp: 'required',
                stock: 'required',
                minimumStock: 'required',
                maximumStock: 'required'
            };
            const validation = Validator.validateForm(
                { name, sku, category, unit, costingPrice: costingPriceRaw, srp: srpRaw, stock: stockRaw, minimumStock: minimumStockRaw, maximumStock: maximumStockRaw },
                rules
            );

            if (!validation.isValid) {
                toast.show(Object.values(validation.errors)[0], 'error');
                return;
            }

            // New products must have expiration date
            if (!isEdit) {
                if (!expirationDate) {
                    toast.show('Expiration Date is required for new products.', 'error');
                    return;
                }
            }

            const costingPrice = parseFloat(costingPriceRaw);
            const srp = parseFloat(srpRaw);
            const stock = parseFloat(stockRaw);
            const minimumStock = parseFloat(minimumStockRaw);
            const maximumStock = parseFloat(maximumStockRaw);

            if (isNaN(costingPrice) || isNaN(srp) || isNaN(stock) || isNaN(minimumStock) || isNaN(maximumStock)) {
                toast.show('All numeric fields must be valid numbers.', 'error');
                return;
            }

            // Pricing constraints
            if (costingPrice < MIN_PRICE || costingPrice > MAX_PRICE) {
                toast.show(`Costing Price must be between ₱${MIN_PRICE.toFixed(2)} and ₱${MAX_PRICE.toLocaleString()}.`, 'error');
                return;
            }

            if (srp < MIN_PRICE || srp > MAX_PRICE) {
                toast.show(`SRP must be between ₱${MIN_PRICE.toFixed(2)} and ₱${MAX_PRICE.toLocaleString()}.`, 'error');
                return;
            }

            if (stock < 0 || minimumStock < 0 || maximumStock < 0) {
                toast.show('Stock quantities cannot be negative.', 'error');
                return;
            }

            if (minimumStock > maximumStock) {
                toast.show('Minimum stock cannot be greater than maximum stock.', 'error');
                return;
            }

            try {
                // Prepare product data
                const promoSrpRaw = document.getElementById('p_promoSrp')?.value?.trim() || '';
                const promoStartDate = document.getElementById('p_promoStart')?.value || '';
                const promoEndDate = document.getElementById('p_promoEnd')?.value || '';
                let promoSrp = promoSrpRaw === '' ? null : parseFloat(promoSrpRaw);
                if (promoSrpRaw !== '' && (isNaN(promoSrp) || promoSrp < 0)) {
                    toast.show('Promo SRP must be a valid non-negative number.', 'error');
                    return;
                }
                if (promoSrp != null && promoSrp > 0 && srp > 0 && promoSrp >= srp) {
                    toast.show('Promo SRP should be lower than regular SRP.', 'error');
                    return;
                }
                if ((promoStartDate && !promoEndDate) || (!promoStartDate && promoEndDate)) {
                    toast.show('Provide both promo start and end dates, or leave both empty.', 'error');
                    return;
                }
                if (promoStartDate && promoEndDate && promoStartDate > promoEndDate) {
                    toast.show('Promo start date cannot be after end date.', 'error');
                    return;
                }

                const productData = {
                    name,
                    sku,
                    category,
                    unit,
                    batchNumber,
                    costingPrice,
                    srp,
                    price: costingPrice, // Keep for backward compatibility
                    promoSrp: promoSrp,
                    promoStartDate: promoStartDate || null,
                    promoEndDate: promoEndDate || null,
                    stock,
                    minimumStock,
                    maximumStock,
                    reorderLevel: minimumStock, // Keep for backward compatibility
                    status,
                    description,
                    manufacturingDate: manufacturingDate || null,
                    expirationDate,
                    image: imagePath,
                    archived: false,
                    lastUpdated: new Date().toISOString()
                };

                let result;
                if (isEdit) {
                    result = await dataService.update('products', originalProduct.id, productData);
                    toast.show('Product updated!', 'success');
                } else {
                    result = await dataService.create('products', productData);
                    toast.show('Product added!', 'success');
                }
                
                // Explicitly close the modal first
                modal.close();
                
                // Reload the data immediately
                await loadProducts();
                
            } catch (error) {
                console.error("Submit Error:", error);
                toast.show('Failed to save product. Check console for details.', 'error');
            }
        }
    });

    // Handle image upload after modal is opened
    setTimeout(() => {
        const uploadBtn = document.getElementById('uploadImageBtn');
        const fileInput = document.getElementById('p_image');
        const imagePreview = document.getElementById('imagePreview');
        const imagePathInput = document.getElementById('p_image_path');

        uploadBtn?.addEventListener('click', () => fileInput.click());

        fileInput?.addEventListener('change', async (e) => {
            const file = e.target.files[0];
            if (!file) return;

            // Validate file type
            if (!file.type.startsWith('image/')) {
                toast.show('Please select an image file.', 'error');
                return;
            }

            // Validate file size (5MB)
            if (file.size > 5 * 1024 * 1024) {
                toast.show('Image size must be less than 5MB.', 'error');
                return;
            }

            // Show uploading state
            uploadBtn.textContent = '⏳ Uploading...';
            uploadBtn.disabled = true;

            try {
                // Upload image
                const formData = new FormData();
                formData.append('image', file);
                formData.append('type', 'product');

                const response = await fetch('api/upload-image.php', {
                    method: 'POST',
                    body: formData
                });

                const result = await response.json();

                if (!result.success) {
                    throw new Error(result.error || 'Upload failed');
                }

                // Update preview and hidden input
                imagePathInput.value = result.data.path;
                imagePreview.innerHTML = `<img src="${result.data.url}" style="max-width:200px; max-height:200px; border-radius:6px;">`;
                
                toast.show('Image uploaded successfully!', 'success');

            } catch (error) {
                console.error('Upload error:', error);
                toast.show('Failed to upload image: ' + error.message, 'error');
            } finally {
                uploadBtn.textContent = '📷 Upload Product Image';
                uploadBtn.disabled = false;
            }
        });
    }, 100);
}

async function confirmArchiveToggle(rowData) {
    const isRestoring = !!rowData.archived;
    const title = isRestoring ? `Restore ${rowData.name}?` : `Archive ${rowData.name}?`;
    const bodyText = isRestoring
        ? `This will restore <strong style="color:var(--text-primary);">${rowData.name}</strong> back into the active catalog.`
        : `This will move <strong style="color:var(--text-primary);">${rowData.name}</strong> to the archive. It will be hidden from the active catalog but not permanently deleted, and can be restored anytime.`;

    modal.open(title, `<p style="color:var(--text-secondary); font-size:0.95rem;">${bodyText}</p>`, {
        confirmText: isRestoring ? 'Restore' : 'Archive',
        onConfirm: async () => {
            try {
                await dataService.update('products', rowData.id, {
                    archived: !isRestoring,
                    archivedAt: !isRestoring ? new Date().toISOString() : null,
                    archivedBy: !isRestoring ? (store.getState().user?.name || 'System') : null,
                    lastUpdated: new Date().toISOString()
                });
                toast.show(isRestoring ? 'Product restored.' : 'Product archived.', 'info');
                modal.close();
                await loadProducts();
            } catch (error) {
                toast.show(`Failed to ${isRestoring ? 'restore' : 'archive'} product.`, 'error');
            }
        }
    });
}


// --- Active SRP helper (regular vs promo) ---
function isPromoActive(p) {
    if (p.promoSrp == null || p.promoSrp === '' || Number(p.promoSrp) <= 0) return false;
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const start = p.promoStartDate ? new Date(p.promoStartDate) : null;
    const end = p.promoEndDate ? new Date(p.promoEndDate) : null;
    if (start) start.setHours(0, 0, 0, 0);
    if (end) end.setHours(0, 0, 0, 0);
    if (start && today < start) return false;
    if (end && today > end) return false;
    // If no dates but promoSrp set, treat as active
    return true;
}

function formatActiveSrp(p) {
    if (isPromoActive(p)) {
        return `<span style="text-decoration:line-through;color:var(--text-secondary);font-size:0.8rem;margin-right:4px;">₱${formatCurrency(p.srp || 0)}</span><span style="color:#DC2626;font-weight:700;">₱${formatCurrency(p.promoSrp)}</span> <span style="background:#FEE2E2;color:#991B1B;font-size:0.65rem;padding:1px 5px;border-radius:4px;font-weight:600;">PROMO</span>`;
    }
    return p.srp ? `₱${formatCurrency(p.srp)}` : '<span style="color:var(--text-secondary);">—</span>';
}

// --- PROMO PRICING MANAGER ---
async function openPromoPricingManager() {
    let products = [];
    try {
        products = await dataService.findAll('products');
        products = products.filter(p => !p.archived);
    } catch (e) {
        toast.show('Failed to load products.', 'error');
        return;
    }

    const rows = products.map(p => {
        const active = isPromoActive(p);
        return `
        <tr data-id="${p.id}" style="border-bottom:1px solid var(--border-color);">
            <td style="padding:10px 12px; font-size:0.85rem;">${Sanitizer.sanitizeString(p.name || '')}<br><span style="color:var(--text-secondary);font-size:0.75rem;">${Sanitizer.sanitizeString(p.sku || '')}</span></td>
            <td style="padding:10px 12px; font-size:0.85rem;">₱${formatCurrency(p.srp || 0)}</td>
            <td style="padding:10px 12px;"><input type="number" step="0.01" min="0" class="form-input promo-srp-input" data-id="${p.id}" value="${p.promoSrp ?? ''}" style="width:100%; max-width:100%; box-sizing:border-box; padding:6px 8px; font-size:0.85rem;" placeholder="—"></td>
            <td style="padding:10px 12px;"><input type="date" class="form-input promo-start-input" data-id="${p.id}" value="${p.promoStartDate || ''}" style="width:100%; max-width:100%; box-sizing:border-box; padding:6px 8px; font-size:0.8rem;"></td>
            <td style="padding:10px 12px;"><input type="date" class="form-input promo-end-input" data-id="${p.id}" value="${p.promoEndDate || ''}" style="width:100%; max-width:100%; box-sizing:border-box; padding:6px 8px; font-size:0.8rem;"></td>
            <td style="padding:10px 12px;">${active ? '<span style="background:#DCFCE7;color:#166534;padding:3px 8px;border-radius:6px;font-size:0.75rem;font-weight:600;">ACTIVE</span>' : (p.promoSrp ? '<span style="background:#FEF3C7;color:#92400E;padding:3px 8px;border-radius:6px;font-size:0.75rem;font-weight:600;">SCHEDULED</span>' : '<span style="color:var(--text-secondary);font-size:0.8rem;">—</span>')}</td>
        </tr>`;
    }).join('');

    const html = `
        <div style="margin-bottom:12px;">
            <p style="color:var(--text-secondary); font-size:0.9rem;">Set promotional SRP and date ranges. Active promos show the discounted price across the catalog and inventory views.</p>
        </div>
        <div style="width:100%; border:1px solid var(--border-color); border-radius:10px; overflow:hidden;">
            <table style="width:100%; border-collapse:collapse; font-size:0.85rem; table-layout:fixed;">
                <thead style="background:var(--bg-gray);">
                    <tr>
                        <th style="padding:10px 12px; text-align:left; font-size:0.75rem; text-transform:uppercase; color:var(--text-secondary); width:28%;">Product</th>
                        <th style="padding:10px 12px; text-align:left; font-size:0.75rem; text-transform:uppercase; color:var(--text-secondary); width:12%;">Regular SRP</th>
                        <th style="padding:10px 12px; text-align:left; font-size:0.75rem; text-transform:uppercase; color:var(--text-secondary); width:14%;">Promo SRP</th>
                        <th style="padding:10px 12px; text-align:left; font-size:0.75rem; text-transform:uppercase; color:var(--text-secondary); width:16%;">Start</th>
                        <th style="padding:10px 12px; text-align:left; font-size:0.75rem; text-transform:uppercase; color:var(--text-secondary); width:16%;">End</th>
                        <th style="padding:10px 12px; text-align:left; font-size:0.75rem; text-transform:uppercase; color:var(--text-secondary); width:14%;">Status</th>
                    </tr>
                </thead>
                <tbody>${rows || '<tr><td colspan="6" style="padding:24px; text-align:center; color:var(--text-secondary);">No products</td></tr>'}</tbody>
            </table>
        </div>
    `;

    modal.open('Promo Pricing — Manage SRP', html, {
        width: '920px',
        singleScroll: true,
        confirmText: 'Save Promos',
        onConfirm: async () => {
            const updates = [];
            document.querySelectorAll('.promo-srp-input').forEach(inp => {
                const id = inp.dataset.id;
                const promoSrpRaw = inp.value.trim();
                const start = document.querySelector(`.promo-start-input[data-id="${id}"]`)?.value || '';
                const end = document.querySelector(`.promo-end-input[data-id="${id}"]`)?.value || '';
                let promoSrp = promoSrpRaw === '' ? null : parseFloat(promoSrpRaw);
                if (promoSrpRaw !== '' && isNaN(promoSrp)) {
                    toast.show('Invalid promo SRP value.', 'error');
                    return;
                }
                updates.push({ id, promoSrp, promoStartDate: start || null, promoEndDate: end || null });
            });

            try {
                for (const u of updates) {
                    await dataService.update('products', u.id, {
                        promoSrp: u.promoSrp,
                        promoStartDate: u.promoStartDate,
                        promoEndDate: u.promoEndDate,
                        lastUpdated: new Date().toISOString()
                    });
                }
                toast.show('Promo pricing saved.', 'success');
                await loadProducts();
            } catch (err) {
                console.error(err);
                toast.show('Failed to save some promos.', 'error');
            }
        }
    });
}

// --- SEASONAL EVENTS PRODUCT SUGGESTIONS ---
const SEASONAL_EVENTS = [
    {
        id: 'new-year',
        name: 'New Year',
        months: [1],
        emoji: '🎆',
        categories: ['Beverages', 'Snacks', 'Specialty Items'],
        tips: ['Stock party packs and beverages', 'Highlight specialty gift items', 'Bundle instant noodles for gatherings']
    },
    {
        id: 'chinese-new-year',
        name: 'Chinese New Year / Lunar New Year',
        months: [1, 2],
        emoji: '🧧',
        categories: ['Rice & Pantry', 'Specialty Items', 'Sauces & Condiments', 'Snacks'],
        tips: ['Push specialty and pantry staples', 'Gift-ready snack packs', 'Sauces for festive cooking']
    },
    {
        id: 'valentines',
        name: "Valentine's Day",
        months: [2],
        emoji: '💝',
        categories: ['Snacks', 'Beverages', 'Specialty Items'],
        tips: ['Sweet snacks and specialty gifts', 'Beverage pairings']
    },
    {
        id: 'summer',
        name: 'Summer / Hot Season',
        months: [3, 4, 5],
        emoji: '☀️',
        categories: ['Beverages', 'Frozen Foods', 'Snacks', 'Kimchi & Pickled'],
        tips: ['Increase cold beverages and frozen foods', 'Light snacks and kimchi for hot weather']
    },
    {
        id: 'back-to-school',
        name: 'Back to School',
        months: [6, 7],
        emoji: '📚',
        categories: ['Instant Noodles', 'Snacks', 'Beverages', 'Rice & Pantry'],
        tips: ['Ready-to-eat noodles for students', 'Affordable snack packs', 'Pantry essentials']
    },
    {
        id: 'mid-autumn',
        name: 'Mid-Autumn Festival',
        months: [9],
        emoji: '🌕',
        categories: ['Specialty Items', 'Snacks', 'Rice & Pantry'],
        tips: ['Specialty festive items', 'Gift snack assortments']
    },
    {
        id: 'halloween',
        name: 'Halloween',
        months: [10],
        emoji: '🎃',
        categories: ['Snacks', 'Beverages', 'Specialty Items'],
        tips: ['Fun snack packs', 'Party beverages']
    },
    {
        id: 'christmas',
        name: 'Christmas / Holiday Season',
        months: [11, 12],
        emoji: '🎄',
        categories: ['Specialty Items', 'Snacks', 'Beverages', 'Sauces & Condiments', 'Frozen Foods'],
        tips: ['Gift-oriented specialty products', 'Holiday cooking sauces', 'Party snacks and drinks', 'Frozen ready meals']
    },
    {
        id: 'rainy',
        name: 'Rainy Season',
        months: [6, 7, 8, 9, 10],
        emoji: '🌧️',
        categories: ['Instant Noodles', 'Sauces & Condiments', 'Rice & Pantry', 'Frozen Foods'],
        tips: ['Comfort food: instant noodles', 'Warm pantry staples', 'Ready sauces for home cooking']
    }
];

async function openSeasonalSuggestions() {
    let products = [];
    try {
        products = await dataService.findAll('products');
        products = products.filter(p => !p.archived);
    } catch (e) {
        toast.show('Failed to load products.', 'error');
        return;
    }

    const now = new Date();
    const month = now.getMonth() + 1; // 1-12
    const currentEvents = SEASONAL_EVENTS.filter(e => e.months.includes(month));
    const otherEvents = SEASONAL_EVENTS.filter(e => !e.months.includes(month));

    const buildEventCard = (ev, isCurrent) => {
        const matched = products.filter(p => ev.categories.includes(p.category));
        const byCat = {};
        matched.forEach(p => {
            byCat[p.category] = byCat[p.category] || [];
            byCat[p.category].push(p);
        });
        const lowStock = matched.filter(p => parseFloat(p.stock || 0) <= parseFloat(p.minimumStock || p.reorderLevel || 10));
        const expiring = matched.filter(p => {
            if (!p.expirationDate) return false;
            const d = Math.ceil((new Date(p.expirationDate) - now) / 86400000);
            return d >= 0 && d <= 45;
        });

        const catBlocks = Object.entries(byCat).map(([cat, list]) => {
            const names = list.map(p => {
                const stock = parseFloat(p.stock || 0);
                const low = stock <= parseFloat(p.minimumStock || p.reorderLevel || 10);
                return `<li style="margin-bottom:4px;">${Sanitizer.sanitizeString(p.name)} <span style="color:var(--text-secondary);font-size:0.75rem;">(${stock} ${p.unit || 'pcs'})</span>${low ? ' <span style="color:#DC2626;font-size:0.7rem;font-weight:600;">LOW</span>' : ''}</li>`;
            }).join('');
            return `<div style="margin-bottom:10px;"><strong style="font-size:0.8rem;color:var(--primary-red);">${cat}</strong> <span style="font-size:0.75rem;color:var(--text-secondary);">(${list.length})</span><ul style="margin:4px 0 0 16px;padding:0;font-size:0.85rem;">${names}</ul></div>`;
        }).join('') || '<p style="color:var(--text-secondary);font-size:0.85rem;">No catalog products in suggested categories yet.</p>';

        return `
        <div style="border:1px solid var(--border-color); border-radius:12px; padding:16px; background:${isCurrent ? 'linear-gradient(135deg,#FEF2F2 0%,#fff 60%)' : 'var(--bg-white)'}; ${isCurrent ? 'border-color:#FECACA;' : ''}">
            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:10px;">
                <h3 style="margin:0; font-size:1rem;">${ev.emoji} ${ev.name}</h3>
                ${isCurrent ? '<span style="background:#DC2626;color:white;font-size:0.7rem;padding:3px 8px;border-radius:6px;font-weight:600;">NOW</span>' : ''}
            </div>
            <p style="font-size:0.8rem; color:var(--text-secondary); margin-bottom:8px;">Suggested categories: <strong>${ev.categories.join(', ')}</strong></p>
            <ul style="margin:0 0 12px 16px; padding:0; font-size:0.8rem; color:var(--text-secondary);">
                ${ev.tips.map(t => `<li>${t}</li>`).join('')}
            </ul>
            ${lowStock.length ? `<p style="font-size:0.8rem; color:#B45309; margin-bottom:8px;"><strong>${lowStock.length}</strong> suggested product(s) are low stock — consider restocking before the peak.</p>` : ''}
            ${expiring.length ? `<p style="font-size:0.8rem; color:#DC2626; margin-bottom:8px;"><strong>${expiring.length}</strong> suggested product(s) expire within 45 days — prioritize these for seasonal promos.</p>` : ''}
            <div style="background:var(--bg-gray); border-radius:8px; padding:12px;">
                ${catBlocks}
            </div>
        </div>`;
    };

    const html = `
        <div style="margin-bottom:14px;">
            <p style="color:var(--text-secondary); font-size:0.9rem;">Product suggestions based on seasonal events. Prioritize stocking and promo pricing for categories that match the current season.</p>
            <p style="font-size:0.8rem; color:var(--text-muted); margin-top:4px;">Today: ${now.toLocaleDateString(undefined, { month: 'long', year: 'numeric' })}</p>
        </div>
        <div style="display:flex; flex-direction:column; gap:14px; width:100%;">
            ${currentEvents.length ? currentEvents.map(e => buildEventCard(e, true)).join('') : '<p style="color:var(--text-secondary);">No primary seasonal event flagged for this month — see upcoming below.</p>'}
            <h4 style="margin:8px 0 0; font-size:0.9rem; color:var(--text-secondary);">Other / Upcoming</h4>
            ${otherEvents.map(e => buildEventCard(e, false)).join('')}
        </div>
    `;

    modal.open('Seasonal Events — Product Suggestions', html, {
        width: '720px',
        confirmText: 'Close',
        hideCancel: true,
        onConfirm: () => {}
    });
}
