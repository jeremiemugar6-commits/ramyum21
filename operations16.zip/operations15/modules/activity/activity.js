/**
 * Recent Activity Module
 * Full detailed view of all system activity (inventory, transfers, security).
 */
import { store } from '../../assets/js/store.js';
import { toast } from '../../assets/js/components/toast.js';
import { modal } from '../../assets/js/components/modal.js';

let allActivities = [];
let currentFilter = 'all';
let currentSearch = '';

export async function renderRecentActivity() {
    const container = document.getElementById('appContent');
    if (!container) return;

    container.innerHTML = `
        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:26px; flex-wrap:wrap; gap:16px; background:var(--bg-card); padding:22px 26px; border-radius:12px; border:1px solid var(--border-color); box-shadow:var(--shadow-sm);">
            <div>
                <h1 class="page-title">Recent Activity</h1>
                <p class="page-subtitle">Complete timeline of inventory movements, stock transfers, and security events.</p>
            </div>
            <button id="refreshActivityBtn" class="btn btn-secondary" style="display:flex; align-items:center; gap:8px;">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M23 4v6h-6M1 20v-6h6"/><path d="M3.51 9a9 9 0 0114.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0020.49 15"/></svg>
                Refresh
            </button>
        </div>

        <!-- Summary Cards -->
        <div id="activitySummary" style="display:grid; grid-template-columns:repeat(auto-fit, minmax(180px, 1fr)); gap:16px; margin-bottom:24px;">
            <div class="card" style="padding:18px 20px; cursor:pointer;" data-filter="all">
                <div style="font-size:0.8rem; color:var(--text-secondary); font-weight:600; text-transform:uppercase; letter-spacing:0.04em;">All Events</div>
                <div id="sumTotal" style="font-size:1.75rem; font-weight:700; color:var(--text-primary); margin-top:4px;">—</div>
            </div>
            <div class="card" style="padding:18px 20px; cursor:pointer;" data-filter="inventory">
                <div style="font-size:0.8rem; color:var(--text-secondary); font-weight:600; text-transform:uppercase; letter-spacing:0.04em;">Inventory</div>
                <div id="sumInventory" style="font-size:1.75rem; font-weight:700; color:#10B981; margin-top:4px;">—</div>
            </div>
            <div class="card" style="padding:18px 20px; cursor:pointer;" data-filter="transfer">
                <div style="font-size:0.8rem; color:var(--text-secondary); font-weight:600; text-transform:uppercase; letter-spacing:0.04em;">Transfers</div>
                <div id="sumTransfer" style="font-size:1.75rem; font-weight:700; color:#3B82F6; margin-top:4px;">—</div>
            </div>
            <div class="card" style="padding:18px 20px; cursor:pointer;" data-filter="security">
                <div style="font-size:0.8rem; color:var(--text-secondary); font-weight:600; text-transform:uppercase; letter-spacing:0.04em;">Security</div>
                <div id="sumSecurity" style="font-size:1.75rem; font-weight:700; color:#8B5CF6; margin-top:4px;">—</div>
            </div>
        </div>

        <!-- Filters -->
        <div class="card" style="padding:16px 20px; margin-bottom:20px;">
            <div style="display:flex; flex-wrap:wrap; gap:12px; align-items:center;">
                <div style="display:flex; gap:6px; flex-wrap:wrap;">
                    <button class="filter-chip active" data-type="all">All</button>
                    <button class="filter-chip" data-type="inventory">Inventory</button>
                    <button class="filter-chip" data-type="transfer">Transfers</button>
                    <button class="filter-chip" data-type="security">Security</button>
                </div>
                <div style="flex:1; min-width:200px;">
                    <input type="text" id="activitySearch" class="form-input" placeholder="Search by product, user, reference, type..." style="width:100%;">
                </div>
                <div style="display:flex; gap:8px; align-items:center;">
                    <input type="date" id="activitySince" class="form-input" style="width:auto;" title="From date">
                    <span style="color:var(--text-muted);">to</span>
                    <input type="date" id="activityUntil" class="form-input" style="width:auto;" title="To date">
                </div>
            </div>
        </div>

        <!-- Timeline / List -->
        <div class="card" style="padding:0; overflow:hidden;">
            <div id="activityList" style="max-height:calc(100vh - 380px); overflow-y:auto; min-height:320px;">
                <div style="display:flex; align-items:center; justify-content:center; padding:60px; color:var(--text-muted);">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="animation:spin 1s linear infinite; margin-right:10px;"><path d="M21 12a9 9 0 11-18 0 9 9 0 0118 0z" opacity=".3"/><path d="M21 12a9 9 0 00-9-9"/></svg>
                    Loading activity...
                </div>
            </div>
        </div>

        <style>
            .filter-chip {
                padding: 6px 14px;
                border-radius: 20px;
                border: 1px solid var(--border-color);
                background: var(--bg-card);
                color: var(--text-secondary);
                font-size: 0.85rem;
                font-weight: 500;
                cursor: pointer;
                transition: all 0.15s;
            }
            .filter-chip:hover { border-color: var(--primary-orange); color: var(--primary-orange); }
            .filter-chip.active {
                background: linear-gradient(135deg, var(--primary-orange), var(--primary-red));
                color: #fff;
                border-color: transparent;
            }
            .activity-item {
                display: flex;
                gap: 14px;
                padding: 16px 20px;
                border-bottom: 1px solid var(--border-color);
                cursor: pointer;
                transition: background 0.15s;
            }
            .activity-item:hover { background: var(--bg-gray); }
            .activity-item:last-child { border-bottom: none; }
            .activity-icon {
                width: 42px;
                height: 42px;
                border-radius: 10px;
                display: flex;
                align-items: center;
                justify-content: center;
                flex-shrink: 0;
                font-size: 18px;
            }
            .activity-body { flex: 1; min-width: 0; }
            .activity-title {
                font-weight: 600;
                color: var(--text-primary);
                font-size: 0.95rem;
                margin-bottom: 3px;
                white-space: nowrap;
                overflow: hidden;
                text-overflow: ellipsis;
            }
            .activity-desc {
                font-size: 0.85rem;
                color: var(--text-secondary);
                margin-bottom: 4px;
                display: -webkit-box;
                -webkit-line-clamp: 2;
                -webkit-box-orient: vertical;
                overflow: hidden;
            }
            .activity-meta {
                font-size: 0.78rem;
                color: var(--text-muted);
                display: flex;
                flex-wrap: wrap;
                gap: 10px;
            }
            .activity-badge {
                display: inline-block;
                padding: 2px 8px;
                border-radius: 6px;
                font-size: 0.72rem;
                font-weight: 600;
                text-transform: uppercase;
                letter-spacing: 0.03em;
            }
            @keyframes spin { to { transform: rotate(360deg); } }
        </style>
    `;

    // Event listeners
    document.getElementById('refreshActivityBtn')?.addEventListener('click', () => loadActivities(true));

    document.querySelectorAll('.filter-chip').forEach(btn => {
        btn.addEventListener('click', () => {
            document.querySelectorAll('.filter-chip').forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            currentFilter = btn.dataset.type;
            loadActivities();
        });
    });

    document.querySelectorAll('#activitySummary .card').forEach(card => {
        card.addEventListener('click', () => {
            const f = card.dataset.filter;
            document.querySelectorAll('.filter-chip').forEach(b => {
                b.classList.toggle('active', b.dataset.type === f);
            });
            currentFilter = f;
            loadActivities();
        });
    });

    let searchTimeout;
    document.getElementById('activitySearch')?.addEventListener('input', (e) => {
        clearTimeout(searchTimeout);
        searchTimeout = setTimeout(() => {
            currentSearch = e.target.value.trim();
            loadActivities();
        }, 300);
    });

    document.getElementById('activitySince')?.addEventListener('change', () => loadActivities());
    document.getElementById('activityUntil')?.addEventListener('change', () => loadActivities());

    await loadActivities();
}

async function loadActivities(showToast = false) {
    const listEl = document.getElementById('activityList');
    if (!listEl) return;

    listEl.innerHTML = `
        <div style="display:flex; align-items:center; justify-content:center; padding:60px; color:var(--text-muted);">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="animation:spin 1s linear infinite; margin-right:10px;"><path d="M21 12a9 9 0 11-18 0 9 9 0 0118 0z" opacity=".3"/><path d="M21 12a9 9 0 00-9-9"/></svg>
            Loading activity...
        </div>
    `;

    const params = new URLSearchParams({ limit: '200', type: currentFilter });
    if (currentSearch) params.set('search', currentSearch);
    const since = document.getElementById('activitySince')?.value;
    const until = document.getElementById('activityUntil')?.value;
    if (since) params.set('since', since);
    if (until) params.set('until', until);

    try {
        const res = await fetch(`api/recent-activity.php?${params.toString()}`);
        const result = await res.json();

        if (!result.success) {
            throw new Error(result.error || 'Failed to load activity');
        }

        allActivities = result.data || [];
        const summary = result.summary || {};

        // Update summary cards
        document.getElementById('sumTotal').textContent = summary.total ?? allActivities.length;
        document.getElementById('sumInventory').textContent = summary.inventory ?? 0;
        document.getElementById('sumTransfer').textContent = summary.transfer ?? 0;
        document.getElementById('sumSecurity').textContent = summary.security ?? 0;

        renderActivityList(allActivities);

        if (showToast) toast.show('Activity refreshed', 'success');
    } catch (err) {
        console.error(err);
        listEl.innerHTML = `
            <div style="text-align:center; padding:48px 20px; color:var(--text-secondary);">
                <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" style="margin:0 auto 12px; opacity:0.35;"><circle cx="12" cy="12" r="10"/><path d="M12 8v4M12 16h.01"/></svg>
                <p style="margin-bottom:8px;">Failed to load activity.</p>
                <p style="font-size:0.85rem; color:var(--text-muted);">${err.message || 'Please try again.'}</p>
            </div>
        `;
        if (showToast) toast.show('Failed to refresh activity', 'error');
    }
}

function renderActivityList(activities) {
    const listEl = document.getElementById('activityList');
    if (!listEl) return;

    if (activities.length === 0) {
        listEl.innerHTML = `
            <div style="text-align:center; padding:48px 20px; color:var(--text-secondary);">
                <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" style="margin:0 auto 12px; opacity:0.35;">
                    <path d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"/>
                </svg>
                <p style="margin-bottom:4px; font-weight:600;">No activity found</p>
                <p style="font-size:0.85rem; color:var(--text-muted);">Try adjusting filters or date range.</p>
            </div>
        `;
        return;
    }

    const iconMap = {
        inventory: '📦',
        transfer:  '🔄',
        security:  '🛡️',
    };

    const categoryColors = {
        inventory: { bg: 'rgba(16,185,129,0.12)', text: '#059669' },
        transfer:  { bg: 'rgba(59,130,246,0.12)', text: '#2563EB' },
        security:  { bg: 'rgba(139,92,246,0.12)', text: '#7C3AED' },
    };

    listEl.innerHTML = activities.map((a, idx) => {
        const icon = iconMap[a.category] || '📋';
        const catStyle = categoryColors[a.category] || { bg: 'rgba(107,114,128,0.12)', text: '#4B5563' };
        const timeStr = formatRelativeTime(a.created_at);
        const fullTime = new Date(a.created_at).toLocaleString();

        return `
            <div class="activity-item" data-idx="${idx}">
                <div class="activity-icon" style="background:${a.color || catStyle.text}22; color:${a.color || catStyle.text};">
                    ${icon}
                </div>
                <div class="activity-body">
                    <div class="activity-title">${escapeHtml(a.title)}</div>
                    <div class="activity-desc">${escapeHtml(a.description || '')}</div>
                    <div class="activity-meta">
                        <span class="activity-badge" style="background:${catStyle.bg}; color:${catStyle.text};">${a.category}</span>
                        ${a.user ? `<span>👤 ${escapeHtml(a.user)}</span>` : ''}
                        <span title="${fullTime}">🕒 ${timeStr}</span>
                    </div>
                </div>
                <div style="display:flex; align-items:center; color:var(--text-muted);">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 18l6-6-6-6"/></svg>
                </div>
            </div>
        `;
    }).join('');

    listEl.querySelectorAll('.activity-item').forEach(el => {
        el.addEventListener('click', () => {
            const idx = parseInt(el.dataset.idx, 10);
            showActivityDetail(activities[idx]);
        });
    });
}

function showActivityDetail(activity) {
    if (!activity) return;

    const details = activity.details || {};
    const rows = [];

    // Common fields
    rows.push(['Event Type', activity.type]);
    rows.push(['Category', activity.category]);
    rows.push(['Title', activity.title]);
    if (activity.description) rows.push(['Description', activity.description]);
    if (activity.user) rows.push(['User', activity.user]);
    rows.push(['Timestamp', new Date(activity.created_at).toLocaleString()]);
    rows.push(['Record ID', activity.id]);

    // Extra detail fields (skip already shown)
    const skipKeys = new Set(['id', 'type', 'productName', 'user', 'date', 'created_at']);
    Object.entries(details).forEach(([k, v]) => {
        if (skipKeys.has(k) || v === null || v === undefined || v === '') return;
        const label = k.replace(/([A-Z])/g, ' $1').replace(/_/g, ' ').replace(/^\w/, c => c.toUpperCase());
        let val = v;
        if (typeof v === 'object') val = JSON.stringify(v, null, 2);
        rows.push([label, String(val)]);
    });

    const tableHtml = rows.map(([label, val]) => `
        <tr>
            <td style="padding:10px 14px; font-weight:600; color:var(--text-secondary); width:160px; vertical-align:top; white-space:nowrap;">${escapeHtml(label)}</td>
            <td style="padding:10px 14px; color:var(--text-primary); word-break:break-word;"><pre style="margin:0; font-family:inherit; white-space:pre-wrap; font-size:0.9rem;">${escapeHtml(String(val))}</pre></td>
        </tr>
    `).join('');

    const bodyHTML = `
        <table style="width:100%; border-collapse:collapse; font-size:0.9rem;">
            <tbody>
                ${tableHtml}
            </tbody>
        </table>
    `;

    modal.open('Activity Detail', bodyHTML, {
        hideFooter: true,
        width: 640,
    });
}

function formatRelativeTime(dateStr) {
    const date = new Date(dateStr);
    const now = new Date();
    const diffMs = now - date;
    const diffSec = Math.floor(diffMs / 1000);
    const diffMin = Math.floor(diffSec / 60);
    const diffHr  = Math.floor(diffMin / 60);
    const diffDay = Math.floor(diffHr / 24);

    if (diffSec < 60) return 'Just now';
    if (diffMin < 60) return `${diffMin} min ago`;
    if (diffHr < 24)  return `${diffHr} hour${diffHr > 1 ? 's' : ''} ago`;
    if (diffDay < 7)  return `${diffDay} day${diffDay > 1 ? 's' : ''} ago`;
    return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
}

function escapeHtml(str) {
    if (str == null) return '';
    return String(str)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#39;');
}
