import { DataService } from '../../assets/js/utils/data-service.js';
import { Validator } from '../../assets/js/utils/validator.js';
import { toast } from '../../assets/js/components/toast.js';
import { modal } from '../../assets/js/components/modal.js';
import { DataTable } from '../../assets/js/components/table.js';
import { store } from '../../assets/js/store.js';
import { formatCurrency, formatQuantity } from '../../assets/js/utils/format.js';
import { BadgeHelper } from '../../assets/js/utils/badge-helper.js';

const dataService = new DataService();

// Demo Integration Mode Configuration
let demoConfig = null;

async function loadDemoConfig() {
    if (!demoConfig) {
        try {
            const response = await fetch('api/demo-config.php');
            const result = await response.json();
            demoConfig = result.success ? result.data : { demoMode: false, demoMessage: '' };
        } catch (error) {
            console.warn('Could not load demo config:', error);
            demoConfig = { demoMode: false, demoMessage: '' };
        }
    }
    return demoConfig;
}

// --- RENDER FUNCTION ---
export async function renderInventory() {
    const container = document.getElementById('appContent');
    const userRole = store.getState().role;
    const canAdjust = userRole === 'admin' || userRole === 'manager';
    
    // Load demo configuration
    const config = await loadDemoConfig();

    container.innerHTML = `
        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:26px; flex-wrap:wrap; gap:16px; background:var(--bg-card); padding:22px 26px; border-radius:12px; border:1px solid var(--border-color); box-shadow:var(--shadow-sm);">
            <div>
                <h1 class="page-title">Inventory Management</h1>
                <p class="page-subtitle">Monitor stock levels, track movements, and manage inventory adjustments.</p>
                ${config.demoMode ? BadgeHelper.getDemoIndicator('Stock updates from receiving are processed locally for demonstration.') : ''}
            </div>
            <div style="display:flex; gap:8px;">
                ${canAdjust ? `<button id="adjustStockBtn" class="btn-primary">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M7 7h10v10M7 17L17 7"/></svg>
                    Adjust Stock
                </button>` : ''}
                <button id="viewMovementsBtn" class="btn-secondary">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2"/></svg>
                    Stock Movements
                </button>
            </div>
        </div>

        <!-- Navigation Tabs -->
        <div style="display:flex; gap:8px; margin-bottom:16px; border-bottom:1px solid var(--border-color); padding-bottom:12px; flex-wrap:wrap;">
            <button class="view-tab active" data-view="current-stock" style="padding:8px 16px; background:transparent; border:none; border-bottom:2px solid var(--primary-red); color:var(--primary-red); font-weight:500; cursor:pointer;">Current Stock</button>
            <button class="view-tab" data-view="expiring" style="padding:8px 16px; background:transparent; border:none; color:var(--text-secondary); cursor:pointer;">Expiration Bridge</button>
            <button class="view-tab" data-view="movements" style="padding:8px 16px; background:transparent; border:none; color:var(--text-secondary); cursor:pointer;">Stock Movements</button>
        </div>

        <div id="inventoryViewContainer">
            <!-- Stock Summary Cards -->
            <div class="grid-4" id="stockSummary">
                <div class="stat-card" style="border-left:4px solid #10B981;">
                    <span class="stat-label">Total Items</span>
                    <span class="stat-value" id="totalItems">0</span>
                </div>
                <div class="stat-card" style="border-left:4px solid #3B82F6;">
                    <span class="stat-label">Stock Value</span>
                    <span class="stat-value" id="totalValue">₱0.00</span>
                </div>
                <div class="stat-card" style="border-left:4px solid #F59E0B;">
                    <span class="stat-label">Low Stock Items</span>
                    <span class="stat-value" style="color:#D97706;" id="lowStockCount">0</span>
                </div>
                <div class="stat-card" style="border-left:4px solid #EF4444;">
                    <span class="stat-label">Out of Stock</span>
                    <span class="stat-value" style="color:#DC2626;" id="outOfStockCount">0</span>
                </div>
            </div>

            <div style="display:flex; gap:12px; margin:20px 0; flex-wrap:wrap; align-items:center;">
                <input type="text" id="inventorySearch" placeholder="Search by name, SKU, batch number..."
                    style="flex:1; min-width:200px; padding:10px 14px; border:1.5px solid var(--border-color); border-radius:10px; background:var(--bg-white); color:var(--text-primary); font-size:0.9rem; font-family:inherit; transition:border-color 0.2s;"
                    onfocus="this.style.borderColor='var(--primary-red)'" onblur="this.style.borderColor='var(--border-color)'">
                <select id="inventoryStatusFilter"
                    style="padding:10px 14px; border:1.5px solid var(--border-color); border-radius:10px; background:var(--bg-white); color:var(--text-primary); font-size:0.9rem; font-family:inherit; cursor:pointer; min-width:150px;">
                    <option value="">All Stock Status</option>
                    <option value="In Stock">In Stock</option>
                    <option value="Low Stock">Low Stock</option>
                    <option value="Out of Stock">Out of Stock</option>
                </select>
            </div>

            <div id="inventoryDataContainer"></div>
        </div>
    `;

    // Attach Tab Event Listeners
    document.querySelectorAll('.view-tab').forEach(btn => {
        btn.addEventListener('click', async (e) => {
            document.querySelectorAll('.view-tab').forEach(b => {
                b.style.borderBottom = 'none';
                b.style.color = 'var(--text-secondary)';
                b.classList.remove('active');
            });
            
            const target = e.target;
            target.style.borderBottom = '2px solid var(--primary-red)';
            target.style.color = 'var(--primary-red)';
            target.classList.add('active');

            if (target.dataset.view === 'movements') {
                await renderMovementsView();
            } else if (target.dataset.view === 'expiring') {
                await renderExpirationBridgeView();
            } else {
                await renderCurrentStockView();
            }
        });
    });

    document.getElementById('adjustStockBtn')?.addEventListener('click', () => openAdjustmentModal());
    document.getElementById('viewMovementsBtn')?.addEventListener('click', () => {
        // Switch to movements tab
        document.querySelector('[data-view="movements"]').click();
    });
    document.getElementById('inventorySearch')?.addEventListener('input', () => {
        if (currentView === 'current-stock') renderTable();
    });
    document.getElementById('inventoryStatusFilter')?.addEventListener('change', () => {
        if (currentView === 'current-stock') renderTable();
    });

    await renderCurrentStockView();
}

// --- STATE & DATA ---
let currentProducts = [];
let filteredProducts = [];
let currentMovements = [];
let currentView = 'current-stock';

// --- LOAD: FETCH DATA + STATS, THEN RENDER TABLE ---
async function renderCurrentStockView() {
    currentView = 'current-stock';
    const container = document.getElementById('inventoryViewContainer');
    
    // Show stock summary and filters, hide movements
    document.getElementById('stockSummary').style.display = 'grid';
    document.getElementById('inventorySearch').parentElement.style.display = 'flex';
    
    try {
        // Load Data - FORCE fetch from DB
        currentProducts = await dataService.findAll('products');

        // Calculate Stats (always reflect the full data set, not the filtered view)
        const totalItems = currentProducts.length;
        const totalValue = currentProducts.reduce((sum, p) => sum + (parseFloat(p.price || 0) * parseFloat(p.stock || 0)), 0);
        const lowStockItems = currentProducts.filter(p => parseFloat(p.stock || 0) <= parseFloat(p.reorderLevel || 10) && parseFloat(p.stock || 0) > 0);
        const outOfStock = currentProducts.filter(p => parseFloat(p.stock || 0) === 0);

        document.getElementById('totalItems').textContent = totalItems;
        document.getElementById('totalValue').textContent = `₱${formatCurrency(totalValue)}`;
        document.getElementById('lowStockCount').textContent = lowStockItems.length;
        document.getElementById('outOfStockCount').textContent = outOfStock.length;

        renderTable();
    } catch (error) {
        console.error('Error rendering inventory:', error);
        toast.show('Failed to load inventory data.', 'error');
    }
}

async function renderMovementsView() {
    currentView = 'movements';
    
    // Hide stock summary and filters for movements view
    document.getElementById('stockSummary').style.display = 'none';
    document.getElementById('inventorySearch').parentElement.style.display = 'none';
    
    try {
        currentMovements = await dataService.findAll('inventory_movements');
        
        // Sort by date descending (most recent first)
        currentMovements.sort((a, b) => new Date(b.date) - new Date(a.date));
        
        renderMovementsTable();
    } catch (error) {
        console.error('Error loading stock movements:', error);
        toast.show('Failed to load stock movements.', 'error');
    }
}

function renderMovementsTable() {
    const container = document.getElementById('inventoryDataContainer');
    
    if (currentMovements.length === 0) {
        container.innerHTML = `
            <div class="card" style="text-align:center; padding:40px;">
                <p style="color:var(--text-secondary); font-size:1.1rem;">No stock movements recorded yet.</p>
                <p style="color:var(--text-secondary); font-size:0.9rem;">Stock adjustments and receiving transactions will appear here.</p>
            </div>
        `;
        return;
    }
    
    const columns = [
        { key: 'date', label: 'Date' },
        { key: 'productName', label: 'Product' },
        { key: 'type', label: 'Type' },
        { key: 'change', label: 'Change' },
        { key: 'newBalance', label: 'New Balance' },
        { key: 'reference', label: 'Reference' },
        { key: 'user', label: 'User' }
    ];
    
    const formattedData = currentMovements.map(m => ({
        ...m,
        date: new Date(m.date).toLocaleString(),
        change: BadgeHelper.formatQuantity(Math.abs(m.change), m.change),
        newBalance: BadgeHelper.formatQuantity(m.newBalance),
        reference: m.referenceType === 'RECEIVING' 
            ? BadgeHelper.getReferenceTypeBadge(m.referenceType, m.referenceId)
            : BadgeHelper.getReferenceTypeBadge(m.referenceType || 'MANUAL', m.referenceId || 'Manual'),
        type: getMovementTypeBadge(m.type)
    }));
    
    container.innerHTML = `<div id="movementsTableContainer"></div>`;
    // View-only: no Edit button on stock movements (audit trail is immutable)
    new DataTable('movementsTableContainer', columns, formattedData, { 
        actions: true,
        onView: (rowData) => viewMovementDetails(rowData)
    });
}

function getMovementTypeBadge(type) {
    return BadgeHelper.getMovementTypeBadge(type);
}

function viewMovementDetails(movementData) {
    const title = `Stock Movement Details`;
    
    const bodyHTML = `
        <div style="display:grid; gap:12px; margin-bottom:16px;">
            <p><strong>Date:</strong> ${new Date(movementData.date).toLocaleString()}</p>
            <p><strong>Product:</strong> ${movementData.productName} (${movementData.sku})</p>
            <p><strong>Movement Type:</strong> ${getMovementTypeBadge(movementData.type)}</p>
            <p><strong>Quantity Change:</strong> <span style="color:${movementData.change > 0 ? '#10B981' : '#EF4444'}; font-weight:600;">${movementData.change > 0 ? '+' : ''}${movementData.change}</span></p>
            <p><strong>Previous Balance:</strong> ${formatQuantity(movementData.previousBalance)}</p>
            <p><strong>New Balance:</strong> ${formatQuantity(movementData.newBalance)}</p>
            <p><strong>Reference:</strong> ${movementData.referenceType || 'Manual'} ${movementData.referenceId ? `(${movementData.referenceId})` : ''}</p>
            ${movementData.referencePO ? `<p><strong>Purchase Order:</strong> ${movementData.referencePO}</p>` : ''}
            <p><strong>Reason:</strong> ${movementData.reason}</p>
            ${movementData.notes ? `<p><strong>Notes:</strong> ${movementData.notes}</p>` : ''}
            <p><strong>Performed By:</strong> ${movementData.user}</p>
            ${movementData.unitCost ? `<p><strong>Unit Cost:</strong> ₱${formatCurrency(movementData.unitCost)}</p>` : ''}
        </div>
    `;
    
    modal.open(title, bodyHTML, {
        confirmText: 'Close',
        onConfirm: () => modal.close()
    });
}

// --- FILTER + RENDER: CURRENT STOCK TABLE ---
function renderTable() {
    const container = document.getElementById('inventoryDataContainer');
    if (!container) return;

    const searchTerm = (document.getElementById('inventorySearch')?.value || '').toLowerCase().trim();
    const statusFilter = document.getElementById('inventoryStatusFilter')?.value || '';

    filteredProducts = currentProducts.filter(p => {
        const matchesSearch = searchTerm === '' ||
            (p.name || '').toLowerCase().includes(searchTerm) ||
            (p.sku || '').toLowerCase().includes(searchTerm) ||
            (p.batchNumber || '').toLowerCase().includes(searchTerm) ||
            (p.category || '').toLowerCase().includes(searchTerm);

        const matchesStatus = !statusFilter || getStockStatus(p.stock, p.reorderLevel) === statusFilter;

        return matchesSearch && matchesStatus;
    });

    // Render Table
    const columns = [
        { key: 'name', label: 'Product Name' },
        { key: 'sku', label: 'SKU' },
        { key: 'stock', label: 'Quantity' },
        { key: 'reorderLevel', label: 'Reorder Point' },
        { key: 'stockLevel', label: 'Stock Level' },
        { key: 'status', label: 'Stock Status' },
        { key: 'batchNumber', label: 'Batch No.' },
        { key: 'manufacturingDate', label: 'Start (Mfg)' },
        { key: 'expirationDate', label: 'End (Exp)' },
        { key: 'lastUpdated', label: 'Last Updated' }
    ];

    // Ensure stock is treated as a number (supports decimal quantities)
    const formattedData = filteredProducts.map(p => ({
        ...p,
        stock: BadgeHelper.formatQuantity(p.stock || 0),
        reorderLevel: formatQuantity(p.reorderLevel || 10),
        stockLevel: getStockLevelBadge(p.stock, p.reorderLevel),
        status: BadgeHelper.getStockStatusBadge(p.stock, p.reorderLevel),
        batchNumber: p.batchNumber
            ? `<span style="font-family:ui-monospace,monospace;font-size:0.85rem;font-weight:500;">${p.batchNumber}</span>`
            : '<span style="color:var(--text-secondary);">—</span>',
        manufacturingDate: (p.manufacturingDate || p.manufacturing_date)
            ? `<span>${p.manufacturingDate || p.manufacturing_date}</span>`
            : '<span style="color:var(--text-secondary);">—</span>',
        expirationDate: formatExpirationBadge(p.expirationDate),
        lastUpdated: p.lastUpdated ? new Date(p.lastUpdated).toLocaleDateString() : 'N/A'
    }));

    // Clear container and rebuild table to force show new item
    container.innerHTML = `<div id="stockTableContainer"></div>`;
    new DataTable('stockTableContainer', columns, formattedData, {
        actions: true,
        onEdit: (rowData) => openAdjustmentModal(rowData)
    });
}

function getStockStatus(stock, reorderLevel) {
    const qty = parseFloat(stock || 0);
    const reorder = parseInt(reorderLevel || 10);
    if (qty === 0) return 'Out of Stock';
    if (qty <= reorder) return 'Low Stock';
    return 'In Stock';
}

function getStatusBadge(stock, reorderLevel) {
    const status = getStockStatus(stock, reorderLevel);
    const styleMap = {
        'In Stock':     'background:var(--green-bg);  color:var(--green-text);',
        'Low Stock':    'background:var(--yellow-bg); color:var(--yellow-text); animation:pulse-border 1.5s infinite;',
        'Out of Stock': 'background:var(--red-bg);    color:var(--red-text);'
    };
    return `<span style="padding:3px 10px; border-radius:999px; font-size:0.75rem; font-weight:600; display:inline-block; ${styleMap[status] || ''}">${status}</span>`;
}

// --- STOCK LEVEL COLOR CODING (Low / Medium / High, relative to reorder point) ---
function getStockLevel(stock, reorderLevel) {
    const qty = parseFloat(stock || 0);
    const reorder = parseFloat(reorderLevel || 10);
    if (qty === 0) return 'None';
    if (qty <= reorder) return 'Low';
    if (qty <= reorder * 2.5) return 'Medium';
    return 'High';
}

function getStockLevelBadge(stock, reorderLevel) {
    const level = getStockLevel(stock, reorderLevel);
    const styleMap = {
        'None':   'background:#F3F4F6; color:#6B7280;',
        'Low':    'background:#FEE2E2; color:#B91C1C;',
        'Medium': 'background:#FEF3C7; color:#B45309;',
        'High':   'background:#D1FAE5; color:#047857;'
    };
    return `<span style="padding:3px 10px; border-radius:999px; font-size:0.75rem; font-weight:700; display:inline-block; ${styleMap[level]}">${level}</span>`;
}

// --- EXPIRATION DATE DISPLAY (red if expired, amber if expiring soon) ---
function formatExpirationBadge(dateStr) {
    if (!dateStr) return '<span style="color:var(--text-secondary);">—</span>';
    const expDate = new Date(dateStr);
    if (isNaN(expDate.getTime())) return '<span style="color:var(--text-secondary);">—</span>';
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const msPerDay = 1000 * 60 * 60 * 24;
    const daysLeft = Math.round((expDate - today) / msPerDay);
    const label = expDate.toLocaleDateString();
    if (daysLeft < 0) {
        return `<span style="color:#EF4444; font-weight:600;">${label} (Expired)</span>`;
    } else if (daysLeft <= 30) {
        return `<span style="color:#F59E0B; font-weight:600;">${label} (${daysLeft}d left)</span>`;
    }
    return `<span>${label}</span>`;
}

// --- CRUD: ADJUSTMENT MODAL ---
async function openAdjustmentModal(product = null) {
    const isSpecificProduct = !!product;
    const title = isSpecificProduct ? `Adjust Stock: ${product.name}` : 'Manual Stock Adjustment';

    let allProducts = [];
    if (!isSpecificProduct) {
        try {
            allProducts = await dataService.findAll('products');
        } catch (error) {
            console.error('Error loading products:', error);
            toast.show('Failed to load products. Please refresh.', 'error');
            return;
        }
    }

    const formHTML = `
        <form id="adjustForm" style="display:grid; gap:16px;">
            ${!isSpecificProduct ? `
            <div>
                <label style="display:block; font-weight:600; font-size:0.875rem; color:var(--text-primary); margin-bottom:6px;">Select Product *</label>
                <select id="adj_product" class="form-input">
                    <option value="">-- Select Product --</option>
                    ${allProducts.map(p => `<option value="${p.id}">${p.name} (SKU: ${p.sku}) - Current: ${parseInt(p.stock || 0)}</option>`).join('')}
                </select>
            </div>` : `
            <div>
                <label style="display:block; font-weight:600; font-size:0.875rem; color:var(--text-primary); margin-bottom:6px;">Product</label>
                <input type="text" value="${product.name}" class="form-input" disabled>
                <input type="hidden" id="adj_product" value="${product.id}">
            </div>`}

            <div>
                <label style="display:block; font-weight:600; font-size:0.875rem; color:var(--text-primary); margin-bottom:6px;">Adjustment Type *</label>
                <select id="adj_type" class="form-input">
                    <option value="Stock In">Stock In (Add Stock)</option>
                    <option value="Stock Out">Stock Out (Remove Stock)</option>
                    <option value="Adjustment">Adjustment (Set Exact Count)</option>
                </select>
            </div>

            <div>
                <label style="display:block; font-weight:600; font-size:0.875rem; color:var(--text-primary); margin-bottom:6px;">Quantity *</label>
                <input type="number" id="adj_quantity" class="form-input" placeholder="Enter quantity" min="0" required>
                <small style="color:var(--text-muted); font-size:0.8rem; margin-top:4px; display:block;">For Stock In/Out: quantity to add/remove. For Adjustment: new stock count.</small>
            </div>

            <div>
                <label style="display:block; font-weight:600; font-size:0.875rem; color:var(--text-primary); margin-bottom:6px;">Reason for Adjustment *</label>
                <select id="adj_reason" class="form-input">
                    <option value="Restock">Restock</option>
                    <option value="Sales">Sales (Order Fulfillment)</option>
                    <option value="Damaged">Damaged Goods</option>
                    <option value="Expired">Expired Items</option>
                    <option value="Inventory Count">Cycle Count / Correction</option>
                    <option value="Return">Customer Return</option>
                </select>
            </div>

            <div>
                <label style="display:block; font-weight:600; font-size:0.875rem; color:var(--text-primary); margin-bottom:6px;">Notes (Optional)</label>
                <textarea id="adj_notes" rows="2" class="form-input" style="resize:vertical;" placeholder="Add any internal notes..."></textarea>
            </div>
        </form>
    `;

    modal.open(title, formHTML, {
        confirmText: 'Submit Adjustment',
        onConfirm: async () => {
            try {
                // Get form values
                const productId = document.getElementById('adj_product').value;
                const type = document.getElementById('adj_type').value;
                const quantity = parseInt(document.getElementById('adj_quantity').value);
                const reason = document.getElementById('adj_reason').value;
                const notes = document.getElementById('adj_notes').value.trim();

                // Validation
                if (!productId) {
                    toast.show('Please select a product.', 'error');
                    return;
                }
                
                if (isNaN(quantity) || quantity < 0) {
                    toast.show('Please enter a valid positive quantity.', 'error');
                    return;
                }

                if (quantity === 0) {
                    toast.show('Quantity must be greater than 0.', 'error');
                    return;
                }

                // Get product data
                let productData;
                try {
                    productData = await dataService.findById('products', productId);
                } catch (error) {
                    console.error('Error fetching product:', error);
                    toast.show('Failed to fetch product data. Please try again.', 'error');
                    return;
                }

                if (!productData) {
                    toast.show('Product not found. Please refresh and try again.', 'error');
                    return;
                }

                let currentStock = parseInt(productData.stock || 0);
                let newStock = currentStock;
                let actualChange = 0;
                
                if (type === 'Stock In') {
                    newStock = currentStock + quantity;
                    actualChange = quantity;
                } else if (type === 'Stock Out') {
                    if (currentStock < quantity) {
                        toast.show(`Insufficient stock! Current: ${currentStock}. Requested to remove: ${quantity}`, 'error');
                        return;
                    }
                    newStock = currentStock - quantity;
                    actualChange = -quantity;
                } else if (type === 'Adjustment') {
                    // For adjustment, the quantity is the NEW stock count
                    actualChange = quantity - currentStock;
                    newStock = quantity;
                }

                // Update product via DataService (keeps all other collections intact)
                try {
                    await dataService.update('products', productId, {
                        stock: newStock,
                        status: getStockStatus(newStock, productData.reorderLevel),
                        lastUpdated: new Date().toISOString()
                    });
                } catch (error) {
                    console.error('Error updating product:', error);
                    toast.show(`Failed to update product: ${error.message || 'Unknown error'}`, 'error');
                    return;
                }

                // Log the movement with enhanced details
                try {
                    const movementLog = {
                        productId: productData.id,
                        productName: productData.name,
                        sku: productData.sku || 'N/A',
                        date: new Date().toISOString(),
                        type: type,
                        quantity: Math.abs(actualChange),
                        previousBalance: currentStock,
                        newBalance: newStock,
                        change: actualChange,
                        reason: reason,
                        notes: notes || `${type} - ${reason}`,
                        user: store.getState().user?.name || 'System',
                        referenceType: 'MANUAL',
                        referenceId: `ADJ-${Date.now().toString().slice(-6)}`
                    };

                    await dataService.create('inventory_movements', movementLog);
                } catch (error) {
                    console.error('Error logging movement:', error);
                    toast.show('Stock updated but failed to log movement.', 'warning');
                }

                // Show success message
                const actionText = actualChange >= 0 ? 'increased' : 'decreased';
                toast.show(`Stock ${actionText} successfully! New balance: ${newStock} (${type})`, 'success');
                modal.close();
                
                // Force refresh the inventory view
                await renderCurrentStockView();

            } catch (error) {
                console.error('Stock adjustment error:', error);
                const errorMsg = error.message || 'Please try again.';
                toast.show(`Failed to update stock: ${errorMsg}`, 'error');
            }
        }
    });
}
/**
 * Create a standardized stock movement record
 */
function createStockMovement(productData, type, quantity, previousStock, newStock, reference = {}) {
    return {
        productId: productData.id,
        productName: productData.name,
        sku: productData.sku || 'N/A',
        date: new Date().toISOString(),
        type: type, // 'Stock In', 'Stock Out', 'Adjustment'
        quantity: Math.abs(quantity),
        previousBalance: previousStock,
        newBalance: newStock,
        change: quantity, // Positive for increase, negative for decrease
        reason: reference.reason || type,
        notes: reference.notes || '',
        user: store.getState().user?.name || 'System',
        referenceType: reference.type || 'MANUAL',
        referenceId: reference.id || null,
        referencePO: reference.poNumber || null,
        unitCost: reference.unitCost || null
    };
}

// Export for use in other modules
window.InventoryHelpers = {
    createStockMovement
};


// --- EXPIRATION BRIDGE: know exactly which products will expire ---
async function renderExpirationBridgeView() {
    currentView = 'expiring';
    const container = document.getElementById('inventoryViewContainer');

    // Hide default stock summary layout pieces if present
    const stockSummary = document.getElementById('stockSummary');
    const searchRow = document.getElementById('inventorySearch')?.parentElement;
    if (stockSummary) stockSummary.style.display = 'none';
    if (searchRow) searchRow.style.display = 'none';

    try {
        currentProducts = await dataService.findAll('products');
        const today = new Date();
        today.setHours(0, 0, 0, 0);

        const withExpiry = currentProducts
            .filter(p => p.expirationDate)
            .map(p => {
                const exp = new Date(p.expirationDate);
                exp.setHours(0, 0, 0, 0);
                const daysLeft = Math.ceil((exp - today) / (1000 * 60 * 60 * 24));
                return { ...p, daysLeft, expDate: exp };
            })
            .sort((a, b) => a.daysLeft - b.daysLeft);

        const expired = withExpiry.filter(p => p.daysLeft < 0);
        const d7 = withExpiry.filter(p => p.daysLeft >= 0 && p.daysLeft <= 7);
        const d30 = withExpiry.filter(p => p.daysLeft > 7 && p.daysLeft <= 30);
        const d60 = withExpiry.filter(p => p.daysLeft > 30 && p.daysLeft <= 60);
        const later = withExpiry.filter(p => p.daysLeft > 60);

        const dataContainer = document.getElementById('inventoryDataContainer');
        dataContainer.innerHTML = `
            <div style="margin-bottom:20px;">
                <h2 style="font-size:1.15rem; font-weight:700; color:var(--text-primary); margin-bottom:6px;">Expiration Bridge</h2>
                <p style="color:var(--text-secondary); font-size:0.9rem; margin-bottom:16px;">
                    See exactly which products are expired or approaching expiration so you can prioritize sell-through, promos, or disposal.
                </p>
                <div class="grid-4" style="margin-bottom:20px;">
                    <div class="stat-card" style="border-left:4px solid #EF4444; cursor:pointer;" data-exp-filter="expired">
                        <span class="stat-label">Expired</span>
                        <span class="stat-value" style="color:#DC2626;">${expired.length}</span>
                    </div>
                    <div class="stat-card" style="border-left:4px solid #F97316; cursor:pointer;" data-exp-filter="7">
                        <span class="stat-label">Within 7 Days</span>
                        <span class="stat-value" style="color:#EA580C;">${d7.length}</span>
                    </div>
                    <div class="stat-card" style="border-left:4px solid #F59E0B; cursor:pointer;" data-exp-filter="30">
                        <span class="stat-label">8–30 Days</span>
                        <span class="stat-value" style="color:#D97706;">${d30.length}</span>
                    </div>
                    <div class="stat-card" style="border-left:4px solid #3B82F6; cursor:pointer;" data-exp-filter="60">
                        <span class="stat-label">31–60 Days</span>
                        <span class="stat-value" style="color:#2563EB;">${d60.length}</span>
                    </div>
                </div>
                <div style="display:flex; gap:10px; flex-wrap:wrap; margin-bottom:16px; align-items:center;">
                    <label style="font-size:0.85rem; font-weight:600; color:var(--text-secondary);">Filter:</label>
                    <select id="expBridgeFilter" style="padding:8px 12px; border:1.5px solid var(--border-color); border-radius:8px; background:var(--bg-white); font-size:0.875rem; font-family:inherit;">
                        <option value="all">All with expiration</option>
                        <option value="expired">Expired only</option>
                        <option value="7">Within 7 days</option>
                        <option value="30">Within 30 days</option>
                        <option value="60">Within 60 days</option>
                        <option value="ok">More than 60 days</option>
                    </select>
                    <input type="text" id="expBridgeSearch" placeholder="Search product or SKU..."
                        style="flex:1; min-width:180px; padding:8px 12px; border:1.5px solid var(--border-color); border-radius:8px; font-size:0.875rem; font-family:inherit;">
                </div>
            </div>
            <div id="expBridgeTable"></div>
        `;

        const renderExpTable = () => {
            const filter = document.getElementById('expBridgeFilter')?.value || 'all';
            const q = (document.getElementById('expBridgeSearch')?.value || '').toLowerCase().trim();
            let list = withExpiry;
            if (filter === 'expired') list = expired;
            else if (filter === '7') list = d7;
            else if (filter === '30') list = withExpiry.filter(p => p.daysLeft >= 0 && p.daysLeft <= 30);
            else if (filter === '60') list = withExpiry.filter(p => p.daysLeft >= 0 && p.daysLeft <= 60);
            else if (filter === 'ok') list = later;

            if (q) {
                list = list.filter(p =>
                    (p.name || '').toLowerCase().includes(q) ||
                    (p.sku || '').toLowerCase().includes(q) ||
                    (p.batchNumber || '').toLowerCase().includes(q)
                );
            }

            if (list.length === 0) {
                document.getElementById('expBridgeTable').innerHTML = `
                    <div class="card" style="text-align:center; padding:36px;">
                        <p style="color:var(--text-secondary);">No products match this expiration filter.</p>
                    </div>`;
                return;
            }

            const columns = [
                { key: 'name', label: 'Product' },
                { key: 'sku', label: 'SKU' },
                { key: 'stock', label: 'Stock' },
                { key: 'batchNumber', label: 'Batch' },
                { key: 'manufacturingDate', label: 'Start (Mfg)' },
                { key: 'expirationDate', label: 'Expiration' },
                { key: 'daysLeftLabel', label: 'Days Left' },
                { key: 'urgency', label: 'Urgency' },
                { key: 'srp', label: 'SRP' }
            ];

            const formatDate = (d) => {
                if (!d) return '—';
                try {
                    const dt = new Date(d);
                    if (isNaN(dt.getTime())) return String(d);
                    return dt.toLocaleDateString('en-CA'); // YYYY-MM-DD
                } catch (_) {
                    return String(d);
                }
            };

            const formatted = list.map(p => {
                let urgency, daysLabel, color;
                if (p.daysLeft < 0) {
                    urgency = '<span style="background:#FEE2E2;color:#991B1B;padding:3px 8px;border-radius:6px;font-size:0.75rem;font-weight:600;">EXPIRED</span>';
                    daysLabel = `<span style="color:#DC2626;font-weight:700;">${Math.abs(p.daysLeft)}d ago</span>`;
                } else if (p.daysLeft <= 7) {
                    urgency = '<span style="background:#FFEDD5;color:#9A3412;padding:3px 8px;border-radius:6px;font-size:0.75rem;font-weight:600;">CRITICAL</span>';
                    daysLabel = `<span style="color:#EA580C;font-weight:700;">${p.daysLeft}d</span>`;
                } else if (p.daysLeft <= 30) {
                    urgency = '<span style="background:#FEF3C7;color:#92400E;padding:3px 8px;border-radius:6px;font-size:0.75rem;font-weight:600;">SOON</span>';
                    daysLabel = `<span style="color:#D97706;font-weight:600;">${p.daysLeft}d</span>`;
                } else if (p.daysLeft <= 60) {
                    urgency = '<span style="background:#DBEAFE;color:#1E40AF;padding:3px 8px;border-radius:6px;font-size:0.75rem;font-weight:600;">WATCH</span>';
                    daysLabel = `<span style="color:#2563EB;">${p.daysLeft}d</span>`;
                } else {
                    urgency = '<span style="background:#D1FAE5;color:#065F46;padding:3px 8px;border-radius:6px;font-size:0.75rem;font-weight:600;">OK</span>';
                    daysLabel = `<span style="color:#059669;">${p.daysLeft}d</span>`;
                }
                return {
                    ...p,
                    stock: formatQuantity(p.stock),
                    batchNumber: p.batchNumber || '—',
                    manufacturingDate: formatDate(p.manufacturingDate || p.manufacturing_date),
                    expirationDate: formatDate(p.expirationDate),
                    daysLeftLabel: daysLabel,
                    urgency,
                    srp: p.srp ? `₱${formatCurrency(p.srp)}` : '—'
                };
            });

            document.getElementById('expBridgeTable').innerHTML = '<div id="expBridgeTableInner"></div>';
            new DataTable('expBridgeTableInner', columns, formatted, { actions: false });
        };

        document.getElementById('expBridgeFilter')?.addEventListener('change', renderExpTable);
        document.getElementById('expBridgeSearch')?.addEventListener('input', renderExpTable);
        document.querySelectorAll('[data-exp-filter]').forEach(card => {
            card.addEventListener('click', () => {
                const f = card.dataset.expFilter;
                const sel = document.getElementById('expBridgeFilter');
                if (sel) {
                    sel.value = f === 'expired' ? 'expired' : f;
                    renderExpTable();
                }
            });
        });

        renderExpTable();
    } catch (error) {
        console.error('Error loading expiration bridge:', error);
        toast.show('Failed to load expiration data.', 'error');
    }
}
